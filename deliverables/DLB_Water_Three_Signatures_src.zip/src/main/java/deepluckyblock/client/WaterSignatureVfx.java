package deepluckyblock.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * T375-WATER-REFONTE — élément <b>EAU</b> : trois signatures voxel sur un moteur commun.
 *
 * <p><b>Pourquoi cette classe ?</b> L'eau était le dernier des cinq éléments chinois classiques à
 * n'avoir <i>aucun</i> moteur dédié : ses trois signatures étaient dessinées en ligne dans
 * {@code WeaponWorldVfxManager#impactWater} (une nappe de cubes, une « vague » générique et un
 * buisson de piques de glace) et duraient 14 à 22 ticks, soit moins d'une seconde — là où le feu,
 * la terre, le métal, la lumière, le poison, la nature et le vent ont tous reçu une chorégraphie de
 * 80 à 170 ticks avec son propre fichier. Cette classe met l'eau au même niveau.</p>
 *
 * <p><b>Langage visuel.</b> Une masse d'eau réelle n'est pas une plaque bleue : elle a une
 * <i>épaisseur</i> (le volume est translucide, l'écume est opaque), elle <i>déferle</i> (la crête
 * avance plus vite que la base et finit par basculer), et elle <i>revient</i> (reflux + rides).
 * Un tourbillon réel tourne en <b>rotation différentielle</b> : plus on approche de l'axe, plus
 * c'est rapide et plus c'est bas. Le givre, lui, ne « pousse » pas : il <i>court</i> au sol en
 * étoile, puis cristallise en pics, puis <b>éclate</b>.</p>
 *
 * <ul>
 *   <li>{@link #SURGE} — <b>Raz-de-marée</b> ({@code HYDRO_TIDAL_SURGE}, 104 ticks) : la mer se
 *       retire, un mur d'eau de 4,6 blocs se lève derrière la cible, le traverse, la lèvre
 *       s'enroule et déferle en écume, puis la nappe reflue en rides concentriques.</li>
 *   <li>{@link #MAELSTROM} — <b>Maelström abyssal</b> ({@code ABYSSAL_MAELSTROM}, 150 ticks) : un
 *       bassin en entonnoir se creuse dans le sol, cinq anneaux tournent de plus en plus vite vers
 *       une gorge noire, trois bras d'écume en spirale logarithmique y plongent, puis tout implose
 *       et un <b>geyser</b> de 9 blocs recrache ce qui a été avalé.</li>
 *   <li>{@link #RIME} — <b>Givre du permafrost</b> ({@code PERMAFROST_RIME}, 120 ticks) : le gel
 *       court au sol en étoile de givre, neuf pics de glace percent le sol, la cible est enfermée
 *       dans un bloc translucide qui se fissure, tremble, puis <b>éclate</b> en soixante éclats.</li>
 * </ul>
 *
 * <p><b>Blocs réels.</b> Comme pour le vent et le séisme, les vrais {@code BlockState} du terrain
 * sont capturés et animés par une classe séparée ({@link WaterTerrainVfx}) : la vague pousse les
 * blocs devant elle, le maelström les avale en spirale. Cette classe ne dessine que l'eau, l'écume
 * et la glace.</p>
 *
 * <p><b>Contraintes.</b> Aucune allocation dans la passe de rendu, aucun {@code RenderType}
 * demandé ici, tout est exprimé dans le repère caméra-relatif fourni par le manager. Charge mesurée
 * au pic : ≈ 560 cubes pour le raz-de-marée, ≈ 470 pour le maelström, ≈ 580 pour le givre —
 * sous le plafond de 7 000 cubes par image de {@link WeaponWorldVfxManager}.</p>
 */
public final class WaterSignatureVfx {

    /** Raz-de-marée ({@code HYDRO_TIDAL_SURGE}). */
    public static final int SURGE = 0;
    /** Maelström abyssal ({@code ABYSSAL_MAELSTROM}). */
    public static final int MAELSTROM = 1;
    /** Givre du permafrost ({@code PERMAFROST_RIME}). */
    public static final int RIME = 2;

    /** Palette eau : de l'abysse à l'écume. */
    private static final int ABYSS = 0x0B3550;
    private static final int DEEP = 0x14557F;
    private static final int OCEAN = 0x1E7BA8;
    private static final int AZURE = 0x37A6D6;
    private static final int SHALLOW = 0x62C7E8;
    private static final int SPRAY = 0xA9E6F7;
    private static final int FOAM = 0xE8FBFF;
    private static final int WHITE = 0xF6FEFF;
    /** Palette givre : la glace garde une dominante plus froide et plus claire que l'eau liquide. */
    private static final int ICE_DEEP = 0x2E6F93;
    private static final int ICE = 0x7FC9E8;
    private static final int ICE_PALE = 0xBFEBFA;
    private static final int FROST = 0xE4F7FF;

    private static final float TAU = (float) (Math.PI * 2.0);

    private WaterSignatureVfx() { }

    /**
     * Point d'entrée unique des trois signatures.
     *
     * @param cx,cy,cz origine caméra-relative (centre de la cible)
     * @param dx,dz    direction horizontale normalisée (sens de marche de la vague)
     * @param t        progression 0..1 sur la durée visuelle
     * @param alpha    opacité de base fournie par le manager (0..255)
     * @param salt     graine stable de l'instance
     */
    public static void render(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                              float cx, float cy, float cz, float t,
                              float dx, float dz, int variant, int alpha, int salt) {
        if (t <= 0.0f || t >= 1.0f || alpha <= 4) return;
        float length = Mth.sqrt(dx * dx + dz * dz);
        if (length < 0.001f) { dx = 0.0f; dz = 1.0f; }
        else { dx /= length; dz /= length; }
        if (variant == MAELSTROM) renderMaelstrom(vc, mat, tmp, cx, cy, cz, t, dx, dz, alpha, salt);
        else if (variant == RIME) renderRime(vc, mat, tmp, cx, cy, cz, t, dx, dz, alpha, salt);
        else renderSurge(vc, mat, tmp, cx, cy, cz, t, dx, dz, alpha, salt);
    }

    // ============================================================================================
    // 1. RAZ-DE-MARÉE — retrait, mur d'eau qui avance, lèvre qui déferle, reflux
    // ============================================================================================

    /** Hauteur du mur d'eau au plus fort du déferlement, en blocs. */
    private static final float SURGE_HEIGHT = 4.60f;
    /** Demi-largeur du front, en blocs : la vague est un mur, pas un jet. */
    private static final float SURGE_HALF_WIDTH = 3.40f;
    /** Nombre de colonnes du mur. Chaque colonne a sa propre hauteur et sa propre phase. */
    private static final int SURGE_COLUMNS = 19;

    /**
     * Chorégraphie (104 ticks) :
     * <ul>
     *   <li>0,00–0,18 <b>retrait</b> : l'eau est aspirée vers l'arrière, le sol se découvre ;</li>
     *   <li>0,10–0,54 <b>montée et marche</b> : le mur se lève à 3,4 blocs derrière la cible et
     *       avance jusqu'à 2,8 blocs devant elle ;</li>
     *   <li>0,34–0,64 <b>déferlement</b> : la lèvre s'enroule vers l'avant et bascule ;</li>
     *   <li>0,50–0,82 <b>écume et gerbes</b> : projections balistiques et moutons blancs ;</li>
     *   <li>0,66–1,00 <b>reflux</b> : rides concentriques au sol et nappe qui s'efface.</li>
     * </ul>
     */
    private static void renderSurge(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                    float cx, float cy, float cz, float t,
                                    float dx, float dz, int alpha, int salt) {
        int a = Math.round(alpha * smooth(t / 0.05f) * (1.0f - smooth((t - 0.90f) / 0.10f)));
        if (a <= 4) return;

        float draw = smooth(t / 0.18f);                        // retrait initial
        float lift = smooth((t - 0.08f) / 0.34f);              // montée du mur
        float march = smooth((t - 0.12f) / 0.46f);             // avancée du front
        float curl = smooth((t - 0.34f) / 0.26f);              // enroulement de la lèvre
        float burst = smooth((t - 0.50f) / 0.16f) * (1.0f - smooth((t - 0.82f) / 0.18f));
        float ebb = smooth((t - 0.66f) / 0.30f);               // reflux
        float body = (1.0f - ebb * 0.86f);

        // ---- 1. Retrait : l'eau recule et découvre le sol (3 arcs de succion, 72 cubes) ----
        if (draw < 1.0f || ebb > 0.0f) {
            float pull = Math.max(1.0f - draw, ebb * 0.85f);
            for (int arc = 0; arc < 3; arc++) {
                float radius = (1.10f + arc * 0.78f) * (0.65f + 0.55f * pull);
                for (int i = 0; i < 24; i++) {
                    float u = (i / 23.0f) * 2.0f - 1.0f;
                    float h = hash(salt, 7100 + arc * 61 + i * 7);
                    float lateral = u * radius * 1.35f;
                    float forward = -radius * (0.55f + 0.45f * Mth.cos(u * 1.4f)) - pull * 0.70f;
                    float y = -1.12f + 0.05f * h + 0.08f * Mth.sin(t * 7.0f + i * 0.9f);
                    float size = (0.070f + 0.045f * h) * (0.55f + 0.45f * pull);
                    box(vc, mat, tmp, cx, cy, cz, dx, dz, forward, lateral, y,
                            size * 1.5f, size * 0.42f, size * 1.5f,
                            mix(DEEP, OCEAN, h), opaque(a * pull * 0.62f));
                }
            }
        }

        // ---- 2. Le mur d'eau : 19 colonnes pleines, crête irrégulière, lèvre enroulée ----
        // La position du front va de -3,4 (derrière la cible) à +2,8 (devant elle).
        float front = Mth.lerp(march, -3.40f, 2.80f);
        if (body > 0.02f) {
            for (int c = 0; c < SURGE_COLUMNS; c++) {
                float u = (c / (float) (SURGE_COLUMNS - 1)) * 2.0f - 1.0f;      // -1 .. +1
                float hc = hash(salt, 7300 + c * 29);
                float hc2 = hash(salt, 7400 + c * 53);
                // Profil du front : plein au centre, effilé aux extrémités, jamais symétrique.
                float profile = (1.0f - u * u * 0.74f) * (0.86f + 0.26f * hc);
                float columnH = SURGE_HEIGHT * lift * profile * body;
                if (columnH < 0.12f) continue;
                float lateral = u * SURGE_HALF_WIDTH;
                // Le front n'est pas droit : il se recourbe en arc, les ailes restent en retard.
                float forward = front - (u * u) * 1.15f + (hc2 - 0.5f) * 0.22f;
                int steps = Math.max(3, Mth.floor(columnH / 0.36f));
                for (int s = 0; s < steps; s++) {
                    float v = (s + 0.5f) / steps;                                 // 0 bas .. 1 crête
                    // Cisaillement : le haut de la colonne avance plus vite que le pied.
                    float shear = curl * v * v * 1.45f + march * v * 0.38f;
                    float y = -1.12f + columnH * v;
                    float half = (0.235f - 0.085f * v) * (0.90f + 0.22f * hc);
                    float depth = 0.30f + 0.26f * (1.0f - v);
                    int rgb = mix(mix(ABYSS, OCEAN, v * 0.85f), AZURE, v * v);
                    int ca = opaque(a * body * (0.62f + 0.34f * v));
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            forward + shear, lateral + Mth.sin(v * 3.1f + hc * 6.0f) * 0.10f, y,
                            depth, 0.21f + 0.06f * (1.0f - v), half,
                            0.0f, -curl * v * 0.85f, (hc2 - 0.5f) * 0.30f, rgb, ca);
                }
                // ---- Lèvre : le sommet bascule vers l'avant et se creuse (tube de la vague) ----
                if (curl > 0.03f) {
                    int lipSteps = 5;
                    for (int s = 0; s < lipSteps; s++) {
                        float v = s / (float) (lipSteps - 1);
                        float arcAngle = curl * (0.35f + v * 1.95f);
                        float r = 0.52f + 0.20f * hc;
                        float ly = -1.12f + columnH + Mth.sin(arcAngle) * r * 0.70f - v * 0.10f;
                        float lf = forward + curl * 1.45f + (1.0f - Mth.cos(arcAngle)) * r * 1.35f;
                        int rgb = mix(AZURE, FOAM, 0.30f + 0.60f * v);
                        rot(vc, mat, tmp, cx, cy, cz, dx, dz, lf, lateral, ly,
                                0.30f, 0.17f, 0.215f + 0.03f * hc,
                                0.0f, -arcAngle, 0.0f, rgb,
                                opaque(a * body * curl * (0.80f - 0.25f * v)));
                    }
                }
            }
        }

        // ---- 3. Écume : moutons blancs discontinus sur la crête (jamais une nappe continue) ----
        if (curl > 0.05f && ebb < 0.85f) {
            for (int i = 0; i < 58; i++) {
                float h = hash(salt, 7600 + i * 17);
                if (h > 0.62f) continue;                       // discontinue par construction
                float h2 = hash(salt, 7700 + i * 31);
                float h3 = hash(salt, 7800 + i * 11);
                float u = (h2 * 2.0f - 1.0f);
                float columnH = SURGE_HEIGHT * lift * (1.0f - u * u * 0.74f) * body;
                float lf = front - (u * u) * 1.15f + curl * (1.10f + 0.90f * h3);
                float ly = -1.12f + columnH * (0.86f + 0.22f * h3) + curl * 0.22f;
                float size = 0.055f + 0.055f * h3;
                box(vc, mat, tmp, cx, cy, cz, dx, dz, lf, u * SURGE_HALF_WIDTH, ly,
                        size, size * (0.70f + 0.40f * h), size,
                        mix(FOAM, WHITE, h3), opaque(a * (1.0f - ebb) * 0.92f));
            }
        }

        // ---- 4. Gerbes balistiques : l'eau qui part en l'air au moment du déferlement ----
        if (burst > 0.01f) {
            for (int i = 0; i < 46; i++) {
                float h = hash(salt, 7900 + i * 13);
                float h2 = hash(salt, 8000 + i * 23);
                float h3 = hash(salt, 8100 + i * 37);
                float birth = 0.50f + h * 0.18f;
                float life = (t - birth) / 0.30f;
                if (life <= 0.0f || life >= 1.0f) continue;
                float speed = 2.10f + 2.60f * h2;
                float side = (h3 * 2.0f - 1.0f) * 2.60f;
                float dForward = front + life * speed * (0.45f + 0.55f * h2);
                float dY = -1.12f + life * (3.60f + 1.70f * h) - life * life * (4.30f + 1.60f * h2);
                if (dY < -1.16f) continue;
                float size = (0.055f + 0.050f * h3) * (1.0f - life * 0.45f);
                int rgb = mix(SPRAY, WHITE, h2 * 0.75f);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz, dForward, side * (0.55f + 0.45f * life), dY,
                        size, size * 1.30f, size,
                        life * 7.0f * (h - 0.5f), life * 5.0f, life * 4.0f, rgb,
                        opaque(a * burst * (1.0f - life * 0.80f)));
            }
        }

        // ---- 5. Reflux : trois rides concentriques plates qui s'éloignent et meurent ----
        if (ebb > 0.02f) {
            for (int ring = 0; ring < 3; ring++) {
                float phase = ebb - ring * 0.14f;
                if (phase <= 0.0f) continue;
                float radius = 0.90f + phase * (4.60f + ring * 0.85f);
                int count = 30 + ring * 6;
                float ringFade = (1.0f - smooth(phase * 1.12f)) * (1.0f - ebb * 0.25f);
                for (int i = 0; i < count; i++) {
                    float ang = i * TAU / count + ring * 0.22f;
                    float h = hash(salt, 8200 + ring * 97 + i * 5);
                    if (h > 0.86f) continue;
                    float r = radius * (0.95f + 0.10f * Mth.sin(ang * 3.0f + ebb * 5.0f));
                    float y = -1.14f + 0.045f * Mth.sin(ang * 5.0f + t * 12.0f);
                    float size = 0.085f + 0.055f * h;
                    box(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size * 1.45f, 0.030f + 0.020f * h, size * 1.45f,
                            mix(SHALLOW, FOAM, h), opaque(a * ringFade * 0.70f));
                }
            }
        }

        // 7. RUISSELLEMENT — l'eau redescend le long de la face du mur en filets verticaux.
        // Sans cela la paroi est une surface lisse et on ne lit pas sa hauteur.
        if (lift > 0.12f && body > 0.05f) {
            for (int i = 0; i < 34; i++) {
                float h = hash(salt, 8400 + i * 23);
                float h2 = hash(salt, 8500 + i * 41);
                float h3 = hash(salt, 8600 + i * 13);
                float u = h2 * 2.0f - 1.0f;
                float columnH = SURGE_HEIGHT * lift * (1.0f - u * u * 0.74f) * body;
                if (columnH < 0.35f) continue;
                // Le filet part du sommet et descend : phase propre, vitesse propre.
                float fall = fract(t * (0.70f + 0.55f * h3) + h);
                float fy = -1.12f + columnH * (1.0f - fall * 0.92f);
                float forward = front - (u * u) * 1.15f + curl * 0.55f + (h3 - 0.5f) * 0.20f;
                float len = 0.10f + 0.16f * (1.0f - fall);
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        forward, u * SURGE_HALF_WIDTH, fy,
                        0.055f, len, 0.045f + 0.025f * h3,
                        mix(SHALLOW, FOAM, 0.35f + 0.55f * (1.0f - fall)),
                        opaque(a * body * (0.55f - 0.30f * fall)));
            }
        }

        // 8. SOL MOUILLÉ — nappe sombre qui s'étend devant le front : la vague laisse une trace,
        // et surtout cela ancre le mur au terrain au lieu de le laisser flotter.
        if (march > 0.02f) {
            float wetFront = front + 1.10f;
            for (int i = 0; i < 40; i++) {
                float h = hash(salt, 8700 + i * 19);
                float h2 = hash(salt, 8800 + i * 7);
                float along = -3.60f + (wetFront + 3.60f) * h;
                float lateral = (h2 * 2.0f - 1.0f) * SURGE_HALF_WIDTH * (1.05f - 0.25f * h);
                float fade = 1.0f - ebb * 0.80f;
                if (fade <= 0.04f) continue;
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        along, lateral, -1.16f + 0.015f * h,
                        0.30f + 0.18f * h, 0.022f, 0.30f + 0.18f * h2,
                        mix(DEEP, OCEAN, h * 0.60f),
                        opaque(a * fade * 0.34f));
            }
        }
    }

    // ============================================================================================
    // 2. MAELSTRÖM ABYSSAL — bassin en entonnoir, rotation différentielle, gorge, geyser
    // ============================================================================================

    /** Rayon du bassin au plus large, en blocs. */
    private static final float BASIN_RADIUS = 4.35f;
    /** Profondeur apparente de l'entonnoir, en blocs. */
    private static final float BASIN_DEPTH = 3.30f;
    /** Hauteur du geyser final, en blocs. */
    private static final float GEYSER_HEIGHT = 9.00f;
    /** Anneaux concentriques du bassin : du bord (0) à la gorge (4). */
    private static final int BASIN_RINGS = 5;

    /**
     * Chorégraphie (150 ticks) :
     * <ul>
     *   <li>0,00–0,20 <b>ouverture</b> : l'eau afflue, le bassin se creuse du bord vers l'axe ;</li>
     *   <li>0,12–0,74 <b>rotation différentielle</b> : cinq anneaux tournent, de plus en plus vite
     *       et de plus en plus bas vers la gorge ; trois bras d'écume en spirale les relient ;</li>
     *   <li>0,60–0,80 <b>implosion</b> : les anneaux se referment sur l'axe, la gorge s'éteint ;</li>
     *   <li>0,76–1,00 <b>geyser</b> : une colonne de 9 blocs jaillit, couronne d'écume et retombée.</li>
     * </ul>
     */
    private static void renderMaelstrom(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                        float cx, float cy, float cz, float t,
                                        float dx, float dz, int alpha, int salt) {
        int a = Math.round(alpha * smooth(t / 0.05f) * (1.0f - smooth((t - 0.93f) / 0.07f)));
        if (a <= 4) return;

        float open = smooth(t / 0.20f);
        float spinPhase = t * 10.0f;
        float implode = smooth((t - 0.60f) / 0.20f);
        float geyser = smooth((t - 0.76f) / 0.14f) * (1.0f - smooth((t - 0.94f) / 0.06f));
        float basinLife = (1.0f - implode);

        // ---- 1. Les cinq anneaux du bassin (rotation différentielle : l'axe tourne le plus vite) ----
        if (basinLife > 0.02f) {
            for (int ring = 0; ring < BASIN_RINGS; ring++) {
                float k = ring / (float) (BASIN_RINGS - 1);                  // 0 bord .. 1 gorge
                float radius = BASIN_RADIUS * (1.0f - k * 0.80f) * open
                        * (1.0f - implode * (0.25f + 0.70f * k));
                if (radius < 0.10f) continue;
                float depth = -0.95f - BASIN_DEPTH * k * k * open;
                // Vitesse angulaire : ×1 au bord, ×3,4 à la gorge — c'est ce différentiel qui fait
                // « tourbillon » plutôt que « roue ». Le sens est unique, comme pour la tornade.
                float omega = 1.0f + k * 2.40f;
                int count = Math.max(18, Math.round(44 - ring * 4.0f));
                for (int i = 0; i < count; i++) {
                    float h = hash(salt, 9100 + ring * 211 + i * 7);
                    float ang = i * TAU / count + spinPhase * omega + ring * 0.47f;
                    float wobble = 0.90f + 0.16f * Mth.sin(ang * 3.0f + t * 9.0f + ring);
                    float r = radius * wobble;
                    float y = depth + 0.10f * Mth.sin(ang * 4.0f + t * 11.0f) - 0.05f * h;
                    // Chaque cube est incliné sur la pente de l'entonnoir : la paroi est lisse.
                    float slope = -(0.42f + 0.95f * k);
                    float size = (0.185f - 0.055f * k) * (0.85f + 0.30f * h);
                    int rgb = mix(mix(SHALLOW, OCEAN, k), ABYSS, k * k * 0.85f);
                    int ca = opaque(a * basinLife * (0.52f + 0.40f * (1.0f - k)));
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size * 1.55f, size * 0.52f, size * 1.05f,
                            ang, slope, 0.0f, rgb, ca);
                }
            }
        }

        // ---- 2. Trois bras d'écume en spirale logarithmique, du bord à la gorge ----
        if (basinLife > 0.02f) {
            for (int arm = 0; arm < 4; arm++) {
                float armPhase = arm * (TAU / 4.0f);
                for (int i = 0; i < 30; i++) {
                    float v = i / 29.0f;                                       // 0 bord .. 1 gorge
                    float h = hash(salt, 9400 + arm * 131 + i * 17);
                    if (h > 0.90f) continue;
                    float radius = BASIN_RADIUS * (1.0f - v * 0.88f) * open
                            * (1.0f - implode * (0.20f + 0.75f * v));
                    // Spirale : l'angle s'enroule de 1,6 tour entre le bord et la gorge.
                    float ang = armPhase + v * TAU * 1.60f + spinPhase * (1.0f + v * 2.40f);
                    float y = -0.95f - BASIN_DEPTH * v * v * open + 0.06f * Mth.sin(v * 20.0f + t * 14.0f);
                    float size = (0.085f - 0.030f * v) * (0.80f + 0.45f * h);
                    int rgb = mix(FOAM, SPRAY, v * 0.80f);
                    box(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * radius, Mth.sin(ang) * radius, y,
                            size * 1.35f, size * 0.55f, size * 1.35f,
                            rgb, opaque(a * basinLife * (0.90f - 0.35f * v)));
                }
            }
        }

        // ---- 3. La gorge : cylindre sombre qui aspire, pulsant, au fond de l'entonnoir ----
        if (basinLife > 0.02f) {
            float throat = 0.62f * open * (1.0f - implode);
            for (int level = 0; level < 4; level++) {
                float lv = level / 3.0f;
                float r = throat * (1.0f - lv * 0.55f);
                if (r < 0.05f) continue;
                float y = -0.95f - BASIN_DEPTH * open * (0.72f + 0.26f * lv);
                int count = 14 - level * 2;
                for (int i = 0; i < count; i++) {
                    float ang = i * TAU / count + spinPhase * (3.4f + lv * 1.6f);
                    float pulse = 0.88f + 0.18f * Mth.sin(t * 24.0f + lv * 2.4f);
                    box(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r * pulse, Mth.sin(ang) * r * pulse, y,
                            0.115f, 0.085f, 0.115f,
                            mix(ABYSS, DEEP, lv * 0.45f),
                            opaque(a * basinLife * (0.95f - 0.20f * lv)));
                }
            }
        }

        // ---- 4. Couronne du bord : l'eau qui déborde du bassin, en crête tournante ----
        if (open > 0.05f && basinLife > 0.02f) {
            int count = 44;
            for (int i = 0; i < count; i++) {
                float h = hash(salt, 9700 + i * 19);
                float ang = i * TAU / count + spinPhase * 0.85f;
                float r = BASIN_RADIUS * open * (1.02f + 0.08f * Mth.sin(ang * 5.0f + t * 8.0f))
                        * (1.0f - implode * 0.30f);
                float y = -1.02f + 0.30f * open * (0.55f + 0.45f * Mth.sin(ang * 3.0f - t * 10.0f))
                        + 0.06f * h;
                float size = 0.095f + 0.055f * h;
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 1.40f, size * 0.70f, size * 0.95f,
                        ang, -0.35f, 0.0f, mix(AZURE, FOAM, h * 0.65f),
                        opaque(a * basinLife * 0.78f));
            }
        }

        // ---- 5. Geyser : la colonne recrachée, sa couronne et ses retombées ----
        if (geyser > 0.01f) {
            float jet = smooth((t - 0.76f) / 0.10f);
            int steps = 26;
            for (int s = 0; s < steps; s++) {
                float v = (s + 0.5f) / steps;
                float h = hash(salt, 9900 + s * 23);
                // Le jet se construit de bas en haut : chaque tranche attend son tour.
                float local = Mth.clamp((jet - v * 0.55f) / 0.45f, 0.0f, 1.0f);
                if (local <= 0.0f) continue;
                float y = -1.10f + GEYSER_HEIGHT * v * local;
                float r = (0.78f - 0.46f * v) * (0.85f + 0.30f * h) * local;
                int count = Math.max(5, Math.round(11 - v * 5.0f));
                for (int i = 0; i < count; i++) {
                    float ang = i * TAU / count + spinPhase * (1.6f + v * 1.2f);
                    float size = (0.145f - 0.070f * v) * (0.85f + 0.28f * h);
                    int rgb = mix(mix(OCEAN, SHALLOW, v), WHITE, v * v * 0.80f);
                    box(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size, size * 1.55f, size, rgb,
                            opaque(a * geyser * (0.92f - 0.30f * v)));
                }
            }
            // Couronne : l'eau qui retombe en parapluie au sommet du jet.
            float crown = smooth((t - 0.84f) / 0.12f);
            if (crown > 0.02f) {
                for (int i = 0; i < 40; i++) {
                    float h = hash(salt, 10100 + i * 29);
                    float h2 = hash(salt, 10200 + i * 13);
                    float ang = i * TAU / 40.0f + h * 0.5f;
                    float reach = crown * (1.50f + 2.40f * h2);
                    float y = -1.10f + GEYSER_HEIGHT * (0.92f + 0.08f * h)
                            - crown * crown * (4.20f + 3.10f * h2);
                    if (y < -1.14f) continue;
                    float size = 0.065f + 0.050f * h2;
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * reach, Mth.sin(ang) * reach, y,
                            size, size * 1.25f, size,
                            ang, crown * 3.0f, crown * 2.0f,
                            mix(SPRAY, WHITE, h), opaque(a * geyser * (1.0f - crown * 0.55f)));
                }
            }
        }

        // 7. NAPPE DE SURFACE — anneau d'eau plaqué au sol, DÉBORDANT du bassin.
        //
        // Rôle technique autant qu'esthétique : depuis que le sol est réellement effacé à l'écran
        // (blocs fantômes, voir GhostBlockMask), il existe une arête nette entre le terrain intact
        // et le bord du trou. Cette nappe la recouvre : l'œil voit de l'eau qui tourne par-dessus
        // le rebord, pas une découpe géométrique.
        if (open > 0.04f) {
            float sheet = basinLife * (0.55f + 0.45f * open);
            for (int ring = 0; ring < 3; ring++) {
                float k = ring / 2.0f;
                float radius = BASIN_RADIUS * (1.02f + 0.16f * k) * open;
                int count = 38 + ring * 8;
                for (int i = 0; i < count; i++) {
                    float h = hash(salt, 10400 + ring * 137 + i * 11);
                    if (h > 0.88f) continue;
                    float ang = i * TAU / count + spinPhase * (0.55f - 0.12f * k) + ring * 0.31f;
                    float r = radius * (0.97f + 0.07f * Mth.sin(ang * 4.0f + t * 7.0f));
                    float y = -1.15f + 0.055f * Mth.sin(ang * 6.0f + t * 9.0f) + 0.02f * h;
                    float size = 0.115f + 0.070f * h;
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size * 1.50f, 0.028f + 0.018f * h, size * 1.10f,
                            -ang, 0.0f, 0.0f,
                            mix(mix(OCEAN, SHALLOW, k), FOAM, h * 0.45f),
                            opaque(a * sheet * (0.62f - 0.14f * k)));
                }
            }
        }

        // 8. BULLES — elles remontent du fond de la gorge, toujours, même pendant l'implosion.
        // C'est le seul élément qui se lit DANS le trou et qui en donne la profondeur.
        if (open > 0.08f) {
            for (int i = 0; i < 30; i++) {
                float h = hash(salt, 10600 + i * 29);
                float h2 = hash(salt, 10700 + i * 17);
                float h3 = hash(salt, 10800 + i * 43);
                float climb = fract(t * (0.42f + 0.38f * h3) + h);
                float ang = h2 * TAU + spinPhase * 1.20f * climb;
                float r = (0.22f + 0.95f * h2) * open * (1.0f - climb * 0.55f);
                float y = -0.95f - BASIN_DEPTH * open * (1.0f - climb) + 0.35f * climb;
                float size = (0.045f + 0.040f * h3) * (0.60f + 0.55f * climb);
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size, size, size,
                        mix(SPRAY, WHITE, climb * 0.70f),
                        opaque(a * basinLife * (0.30f + 0.55f * climb)));
            }
        }

        // ============================ v1.3 — L'INTÉRIEUR DU TROU ============================
        // Reproche de la partie d'essai : « on voit bien le trou, mais ça manque gravement de
        // particules à l'intérieur, on voit juste le mob fly ». Les cinq anneaux d'origine ne
        // dessinaient qu'un fil de fer : entre eux, le vide. Les trois blocs qui suivent
        // remplissent le VOLUME de l'entonnoir, puis détaillent son cœur à plusieurs échelles.

        // ---- 9. PAROI CONIQUE PLEINE : le nombre de dalles suit la circonférence ----
        // Reproche de la partie du 13 novembre : « le centre du maelström est toujours mal
        // rempli, je ne vois que des petits pixels dedans ainsi que des mini textures de
        // blocs », « les surfaces ne sont pas remplies de bleu tournoyant abysses ».
        //
        // Cause mesurée : la paroi était faite de 11 hélices, nombre FIXE quelle que soit la
        // profondeur. Or au bord la circonférence vaut 2π × 4,35 = 27,3 m : onze dalles de
        // 0,70 m n'en couvrent que 28 %. Les 72 % restants étaient des trous, à travers
        // lesquels on voyait le sol et les blocs avalés — d'où « des petits pixels et des
        // mini textures de blocs » au lieu d'une masse d'eau.
        //
        // Correctif : on ne raisonne plus en nombre d'hélices mais en TAUX DE RECOUVREMENT.
        // À chaque profondeur, le nombre de dalles est calculé pour que la circonférence soit
        // couverte avec 28 % de chevauchement, et les dalles sont nettement plus larges.
        if (basinLife > 0.02f) {
            final int rings = 30;
            for (int ring = 0; ring < rings; ring++) {
                float v = ring / (float) (rings - 1);                   // 0 bord .. 1 gorge
                // RAYON NORMALISÉ, VOLONTAIREMENT SANS `open` : en v1.6 l'emprise entière était
                // multipliée par `open`, si bien qu'au tick 10 la paroi ne mesurait qu'un mètre
                // alors que GhostBlockMask avait déjà effacé le sol jusqu'à 3,4 m. D'où le
                // cratère nu. Désormais le disque couvre le trou dès le premier tick et c'est
                // la PROFONDEUR, elle seule, qui s'enfonce avec `open`.
                float rr = 1.0f - v * 0.86f;
                float radius = BASIN_RADIUS * rr
                        * (1.0f - implode * (0.22f + 0.74f * v))
                        * (0.96f + 0.07f * Mth.sin(v * 9.0f + t * 12.0f));
                if (radius < 0.05f) continue;
                // PROFIL PARABOLOÏDE, copie conforme de ce que creuse GhostBlockMask.digFunnel
                // (depth = BASIN_DEPTH × (1 − ratio²)). L'ancien cône `-0.95 - BASIN_DEPTH·v²`
                // passait JUSQU'À 45 cm AU-DESSUS du fond réel sur toute la couronne médiane :
                // la paroi flottait et on voyait la terre dessous. Le terme `0.70 × (1 − rr)`
                // ajoute un débord sous le fond pour absorber l'arrondi en couches entières.
                float sink = BASIN_DEPTH * (1.0f - rr * rr) + 0.70f * (1.0f - rr);
                float y0 = -0.18f - sink * open;                        // -0,18 : arase du sol
                float size = 0.280f - 0.140f * v;                       // large dalle .. écaille
                float tang = size * 1.35f;                              // demi-largeur tangentielle
                // Couverture : circonférence / (largeur × 0,72) ⇒ les dalles se chevauchent.
                int count = Math.max(9, Math.round(TAU * radius / (tang * 2.0f * 0.72f)));
                // L'enroulement s'accélère vers le fond : c'est le différentiel qui fait
                // « tourbillon » plutôt que « pile d'anneaux ».
                float spin = spinPhase * (1.0f + v * 2.40f) + v * TAU * 1.60f;
                // Tangente du paraboloïde : raide au bord, presque plate dans la gorge —
                // l'exact inverse de l'ancien cône, qui inclinait les dalles à contresens.
                float slope = -(0.18f + 0.82f * rr * open);
                for (int i = 0; i < count; i++) {
                    float h = hash(salt, 11100 + ring * 173 + i * 29);
                    float ang = i * TAU / count + spin;
                    float r = radius * (0.985f + 0.030f * h);
                    float y = y0 + 0.06f * Mth.sin(v * 16.0f + t * 13.0f + i * 0.7f) + 0.03f * h;
                    // Du bleu clair en surface jusqu'aux abîmes dans la gorge.
                    int rgb = mix(mix(AZURE, OCEAN, v * 0.85f), ABYSS, v * v * 0.80f);
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size * 0.95f, size * 0.44f, tang,
                            ang, slope, 0.0f, rgb,
                            opaque(a * basinLife * (0.74f + 0.24f * (1.0f - v))));
                }
            }
        }

        // ---- 10. VOLUME INTÉRIEUR : des lames larges, plus des poussières ----
        // Les 200 gouttes de 0,08 m d'origine étaient exactement les « petits pixels »
        // reprochés : trop fines pour lire comme de l'eau. On les remplace par 120 lames
        // tangentielles bien plus larges, réparties dans le volume du cône.
        if (basinLife > 0.02f && open > 0.05f) {
            for (int i = 0; i < 120; i++) {
                float h = hash(salt, 12000 + i * 37);
                float h2 = hash(salt, 12200 + i * 53);
                float h3 = hash(salt, 12400 + i * 19);
                float v = h;                                            // profondeur relative
                float wall = BASIN_RADIUS * (1.0f - v * 0.86f) * open
                        * (1.0f - implode * (0.22f + 0.74f * v));
                if (wall < 0.08f) continue;
                // sqrt : répartition homogène en surface, sinon tout s'entasse sur l'axe.
                float r = wall * (float) Math.sqrt(h2) * 0.92f;
                float ang = h3 * TAU + spinPhase * (1.0f + v * 2.40f) * (0.80f + 0.40f * h2);
                float y = -0.95f - BASIN_DEPTH * v * v * open
                        + 0.20f * Mth.sin(t * 15.0f + h3 * 9.0f);
                float size = (0.150f + 0.110f * h2) * (1.0f - 0.30f * v);
                int rgb = mix(mix(SHALLOW, OCEAN, v * 0.70f), AZURE, h3 * 0.55f);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 0.80f, size * 0.52f, size * 1.45f,
                        ang, -(0.30f + 0.70f * v), 0.0f, rgb,
                        opaque(a * basinLife * (0.62f + 0.30f * (1.0f - v))));
            }
        }

        // ---- 11. LE CŒUR, À TROIS ÉCHELLES ----
        // Demande explicite : « détaille à mort le cœur du maelström, avec des cubes de
        // différentes tailles, je veux que ça soit ultra compréhensible ». La lisibilité vient
        // du CONTRASTE d'échelle : on superpose trois tailles très séparées (0,34 / 0,155 /
        // 0,055) tournant à trois vitesses différentes, plus un œil noir immobile au centre.
        if (basinLife > 0.02f && open > 0.06f) {
            float core = open * (1.0f - implode * 0.55f);
            float floorY = -0.95f - BASIN_DEPTH * open;

            // (a) Six GROSSES dalles, lentes, qui tournent au fond : elles donnent l'échelle.
            for (int i = 0; i < 12; i++) {
                float h = hash(salt, 13000 + i * 101);
                float ang = i * TAU / 12.0f + spinPhase * 1.70f;
                float r = (0.52f + 0.30f * h) * core;
                float y = floorY + 0.28f + 0.16f * Mth.sin(t * 9.0f + i * 1.7f);
                float size = 0.44f * (0.85f + 0.30f * h);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 1.45f, size * 0.50f, size * 1.05f,
                        ang, -0.85f, 0.0f,
                        mix(DEEP, OCEAN, h * 0.55f),
                        opaque(a * basinLife * 0.90f));
            }

            // (b) Vingt-quatre blocs MOYENS en double hélice serrée autour de l'axe.
            for (int i = 0; i < 40; i++) {
                float h = hash(salt, 13200 + i * 59);
                float v = i / 39.0f;
                float ang = v * TAU * 2.40f + spinPhase * 3.10f + (i % 2) * 3.1416f;
                float r = (0.20f + 0.46f * (1.0f - v)) * core;
                float y = floorY + 0.10f + v * (1.45f * core)
                        + 0.07f * Mth.sin(t * 17.0f + i);
                float size = 0.230f * (0.80f + 0.45f * h);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 1.30f, size * 0.85f, size * 1.30f,
                        ang, -0.55f, 0.0f,
                        mix(OCEAN, SHALLOW, v * 0.70f),
                        opaque(a * basinLife * (0.88f - 0.20f * v)));
            }

            // (c) Quatre-vingt-dix ÉCLATS minuscules et rapides : la poussière d'eau du cœur.
            for (int i = 0; i < 54; i++) {
                float h = hash(salt, 13500 + i * 23);
                float h2 = hash(salt, 13700 + i * 41);
                float h3 = hash(salt, 13900 + i * 13);
                float spin2 = spinPhase * (4.20f + 2.60f * h2);
                float ang = h * TAU + spin2;
                float r = (0.10f + 0.72f * h2) * core;
                float y = floorY + 0.05f + h3 * (1.90f * core)
                        + 0.10f * Mth.sin(t * 26.0f + h * 11.0f);
                float size = 0.115f * (0.70f + 0.60f * h3);
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size, size * 1.45f, size,
                        mix(SPRAY, WHITE, h3 * 0.75f),
                        opaque(a * basinLife * (0.60f + 0.35f * h2)));
            }

            // (d) L'ŒIL : noyau noir presque immobile, qui pulse. Sans lui le centre « bave » ;
            // avec lui on lit instantanément où est le fond de l'entonnoir.
            float eye = 0.30f * core * (0.90f + 0.14f * Mth.sin(t * 20.0f));
            for (int i = 0; i < 16; i++) {
                float h = hash(salt, 14100 + i * 71);
                float ang = i * TAU / 16.0f + spinPhase * 0.90f;
                float lift = (i % 2 == 0) ? 0.0f : 0.14f;
                float size = 0.150f * (0.85f + 0.30f * h);
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * eye, Mth.sin(ang) * eye, floorY + 0.08f + lift,
                        size, size * 1.20f, size,
                        mix(ABYSS, DEEP, h * 0.30f),
                        opaque(a * basinLife * 0.96f));
            }
        }

        // ================== v1.5c — 12. NAPPE DE FERMETURE (le trou ne doit JAMAIS être nu) =====
        // Partie d'essai du 13 novembre 2026 : « c'est encore pire qu'avant », puis la cause
        // réelle, donnée par le joueur : « les blocs pixels trop transparents n'apparaissent pas
        // du tout en jeu ». Vérification faite dans le moteur, emitVoxelCube / emitVoxelBoxRotated :
        //
        //     if (pixelDensity < 0.999f && alpha < 200) { ... return; }        // T350-VFX-VARIATIONS
        //
        // et pixelDensity vaut 0,30 à 0,70 selon la déclinaison (WeaponVfxVariant : 0,70 - 0,40 f).
        // Autrement dit : SOUS alpha 200, le moteur jette aléatoirement 30 à 70 % des cubes.
        // La nappe v1.5b à 0,42 d'opacité (alpha ≈ 107) était donc effacée aux deux tiers — d'où
        // le « pire qu'avant ». Le même piège frappait déjà le bassin lui-même : son alpha est
        // multiplié par basinLife, si bien qu'à partir de basinLife ≈ 0,85 le tourbillon ne
        // s'estompait pas, il se DÉSINTÉGRAIT en confettis clairsemés avant de disparaître.
        //
        // Règle retenue pour toute l'animation (cf. opaque()) : on ne fait JAMAIS disparaître
        // quelque chose par fondu d'alpha, on le fait disparaître par la GÉOMÉTRIE. Tout cube
        // encore vivant est émis au-dessus du seuil ; la transparence visuelle de l'eau est
        // rendue ensuite par le voile de matière (cubeVeil = 0,62 pour WATER), appliqué APRÈS
        // le tamis — la nappe est donc à la fois réellement dessinée et translucide à l'œil.
        //
        // Chronologie (150 ticks) : la nappe est PLEINE au tick 0 puis s'ouvre 0,00 → 0,20 au
        // rythme du masque ; l'iris se referme 0,50 → 0,72 (tick 75 → 108) ; le sol fantôme
        // revient au tick 129 au plus tard (digFunnel closeAt 118 + 4,35 × 2,6) ; la nappe se
        // résorbe enfin en se ROUVRANT 0,90 → 0,97. Le joueur ne voit jamais la terre à nu.
        float sealGrow = smooth((t - 0.50f) / 0.22f);              // iris : se ferme 0,50 → 0,72
        float sealBack = smooth((t - 0.90f) / 0.07f);              // puis se rouvre 0,90 → 0,97
        {
            // Rayon intérieur. Trois régimes enchaînés par un simple min/max :
            //   • 0,00 → 0,20  `open` écarte la nappe depuis l'axe  → le trou s'OUVRE ;
            //   • 0,50 → 0,72  `1 - sealGrow` la ramène vers l'axe  → le trou se REFERME ;
            //   • 0,90 → 0,97  `sealBack` la rouvre pour la résorption finale.
            // Le facteur `open` est la correction de v1.7 : en v1.6 la nappe n'existait qu'à
            // partir de t = 0,50 (tick 75), si bien que pendant tout le creusement rien ne
            // couvrait la couronne entre la gorge et le bord — c'est le trou que le joueur
            // voyait. Elle est maintenant PLEINE au tick 0 et s'ouvre au rythme exact du
            // masque, donc le sol effacé est couvert à chaque instant.
            float innerR = BASIN_RADIUS * Math.min(open, Math.max(1.0f - sealGrow, sealBack));
            // Rayon extérieur : épouse la largeur réellement creusée (digFunnel : 4,35) et se
            // rétracte à la toute fin, si bien que la nappe meurt sans le moindre fondu.
            float outerR = BASIN_RADIUS * Math.max(open, 0.92f) * (1.0f - 0.82f * sealBack);
            int rings = 11;
            for (int ring = 0; ring < rings && innerR < outerR; ring++) {
                float rk = (ring + 0.5f) / rings;
                float r = outerR * rk;
                if (r < innerR - 0.22f) continue;                  // encore ouvert ici
                // La lèvre ne pilote plus l'opacité (interdit) mais la TEINTE et le relief :
                // l'écume se concentre sur le front qui se referme.
                float lip = Math.max(sealGrow * sealGrow,
                        Mth.clamp((r - innerR) / 0.55f, 0.0f, 1.0f));
                int count = Math.max(7, Math.round(r * 13.0f));
                for (int i = 0; i < count; i++) {
                    float h = hash(salt, 14500 + ring * 149 + i * 31);
                    float ang = i * TAU / count + ring * 0.31f + spinPhase * 0.22f;
                    // Houle résiduelle : la surface n'est pas un disque plat et mort.
                    float y = -0.98f + 0.085f * Mth.sin(ang * 3.0f + t * 7.0f + rk * 5.0f)
                            + 0.045f * Mth.sin(rk * 11.0f - t * 9.0f) + 0.03f * h;
                    float size = 0.225f * (0.86f + 0.26f * h);
                    // Teinte : azur au centre (l'eau y est encore profonde), bas-fond au bord.
                    int rgb = mix(mix(SHALLOW, AZURE, 1.0f - rk), FOAM, lip * 0.18f + h * 0.12f);
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size * 1.95f, size * 0.46f, size * 1.60f,
                            ang, 0.0f, 0.0f, rgb, opaque(a));
                }
            }
            // Bourrelet d'écume sur la lèvre de l'iris : marque le front qui se referme.
            if (innerR > 0.25f && innerR < outerR) {
                int count = Math.max(10, Math.round(innerR * 15.0f));
                for (int i = 0; i < count; i++) {
                    float h = hash(salt, 14900 + i * 53);
                    float ang = i * TAU / count + spinPhase * 1.25f;
                    float r = innerR * (0.98f + 0.07f * Mth.sin(ang * 4.0f + t * 12.0f));
                    float y = -0.93f + 0.10f * Mth.sin(ang * 5.0f - t * 13.0f) + 0.04f * h;
                    float size = 0.105f * (0.80f + 0.50f * h);
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                            size * 1.50f, size * 0.80f, size * 1.10f,
                            ang, -0.30f, 0.0f, mix(FOAM, WHITE, h * 0.60f), opaque(a));
                }
            }
        }
    }

    // ============================================================================================
    // 3. GIVRE DU PERMAFROST — étoile de gel, pics, prison de glace, éclatement
    // ============================================================================================

    /**
     * Alpha minimal réellement dessiné par le moteur quand une déclinaison allégée est tirée
     * ({@code pixelDensity} 0,30 à 0,70). Le tamis du manager compare à 200 ; on prend une
     * petite marge au-dessus.
     */
    private static final int SOLID_FLOOR = 208;

    /** Hauteur du plus grand pic de glace, en blocs. */
    private static final float SPIKE_HEIGHT = 3.20f;
    /** Nombre de pics de la couronne. */
    private static final int SPIKE_COUNT = 9;

    /**
     * Chorégraphie (120 ticks) :
     * <ul>
     *   <li>0,00–0,22 <b>étoile de gel</b> : huit branches de givre courent au sol en craquelant ;</li>
     *   <li>0,10–0,46 <b>pics</b> : neuf pics percent le sol en couronne, trois gros sous la cible ;</li>
     *   <li>0,30–0,66 <b>prison</b> : un bloc de glace translucide se referme sur la cible ;</li>
     *   <li>0,60–0,80 <b>fissures</b> : des veines sombres courent dans le bloc, qui tremble ;</li>
     *   <li>0,78–1,00 <b>éclatement</b> : soixante éclats partent en tournant, les pics s'effondrent.</li>
     * </ul>
     */
    private static void renderRime(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                   float cx, float cy, float cz, float t,
                                   float dx, float dz, int alpha, int salt) {
        int a = Math.round(alpha * smooth(t / 0.04f) * (1.0f - smooth((t - 0.92f) / 0.08f)));
        if (a <= 4) return;

        float creep = smooth(t / 0.22f);
        float grow = smooth((t - 0.10f) / 0.36f);
        float cage = smooth((t - 0.30f) / 0.36f);
        float crack = smooth((t - 0.60f) / 0.20f);
        float shatter = smooth((t - 0.78f) / 0.14f);
        float solid = 1.0f - shatter;

        // ---- 1. Étoile de givre : huit branches qui courent au sol, avec ramifications ----
        for (int branch = 0; branch < 8; branch++) {
            float base = branch * TAU / 8.0f + hash(salt, 11000 + branch) * 0.35f;
            int segs = 16;
            for (int s = 0; s < segs; s++) {
                float v = (s + 1) / (float) segs;
                float local = Mth.clamp((creep - v * 0.55f) / 0.45f, 0.0f, 1.0f);
                if (local <= 0.0f) continue;
                float h = hash(salt, 11100 + branch * 97 + s * 11);
                float ang = base + (h - 0.5f) * 0.30f * v;
                float r = v * 4.60f * local;
                float y = -1.15f + 0.02f * h;
                float size = (0.115f - 0.055f * v) * (0.80f + 0.40f * h);
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 1.30f, 0.032f + 0.022f * h, size * 1.30f,
                        mix(ICE_PALE, FROST, h), opaque(a * local * (0.92f - 0.30f * v) * solid));
                // Ramification : une épine latérale un segment sur trois.
                if (s % 3 == 2 && h > 0.35f) {
                    float side = (hash(salt, 11200 + branch * 31 + s) - 0.5f) > 0.0f ? 1.0f : -1.0f;
                    float sAng = ang + side * 0.62f;
                    float sr = r * 0.82f;
                    float len = 0.42f * (1.0f - v) * local;
                    box(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(sAng) * (sr + len), Mth.sin(sAng) * (sr + len), y,
                            0.070f, 0.028f, 0.070f,
                            mix(ICE, ICE_PALE, h), opaque(a * local * 0.70f * solid));
                }
            }
        }

        // ---- 2. Couronne de pics : neuf aiguilles inclinées vers l'extérieur ----
        for (int p = 0; p < SPIKE_COUNT; p++) {
            float h = hash(salt, 11400 + p * 53);
            float h2 = hash(salt, 11500 + p * 29);
            float ang = p * TAU / SPIKE_COUNT + (h - 0.5f) * 0.25f;
            float radius = 1.70f + 1.05f * h2;
            float spikeH = SPIKE_HEIGHT * (0.52f + 0.48f * h) * grow * (1.0f - shatter * 0.85f);
            if (spikeH < 0.10f) continue;
            int steps = Math.max(4, Mth.floor(spikeH / 0.26f));
            float tilt = 0.16f + 0.22f * h2;
            for (int s = 0; s < steps; s++) {
                float v = (s + 0.5f) / steps;
                float y = -1.15f + spikeH * v;
                float lean = tilt * v * v * 1.30f;
                float r = radius + lean;
                float half = (0.205f - 0.165f * v) * (0.85f + 0.30f * h);
                int rgb = mix(mix(ICE_DEEP, ICE, v), FROST, v * v * 0.70f);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        half * 1.20f, spikeH / steps * 0.62f, half * 1.20f,
                        ang, tilt * v, (h2 - 0.5f) * 0.40f, rgb,
                        opaque(a * (0.70f + 0.28f * v) * (1.0f - shatter * 0.70f)));
            }
        }
        // Trois pics majeurs sous la cible : ils l'encadrent au lieu de la traverser.
        for (int p = 0; p < 3; p++) {
            float h = hash(salt, 11700 + p * 71);
            float ang = p * TAU / 3.0f + 0.4f;
            float spikeH = (2.05f + 0.75f * h) * grow * (1.0f - shatter * 0.80f);
            int steps = Math.max(5, Mth.floor(spikeH / 0.24f));
            for (int s = 0; s < steps; s++) {
                float v = (s + 0.5f) / steps;
                float y = -1.15f + spikeH * v;
                float r = 0.86f + v * 0.30f;
                float half = (0.235f - 0.185f * v) * (0.90f + 0.20f * h);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        half * 1.25f, spikeH / steps * 0.60f, half * 1.25f,
                        ang, 0.24f * v, 0.0f, mix(ICE, FROST, v * 0.80f),
                        opaque(a * (0.72f + 0.26f * v) * (1.0f - shatter * 0.70f)));
            }
        }

        // ---- 3. Prison de glace : coque translucide autour de la cible, arêtes plus denses ----
        if (cage > 0.02f && solid > 0.02f) {
            float shell = 0.92f * cage;
            float shiver = crack * 0.045f * Mth.sin(t * 52.0f);
            for (int layer = 0; layer < 3; layer++) {
                float lv = layer / 2.0f;
                float r = shell * (0.62f + 0.38f * lv);
                int count = 18 - layer * 3;
                for (int i = 0; i < count; i++) {
                    float h = hash(salt, 11900 + layer * 101 + i * 13);
                    float ang = i * TAU / count + lv * 0.4f + shiver;
                    for (int level = 0; level < 4; level++) {
                        float ly = -0.95f + level * 0.52f;
                        float squeeze = 1.0f - Math.abs(level - 1.5f) * 0.18f;
                        float size = (0.165f + 0.055f * h) * squeeze;
                        box(vc, mat, tmp, cx, cy, cz, dx, dz,
                                Mth.cos(ang) * r * squeeze, Mth.sin(ang) * r * squeeze,
                                ly + shiver * 0.5f,
                                size, size * 1.05f, size,
                                mix(ICE, ICE_PALE, h * 0.70f),
                                opaque(a * cage * solid * (0.38f + 0.22f * lv)));
                    }
                }
            }
            // Veines de fracture : lignes sombres qui apparaissent à partir de 0,60.
            if (crack > 0.03f) {
                for (int i = 0; i < 22; i++) {
                    float h = hash(salt, 12100 + i * 37);
                    float h2 = hash(salt, 12200 + i * 17);
                    if (h > crack) continue;
                    float ang = h2 * TAU;
                    float ly = -0.90f + h * 2.05f;
                    float r = shell * (0.58f + 0.40f * h2);
                    rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                            Mth.cos(ang) * r, Mth.sin(ang) * r, ly,
                            0.028f, 0.165f + 0.120f * h2, 0.028f,
                            ang, (h2 - 0.5f) * 1.6f, (h - 0.5f) * 1.2f,
                            mix(ICE_DEEP, ABYSS, 0.45f), opaque(a * crack * solid * 0.85f));
                }
            }
        }

        // ---- 4. Éclatement : soixante éclats partent en tournant, puis retombent ----
        if (shatter > 0.01f) {
            for (int i = 0; i < 60; i++) {
                float h = hash(salt, 12400 + i * 19);
                float h2 = hash(salt, 12500 + i * 29);
                float h3 = hash(salt, 12600 + i * 7);
                float ang = h2 * TAU;
                float speed = 1.40f + 3.20f * h;
                float r = shatter * speed;
                float y = -0.70f + h3 * 1.70f + shatter * (1.70f + 1.10f * h2)
                        - shatter * shatter * (3.40f + 2.10f * h);
                if (y < -1.16f) continue;
                float size = (0.085f + 0.075f * h3) * (1.0f - shatter * 0.42f);
                float spin = shatter * (7.0f + 9.0f * h2);
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 1.30f, size * 0.70f, size,
                        ang + spin, spin * 0.75f, spin * 0.55f,
                        mix(mix(ICE, ICE_PALE, h3), FROST, h2 * 0.55f),
                        opaque(a * (1.0f - shatter * 0.72f)));
            }
            // Souffle de froid au sol : un anneau plat qui s'échappe de l'éclatement.
            for (int i = 0; i < 34; i++) {
                float h = hash(salt, 12800 + i * 11);
                float ang = i * TAU / 34.0f;
                float r = 0.80f + shatter * (4.40f + 1.10f * h);
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, -1.14f + 0.03f * h,
                        0.115f, 0.030f, 0.115f,
                        mix(FROST, WHITE, h), opaque(a * (1.0f - shatter) * 0.80f));
            }
        }

        // 5. BRUME DE FROID — nappe basse qui rampe au sol pendant toute la durée.
        // Elle recouvre la jonction entre le terrain réel et le sol gelé à l'écran
        // (blocs fantômes, voir GhostBlockMask) : sans elle on verrait la découpe du disque.
        if (creep > 0.03f) {
            float haze = creep * (1.0f - shatter * 0.55f);
            for (int i = 0; i < 46; i++) {
                float h = hash(salt, 13000 + i * 31);
                float h2 = hash(salt, 13100 + i * 17);
                float h3 = hash(salt, 13200 + i * 53);
                float drift = fract(t * (0.10f + 0.09f * h3) + h);
                float ang = h2 * TAU + drift * 0.85f;
                float r = (0.70f + 3.80f * h) * creep;
                float y = -1.14f + 0.10f * h3 + 0.05f * Mth.sin(t * 4.0f + h * 9.0f);
                float size = 0.16f + 0.14f * h3;
                box(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(ang) * r, Mth.sin(ang) * r, y,
                        size * 1.45f, 0.030f + 0.022f * h2, size * 1.45f,
                        mix(ICE_PALE, FROST, h2),
                        opaque(a * haze * (0.26f - 0.10f * (r / 4.50f))));
            }
        }

        // 6. CRISTAUX EN SUSPENSION — de la glace qui flotte et tourne lentement autour de la
        // prison. C'est ce qui distingue un bloc de glace posé là d'un sort de givre actif.
        if (cage > 0.04f && solid > 0.04f) {
            for (int i = 0; i < 26; i++) {
                float h = hash(salt, 13400 + i * 37);
                float h2 = hash(salt, 13500 + i * 23);
                float h3 = hash(salt, 13600 + i * 11);
                float orbit = t * (0.55f + 0.70f * h3) + h2 * TAU;
                float r = 1.05f + 1.45f * h;
                float y = -0.85f + 1.90f * h2 + 0.14f * Mth.sin(t * 3.4f + h * 7.0f);
                float size = 0.045f + 0.055f * h3;
                rot(vc, mat, tmp, cx, cy, cz, dx, dz,
                        Mth.cos(orbit) * r, Mth.sin(orbit) * r, y,
                        size, size * 1.70f, size,
                        orbit, t * 1.8f + h * 6.0f, h2 * 3.0f,
                        mix(ICE, FROST, h3), opaque(a * cage * solid * (0.45f + 0.35f * h)));
            }
        }
    }

    // ============================================================================================
    // Boîte à outils (mêmes conventions que WindSignatureVfx : avant / latéral / hauteur)
    // ============================================================================================

    /**
     * Plancher d'opacité imposé par le moteur de rendu.
     *
     * <p>{@code WeaponWorldVfxManager.emitVoxelCube} et {@code emitVoxelBoxRotated} contiennent
     * un tamis d'allègement (T350) :</p>
     *
     * <pre>if (pixelDensity &lt; 0.999f &amp;&amp; alpha &lt; 200) { ... return; }</pre>
     *
     * <p>Comme {@code pixelDensity} vaut 0,30 à 0,70 suivant la déclinaison tirée, tout cube
     * émis sous alpha 200 a 30 à 70 % de chances d'être purement et simplement jeté. En jeu
     * cela se traduit par « les blocs pixels trop transparents n'apparaissent pas du tout »
     * (retour du 13 novembre 2026) : un fondu d'alpha ne produit pas un estompage mais une
     * désintégration en confettis, puis le vide.</p>
     *
     * <p>Cette méthode verrouille donc l'opacité au-dessus du tamis : un cube est soit absent,
     * soit franchement dessiné. La translucidité de l'eau n'est pas perdue pour autant, elle
     * est appliquée APRÈS le tamis par le voile de matière ({@code cubeVeil = 0,62} pour
     * {@code WATER}), ce qui ramène un cube à 255 vers 158 à l'écran.</p>
     *
     * <p>Corollaire de conception : dans cette animation, rien ne disparaît par fondu — tout
     * disparaît par la géométrie (rayon, hauteur, nombre de cubes).</p>
     *
     * @param v alpha souhaité, avant verrouillage
     * @return 0 si le cube ne doit plus exister, sinon un alpha garanti ≥ {@value #SOLID_FLOOR}
     */
    private static int opaque(float v) {
        int i = Math.round(v);
        if (i <= 10) return 0;                 // réellement mort : on n'émet rien
        return i < SOLID_FLOOR ? SOLID_FLOOR : Math.min(255, i);
    }

    /** Cube aligné : {@code f} = axe attaquant→cible, {@code lateral} = perpendiculaire, {@code y} = hauteur. */
    private static void box(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                            float cx, float cy, float cz, float dx, float dz,
                            float f, float lateral, float y,
                            float hf, float hy, float hl, int rgb, int alpha) {
        if (alpha <= 0 || hf <= 0.0f || hy <= 0.0f || hl <= 0.0f) return;
        float x = cx + dx * f - dz * lateral;
        float z = cz + dz * f + dx * lateral;
        WeaponWorldVfxManager.emitVoxelCube(vc, mat, tmp, x, cy + y, z, hf, hy, hl, rgb, alpha);
    }

    /** Cube orienté (lacet, tangage, roulis) dans le même repère que {@link #box}. */
    private static void rot(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                            float cx, float cy, float cz, float dx, float dz,
                            float f, float lateral, float y,
                            float hf, float hy, float hl,
                            float yaw, float pitch, float roll, int rgb, int alpha) {
        if (alpha <= 0 || hf <= 0.0f || hy <= 0.0f || hl <= 0.0f) return;
        float x = cx + dx * f - dz * lateral;
        float z = cz + dz * f + dx * lateral;
        WeaponWorldVfxManager.emitVoxelBoxRotated(vc, mat, tmp, x, cy + y, z,
                hf, hy, hl, yaw, pitch, roll, rgb, alpha);
    }

    private static int mix(int dark, int light, float u) {
        return WeaponWorldVfxManager.mixRgb(dark, light, clamp(u));
    }

    private static float clamp(float value) { return Mth.clamp(value, 0.0f, 1.0f); }

    /** Partie fractionnaire positive — sert aux cycles qui se rejouent (ruissellement, bulles). */
    private static float fract(float x) {
        return x - (float) Math.floor(x);
    }

    private static float smooth(float x) {
        x = clamp(x);
        return x * x * (3.0f - 2.0f * x);
    }

    private static float hash(int seed, int n) {
        int h = seed ^ (n * 0x45D9F3B);
        h ^= h >>> 16;
        h *= 0x45D9F3B;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535.0f;
    }
}
