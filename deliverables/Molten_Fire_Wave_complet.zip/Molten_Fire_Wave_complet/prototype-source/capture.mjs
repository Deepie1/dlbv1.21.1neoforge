import chromiumPack from '@sparticuz/chromium';
import { chromium } from 'playwright-core';
import fs from 'node:fs/promises';

const quick = process.argv.includes('--quick');
await fs.mkdir('renders', {recursive:true});
if (!quick) await fs.mkdir('renders/frames', {recursive:true});
chromiumPack.setGraphicsMode = true;
const executablePath = await chromiumPack.executablePath();
const browser = await chromium.launch({
  executablePath,
  headless: true,
  args: [...chromiumPack.args, '--enable-webgl', '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader', '--use-angle=swiftshader']
});
const page = await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
const errors=[];
page.on('pageerror',e=>errors.push(String(e)));
page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto('http://127.0.0.1:8080/?t=0.58&clean=1', {waitUntil:'networkidle'});
await page.waitForFunction(()=>window.previewReady===true,{timeout:60000});
await page.evaluate(()=>window.renderAt(.58));
await page.locator('#scene').screenshot({path:'renders/hero.png'});
await page.screenshot({path:'renders/main-preview.png'});
const report={hero:await page.evaluate(()=>window.getDiagnostics()),stages:[],frames:[]};
console.log('DIAGNOSTICS',JSON.stringify(report.hero));
console.log('ERRORS',JSON.stringify(errors));
if(errors.length) throw new Error(errors.join('\n'));
if(!quick){
  for(const [name,t] of [['01-emergence',.12],['02-montee',.38],['03-crete',.58],['04-enfoncement',.86]]){
    await page.evaluate(t=>window.renderAt(t),t);
    await page.locator('#scene').screenshot({path:`renders/${name}.png`});
    report.stages.push({name,...await page.evaluate(()=>window.getDiagnostics())});
  }
  await page.addStyleTag({content:'#panel{display:none!important}.shell{grid-template-columns:1fr!important}.stage-badge,.orbit-hint{display:none!important}'});
  await page.setViewportSize({width:360,height:360});
  await page.evaluate(()=>window.renderAt(.58));
  await page.locator('#scene').screenshot({path:'renders/thumbnail.png'});
  await page.setViewportSize({width:640,height:640});
  for(let i=0;i<42;i++){
    const t=i/41;
    await page.evaluate(t=>window.renderAt(t),t);
    await page.locator('#scene').screenshot({path:`renders/frames/frame-${String(i).padStart(3,'0')}.png`});
    report.frames.push(await page.evaluate(()=>window.getDiagnostics()));
  }
  await fs.writeFile('renders/diagnostics.json',JSON.stringify(report,null,2));
  const maxVoxels=Math.max(...report.frames.map(f=>f.waveVoxels));
  console.log('FRAME_AUDIT',JSON.stringify({frames:report.frames.length,maxVoxels,overBudget:report.frames.filter(f=>f.waveVoxels>1100).length}));
}
await browser.close();
