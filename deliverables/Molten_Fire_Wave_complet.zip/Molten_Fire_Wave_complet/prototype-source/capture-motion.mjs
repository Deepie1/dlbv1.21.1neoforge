import chromiumPack from '@sparticuz/chromium';
import { chromium } from 'playwright-core';
import fs from 'node:fs/promises';
chromiumPack.setGraphicsMode=true;
const browser=await chromium.launch({executablePath:await chromiumPack.executablePath(),headless:true,args:[...chromiumPack.args,'--enable-webgl','--ignore-gpu-blocklist','--enable-unsafe-swiftshader','--use-angle=swiftshader']});
const page=await browser.newPage({viewport:{width:360,height:360},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto('http://127.0.0.1:8080/?t=.58&clean=1',{waitUntil:'networkidle'});
await page.waitForFunction(()=>window.previewReady===true,{timeout:60000});
await page.addStyleTag({content:'#panel{display:none!important}.shell{grid-template-columns:1fr!important}.stage-badge,.orbit-hint{display:none!important}'});
await page.evaluate(()=>window.renderAt(.58));
await page.locator('#scene').screenshot({path:'renders/thumbnail.png'});
await page.setViewportSize({width:640,height:640});
const frames=[];
for(let i=0;i<42;i++){
 const t=(i/41)*.995;await page.evaluate(t=>window.renderAt(t),t);
 await page.locator('#scene').screenshot({path:`renders/frames/frame-${String(i).padStart(3,'0')}.png`});
 frames.push(await page.evaluate(()=>window.getDiagnostics()));
}
await fs.writeFile('renders/motion-diagnostics.json',JSON.stringify(frames,null,2));
console.log('FRAME_AUDIT',JSON.stringify({frames:frames.length,maxVoxels:Math.max(...frames.map(f=>f.waveVoxels)),overBudget:frames.filter(f=>f.waveVoxels>1100).length,errors}));
await browser.close();
if(errors.length)throw new Error(errors.join('\n'));
