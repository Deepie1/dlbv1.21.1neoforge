import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

const P = 0xFF4A10, S = 0xB01B00, A = 0xFFE08A;
const SALT = 0x4D4F4C54;
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
const easeOut = t => 1 - (1 - t) * (1 - t);
const mix = (a, b, t) => a + (b - a) * t;
function pixelHash(salt, a) {
  let h = Math.imul(salt, 0x9E3779B1) ^ Math.imul(a, 0x85EBCA77);
  h ^= h >>> 15; h = Math.imul(h, 0x2545F491); h ^= h >>> 13;
  return (h & 0xFFFF) / 65535;
}
function rgb(i) { return [(i >>> 16) & 255, (i >>> 8) & 255, i & 255]; }
function int(c) { return (Math.round(clamp(c[0], 0, 255)) << 16) | (Math.round(clamp(c[1], 0, 255)) << 8) | Math.round(clamp(c[2], 0, 255)); }
function mixRgb(a, b, t) { const x = rgb(a), y = rgb(b); return int(x.map((v, i) => mix(v, y[i], t))); }
function shadeRgb(a, m) { return int(rgb(a).map(v => v * m)); }
function rampRgb(u, deep, body, high, tip) {
  u = clamp(u);
  if (u < .34) return mixRgb(deep, body, u / .34);
  if (u < .68) return mixRgb(body, high, (u - .34) / .34);
  return mixRgb(high, tip, (u - .68) / .32);
}
function jitterRgb(color, salt, amount) {
  const h = Math.imul(salt, 0x9E3779B1);
  const variation = ((((h >>> 3) & 0xFFFF) / 65535) - .5) * 2 * amount;
  return shadeRgb(color, 1 + variation);
}
const DEEP = shadeRgb(mixRgb(S, P, .30), .52);
const HIGH = shadeRgb(mixRgb(P, A, .35), 1.08);

function voxNoise(seed, x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  let fx = x - xi, fy = y - yi, fz = z - zi;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy); fz = fz * fz * (3 - 2 * fz);
  const h = (dx, dy, dz) => pixelHash(seed, Math.imul(xi + dx, 73856093) ^ Math.imul(yi + dy, 19349663) ^ Math.imul(zi + dz, 83492791));
  const x00 = mix(h(0,0,0), h(1,0,0), fx), x10 = mix(h(0,1,0), h(1,1,0), fx);
  const x01 = mix(h(0,0,1), h(1,0,1), fx), x11 = mix(h(0,1,1), h(1,1,1), fx);
  return mix(mix(x00, x10, fy), mix(x01, x11, fy), fz);
}
function segDist2(pz, py, az, ay, bz, by) {
  const vz = bz - az, vy = by - ay, wz = pz - az, wy = py - ay;
  const len = vz * vz + vy * vy;
  const t = len > 1e-9 ? clamp((wz * vz + wy * vy) / len) : 0;
  const cz = az + vz * t, cy = ay + vy * t;
  return Math.hypot(pz - cz, py - cy);
}
function moltenSdf(x, y, z, t) {
  const rise = smooth(t / .48), curl = smooth((t - .24) / .44), collapse = smooth((t - .68) / .32);
  const height = .16 + .84 * rise * (1 - .58 * collapse);
  const crestY = -.78 + 1.62 * height;
  const backZ = .46 - .18 * rise, shoulderZ = .20 - .20 * curl, crestZ = -.12 - .42 * curl;
  const lipZ = crestZ - .32 - .28 * curl;
  const lipY = crestY - (.22 + .60 * curl + .35 * collapse);
  let d = 1e9;
  d = Math.min(d, segDist2(z,y,backZ,-.98,backZ,-.28+.20*rise)-.29);
  d = Math.min(d, segDist2(z,y,backZ,-.28+.20*rise,shoulderZ,crestY-.36)-.25);
  d = Math.min(d, segDist2(z,y,shoulderZ,crestY-.36,crestZ,crestY)-.22);
  d = Math.min(d, segDist2(z,y,crestZ,crestY,lipZ,lipY)-.17);
  d = Math.min(d, segDist2(z,y,lipZ,lipY,lipZ+.08,Math.max(-.92,lipY-.28))-.11);
  d = Math.min(d, Math.max(Math.abs(y+.88)-.15,Math.abs(z-.02)-.64));
  const width = .84 - .16 * clamp((y + 1) * .5);
  d = Math.max(d, Math.abs(x) - width);
  d = Math.max(d, Math.max(y - 1.04, -y - 1.06));
  return d + (voxNoise(SALT, x*4.4, y*4.4, z*4.4) - .5) * .12;
}
function fillSculpt(res, t) {
  const occ = new Uint8Array(res * res * res);
  const at = (i,j,k) => (i * res + j) * res + k;
  for (let i=0;i<res;i++) for (let j=0;j<res;j++) for (let k=0;k<res;k++) {
    const x=-1+(i+.5)*2/res, y=-1+(j+.5)*2/res, z=-1+(k+.5)*2/res;
    occ[at(i,j,k)] = moltenSdf(x,y,z,t) <= 0 ? 1 : 0;
  }
  let skin=0;
  for (let i=0;i<res;i++) for (let j=0;j<res;j++) for (let k=0;k<res;k++) {
    if (!occ[at(i,j,k)]) continue;
    if (i===0||j===0||k===0||i===res-1||j===res-1||k===res-1||
        !occ[at(i-1,j,k)]||!occ[at(i+1,j,k)]||!occ[at(i,j-1,k)]||!occ[at(i,j+1,k)]||!occ[at(i,j,k-1)]||!occ[at(i,j,k+1)]) skin++;
  }
  return {occ,skin,at};
}

const canvas = document.querySelector('#scene');
const stage = document.querySelector('#stage');
const renderer = new THREE.WebGLRenderer({canvas, antialias:true, preserveDrawingBuffer:true, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.28;
renderer.info.autoReset = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x09090d);
scene.fog = new THREE.Fog(0x09090d, 8, 18);
const camera = new THREE.PerspectiveCamera(38, 1, .05, 60);
const heroCamera = new THREE.Vector3(6.4, 2.15, -3.1);
const heroTarget = new THREE.Vector3(0, .05, -.35);
camera.position.copy(heroCamera);
const controls = new OrbitControls(camera, canvas);
controls.target.copy(heroTarget); controls.enableDamping = true; controls.dampingFactor = .065;
controls.minDistance = 3.2; controls.maxDistance = 12; controls.maxPolarAngle = Math.PI * .49;
controls.update();

scene.add(new THREE.HemisphereLight(0x6c6170, 0x170604, .65));
const key = new THREE.DirectionalLight(0xffd1a1, 3.4);
key.position.set(-3,6,-4); key.castShadow = true;
key.shadow.mapSize.set(1024,1024); key.shadow.camera.left=-5; key.shadow.camera.right=5; key.shadow.camera.top=5; key.shadow.camera.bottom=-5;
scene.add(key);
const rim = new THREE.DirectionalLight(0xff3308, 3.2); rim.position.set(4,2,4); scene.add(rim);
const lavaLight = new THREE.PointLight(0xff4a10, 22, 7, 1.8); scene.add(lavaLight);
const crestLight = new THREE.PointLight(0xffc05a, 12, 4, 2); scene.add(crestLight);

const floor = new THREE.Mesh(new THREE.PlaneGeometry(30,30), new THREE.MeshStandardMaterial({color:0x111015,roughness:.52,metalness:.24}));
floor.rotation.x=-Math.PI/2; floor.position.y=-.585; floor.receiveShadow=true; scene.add(floor);
const tileGeo = new THREE.BoxGeometry(1,1,1);
const tileMat = new THREE.MeshStandardMaterial({color:0xffffff,roughness:.82,metalness:.08,vertexColors:true});
const tiles = new THREE.InstancedMesh(tileGeo,tileMat,225); tiles.receiveShadow=true;
const dummy = new THREE.Object3D(), tmpColor = new THREE.Color();
let ti=0;
for(let x=-7;x<=7;x++) for(let z=-7;z<=7;z++) {
  dummy.position.set(x*.49,-.555,z*.49); dummy.scale.set(.47,.055,.47); dummy.rotation.set(0,0,0); dummy.updateMatrix();
  tiles.setMatrixAt(ti,dummy.matrix); const n=.78+pixelHash(912,ti)*.22; tiles.setColorAt(ti,tmpColor.setRGB(.075*n,.068*n,.082*n)); ti++;
}
scene.add(tiles);

function dynamicInstances(capacity, material, shadows=true) {
  const mesh = new THREE.InstancedMesh(tileGeo,material,capacity);
  mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); mesh.count=0; mesh.frustumCulled=false;
  mesh.castShadow=shadows; mesh.receiveShadow=shadows; scene.add(mesh); return mesh;
}
const waveMat = new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.68,metalness:.02,emissive:0x641000,emissiveIntensity:1.0});
const wave = dynamicInstances(1100,waveMat);
const crust = dynamicInstances(64,new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.88,emissive:0x240300,emissiveIntensity:.45}));
const molten = dynamicInstances(32,new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.6,emissive:0xff2500,emissiveIntensity:1.25}),false);
const flames = dynamicInstances(30,new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.55,emissive:0xff3100,emissiveIntensity:1.4}),false);
const spray = dynamicInstances(9,new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.6,emissive:0xff3b00,emissiveIntensity:1.3}),false);
function setInstance(mesh,index,x,y,z,sx,sy,sz,color,rx=0,ry=0,rz=0,boost=1) {
  dummy.position.set(x,y,z); dummy.scale.set(sx,sy,sz); dummy.rotation.set(rx,ry,rz); dummy.updateMatrix();
  mesh.setMatrixAt(index,dummy.matrix);
  const c=rgb(color); mesh.setColorAt(index,tmpColor.setRGB(c[0]/255*boost,c[1]/255*boost,c[2]/255*boost));
}
function finishMesh(mesh,count) { mesh.count=count; mesh.instanceMatrix.needsUpdate=true; if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true; }

let currentT=.58, playing=true, last=performance.now(), hold=0, waveCount=0;
function phase(t) { return t<.18?['01','Gonflement']:t<.48?['02','Montée de la muraille']:t<.70?['03','Déferlement']:['04','Retombée']; }
function updateScene(t) {
  currentT=clamp(t); t=currentT;
  const rise=smooth(t/.48),curl=smooth((t-.24)/.44),collapse=smooth((t-.68)/.32),fade=clamp(1-t);
  const travel=(-.30+1.45*easeOut(t)),radius=1.12+.18*rise,waveZ=-travel;
  let res=16,field=fillSculpt(res,t);
  if(field.skin>1100){while(field.skin>1100&&res>8){res--;field=fillSculpt(res,t);}}
  else if(res<24){res=clamp(Math.floor(res*Math.sqrt(1100/Math.max(1,field.skin))),16,24);field=fillSculpt(res,t);}
  while(field.skin>1100&&res>8){res--;field=fillSculpt(res,t);}
  const step=2/res,hsz=radius*step*.54; let n=0;
  for(let i=0;i<res;i++)for(let j=0;j<res;j++)for(let k=0;k<res;k++){
    if(!field.occ[field.at(i,j,k)])continue;
    if(!(i===0||j===0||k===0||i===res-1||j===res-1||k===res-1||!field.occ[field.at(i-1,j,k)]||!field.occ[field.at(i+1,j,k)]||!field.occ[field.at(i,j-1,k)]||!field.occ[field.at(i,j+1,k)]||!field.occ[field.at(i,j,k-1)]||!field.occ[field.at(i,j,k+1)]))continue;
    const nx=-1+(i+.5)*step,ny=-1+(j+.5)*step,nz=-1+(k+.5)*step;
    const u=clamp(.42+.62*(ny*.5+.5)+.20*nz);
    const color=jitterRgb(rampRgb(u,DEEP,P,HIGH,A),SALT+i*73+j*131+k*17,.05);
    setInstance(wave,n++,nx*radius,.20+ny*radius,waveZ+nz*radius,hsz*2,hsz*2,hsz*2,color,0,0,0,u>.72?1.34:1.08);
  }
  waveCount=n;finishMesh(wave,n);waveMat.opacity=t>.80?clamp((1-t)/.20):1;waveMat.transparent=t>.80;
  let nc=0,nm=0;const groundY=-.48;
  for(let row=0;row<6;row++){
    const reveal=clamp((t-row*.055)/.20);if(reveal<=0)continue;
    const along=-.42+row*.30+.20*easeOut(t);
    for(let col=-3;col<=3;col++){
      const h=pixelHash(SALT,row*41+col*17+100);if(h<.16&&row>1)continue;
      const side=col*.245,hs=(.105+.025*h)*reveal,color=shadeRgb(S,.62+.16*h);
      setInstance(crust,nc++,side,groundY,-along,hs*2,.06,hs*1.8,color);
      if(((row+col)&1)===0)setInstance(molten,nm++,side,groundY+.04,-along,hs*.96,.036,hs*1.24,h>.72?A:P,0,0,0,1.25);
    }
  }
  finishMesh(crust,nc);finishMesh(molten,nm);
  const crestForward=.52+.54*curl,crestY=.48+.72*rise-.60*collapse;let nf=0;
  for(let i=0;i<5;i++){
    const side=(i-2)*.31,height=(.28+.20*pixelHash(SALT,i*23))*(1-.55*collapse);
    for(let k=0;k<6;k++){
      const u=k/5,phase=t*14*.42+i*1.3,bend=Math.sin(phase+u*3.1)*.075*u,bendZ=Math.cos(phase*.7+u*2.3)*.075*.55*u,half=.05*(1-.68*u);
      const color=rampRgb(u,shadeRgb(P,.52),P,mixRgb(P,A,.55),A);
      setInstance(flames,nf++,side+bend,crestY+u*height,waveZ-crestForward+bendZ,half*2,half*2.6,half*1.7,color,Math.sin(phase)*.25,Math.sin(phase+u*3.1+1.57)*.18,bendZ*3,1.2);
    }
  }
  finishMesh(flames,nf);flames.material.opacity=rise*fade;flames.material.transparent=true;
  let ns=0;const sp=clamp((t-.30)/.70);
  if(sp>0)for(let i=0;i<9;i++){
    const side=(i-4)*.19,speed=.65+.55*pixelHash(SALT,i*37),time=sp*.82,size=.035+.025*pixelHash(SALT,i*19);
    setInstance(spray,ns++,side,crestY+(1.10*time-2.25*time*time),waveZ-crestForward-speed*time,size*2,size*2,size*2,i%3===0?A:P,0,0,0,1.25);
  }
  finishMesh(spray,ns);spray.material.opacity=fade;spray.material.transparent=true;
  lavaLight.position.set(0,-.05,waveZ-.1);lavaLight.intensity=22*fade;
  crestLight.position.set(0,crestY+.25,waveZ-crestForward);crestLight.intensity=12*rise*fade;
  const ph=phase(t);document.querySelector('#phaseIndex').textContent=ph[0];document.querySelector('#phaseName').textContent=ph[1];
  document.querySelector('#timeOutput').textContent=Math.round(t*100)+' %';document.querySelector('#timeline').value=Math.round(t*1000);
  document.querySelector('#timeline').style.background=`linear-gradient(90deg,var(--hot) ${t*100}%,#332b2b ${t*100}%)`;
  document.querySelector('#voxelCount').textContent=n.toLocaleString('fr-FR');
}

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene,camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(800,800),.52,.48,.74);composer.addPass(bloom);composer.addPass(new OutputPass());
function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h,false);composer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(stage);resize();
function setPlaying(value){playing=value;document.querySelector('#play').textContent=playing?'❚❚ Pause':'▶ Lecture';}
function setTime(t){setPlaying(false);hold=0;updateScene(t);controls.update();renderer.info.reset();composer.render();}
document.querySelector('#play').addEventListener('click',()=>setPlaying(!playing));
document.querySelector('#restart').addEventListener('click',()=>{currentT=0;hold=0;setPlaying(true);});
document.querySelector('#timeline').addEventListener('input',e=>setTime(e.target.value/1000));
document.querySelectorAll('[data-time]').forEach(b=>b.addEventListener('click',()=>setTime(Number(b.dataset.time))));
document.querySelector('#resetCamera').addEventListener('click',()=>{camera.position.copy(heroCamera);controls.target.copy(heroTarget);controls.update();});
const params=new URLSearchParams(location.search);if(params.has('clean'))document.querySelectorAll('.stage-badge,.orbit-hint').forEach(e=>e.style.display='none');if(params.has('t')){setPlaying(false);currentT=clamp(Number(params.get('t')));}else currentT=0;
window.renderAt=setTime;
window.setPlaying=setPlaying;
window.getDiagnostics=()=>({type:'web-prototype',t:currentT,waveVoxels:waveCount,phase:phase(currentT)[1],drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles});
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(playing){if(currentT>=1){hold+=dt;if(hold>.42){currentT=0;hold=0;}}else currentT=clamp(currentT+dt/4.2);}updateScene(currentT);controls.update();renderer.info.reset();composer.render();requestAnimationFrame(frame);}
updateScene(currentT);renderer.info.reset();composer.render();window.previewReady=true;requestAnimationFrame(frame);
