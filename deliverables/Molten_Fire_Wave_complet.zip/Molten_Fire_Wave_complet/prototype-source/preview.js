import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

const P = 0xFF4A10, S = 0xB01B00, A = 0xFFE08A;
const SALT = 0x4D4F4C54;
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
const easeOut = t => 1 - (1 - t) * (1 - t);
const mix = (a, b, t) => a + (b - a) * t;
function pixelHash(salt, a) {
  let h = Math.imul(salt, 0x9E3779B1) ^ Math.imul(a, 0x85EBCA77);
  h ^= h >>> 15; h = Math.imul(h, 0x2545F491); h ^= h >>> 13;
  return (h & 0xFFFF) / 65535;
}
function rgb(i) { return [(i >>> 16) & 255, (i >>> 8) & 255, i & 255]; }
function int(c) { return (Math.round(clamp(c[0], 0, 255)) << 16) | (Math.round(clamp(c[1], 0, 255)) << 8) | Math.round(clamp(c[2], 0, 255)); }
function mixRgb(a, b, t) { const x = rgb(a), y = rgb(b); return int(x.map((v, i) => mix(v, y[i], t))); }
function shadeRgb(a, m) { return int(rgb(a).map(v => v * m)); }
function rampRgb(u, deep, body, high, tip) {
  u = clamp(u);
  if (u < .34) return mixRgb(deep, body, u / .34);
  if (u < .68) return mixRgb(body, high, (u - .34) / .34);
  return mixRgb(high, tip, (u - .68) / .32);
}
function jitterRgb(color, salt, amount) {
  const h = Math.imul(salt, 0x9E3779B1);
  const variation = ((((h >>> 3) & 0xFFFF) / 65535) - .5) * 2 * amount;
  return shadeRgb(color, 1 + variation);
}
const DEEP = shadeRgb(mixRgb(S, P, .30), .52);
const HIGH = shadeRgb(mixRgb(P, A, .35), 1.08);
function moltenLavaRgb(nx,ny,nz,u,t){
  const warp=voxNoise(SALT+0x1A7A,nx*2.3,ny*2.3,nz*2.3)-.5;
  const plates=voxNoise(SALT+0x1A73,nx*6.4+warp*1.8,ny*6.4+nx*.6,nz*6.4-warp*1.8);
  const grain=voxNoise(SALT+0x51A9,nx*15,ny*15,nz*15),crack=Math.abs(plates-.5);
  let color;
  if(crack<.075){const heat=1-crack/.075;color=mixRgb(P,A,.35+.55*heat);}
  else if(plates>.61)color=mixRgb(DEEP,P,.25+.20*grain);
  else if(plates<.39)color=mixRgb(P,HIGH,.42+.30*grain);
  else color=mixRgb(P,HIGH,.20+.40*grain);
  const crustMask=voxNoise(SALT+0xC057,nx*3.8,ny*3.8,nz*3.8);
  if(crustMask>.64&&crack>.08)color=mixRgb(color,mixRgb(DEEP,P,.18),.55);
  return shadeRgb(color,.94+.06*Math.sin(t*.7*3+nx*5.1+ny*3.7+nz*4.3));
}

function voxNoise(seed, x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  let fx = x - xi, fy = y - yi, fz = z - zi;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy); fz = fz * fz * (3 - 2 * fz);
  const h = (dx, dy, dz) => pixelHash(seed, Math.imul(xi + dx, 73856093) ^ Math.imul(yi + dy, 19349663) ^ Math.imul(zi + dz, 83492791));
  const x00 = mix(h(0,0,0), h(1,0,0), fx), x10 = mix(h(0,1,0), h(1,1,0), fx);
  const x01 = mix(h(0,0,1), h(1,0,1), fx), x11 = mix(h(0,1,1), h(1,1,1), fx);
  return mix(mix(x00, x10, fy), mix(x01, x11, fy), fz);
}
function segDist2(pz, py, az, ay, bz, by) {
  const vz = bz - az, vy = by - ay, wz = pz - az, wy = py - ay;
  const len = vz * vz + vy * vy;
  const t = len > 1e-9 ? clamp((wz * vz + wy * vy) / len) : 0;
  const cz = az + vz * t, cy = ay + vy * t;
  return Math.hypot(pz - cz, py - cy);
}
function moltenSdf(x, y, z, t) {
  const rise = smooth(t / .48), curl = smooth((t - .24) / .44), collapse = smooth((t - .68) / .32);
  const height = .16 + .84 * rise * (1 - .58 * collapse);
  const crestY = -.78 + 1.62 * height;
  const backZ = .46 - .18 * rise, shoulderZ = .20 - .20 * curl, crestZ = -.12 - .42 * curl;
  const lipZ = crestZ - .32 - .28 * curl;
  const lipY = crestY - (.22 + .60 * curl + .35 * collapse);
  let d = 1e9;
  d = Math.min(d, segDist2(z,y,backZ,-.98,backZ,-.28+.20*rise)-.29);
  d = Math.min(d, segDist2(z,y,backZ,-.28+.20*rise,shoulderZ,crestY-.36)-.25);
  d = Math.min(d, segDist2(z,y,shoulderZ,crestY-.36,crestZ,crestY)-.22);
  d = Math.min(d, segDist2(z,y,crestZ,crestY,lipZ,lipY)-.17);
  d = Math.min(d, segDist2(z,y,lipZ,lipY,lipZ+.08,Math.max(-.92,lipY-.28))-.11);
  d = Math.min(d, Math.max(Math.abs(y+.88)-.15,Math.abs(z-.02)-.64));
  const width = .84 - .16 * clamp((y + 1) * .5);
  d = Math.max(d, Math.abs(x) - width);
  d = Math.max(d, Math.max(y - 1.04, -y - 1.06));
  return d + (voxNoise(SALT, x*4.4, y*4.4, z*4.4) - .5) * .12;
}
function fillSculpt(res, t) {
  const occ = new Uint8Array(res * res * res);
  const at = (i,j,k) => (i * res + j) * res + k;
  for (let i=0;i<res;i++) for (let j=0;j<res;j++) for (let k=0;k<res;k++) {
    const x=-1+(i+.5)*2/res, y=-1+(j+.5)*2/res, z=-1+(k+.5)*2/res;
    occ[at(i,j,k)] = moltenSdf(x,y,z,t) <= 0 ? 1 : 0;
  }
  let skin=0;
  for (let i=0;i<res;i++) for (let j=0;j<res;j++) for (let k=0;k<res;k++) {
    if (!occ[at(i,j,k)]) continue;
    if (i===0||j===0||k===0||i===res-1||j===res-1||k===res-1||
        !occ[at(i-1,j,k)]||!occ[at(i+1,j,k)]||!occ[at(i,j-1,k)]||!occ[at(i,j+1,k)]||!occ[at(i,j,k-1)]||!occ[at(i,j,k+1)]) skin++;
  }
  return {occ,skin,at};
}

const canvas = document.querySelector('#scene');
const stage = document.querySelector('#stage');
const renderer = new THREE.WebGLRenderer({canvas, antialias:true, preserveDrawingBuffer:true, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.22;
renderer.info.autoReset = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x09090d);
scene.fog = new THREE.Fog(0x09090d, 8, 18);
const camera = new THREE.PerspectiveCamera(38, 1, .05, 60);
const heroCamera = new THREE.Vector3(6.4, 2.15, -3.1);
const heroTarget = new THREE.Vector3(0, .05, -.35);
camera.position.copy(heroCamera);
const controls = new OrbitControls(camera, canvas);
controls.target.copy(heroTarget); controls.enableDamping = true; controls.dampingFactor = .065;
controls.minDistance = 3.2; controls.maxDistance = 12; controls.maxPolarAngle = Math.PI * .49;
controls.update();

scene.add(new THREE.HemisphereLight(0x6c6170, 0x170604, .65));
const key = new THREE.DirectionalLight(0xffd1a1, 3.1);
key.position.set(4,6,-3); key.castShadow = true;
key.shadow.mapSize.set(1024,1024); key.shadow.camera.left=-5; key.shadow.camera.right=5; key.shadow.camera.top=5; key.shadow.camera.bottom=-5;
scene.add(key);
const rim = new THREE.DirectionalLight(0xff3308, 3.2); rim.position.set(4,2,4); scene.add(rim);
const lavaLight = new THREE.PointLight(0xff6a1a, 24, 7, 1.8); scene.add(lavaLight);
const crestLight = new THREE.PointLight(0xffb14a, 8, 4, 2); scene.add(crestLight);
const underLight = new THREE.PointLight(0xa81200, 10, 5, 2); scene.add(underLight);

const floor = new THREE.Mesh(new THREE.PlaneGeometry(30,30), new THREE.MeshStandardMaterial({color:0x111015,roughness:.52,metalness:.24}));
floor.rotation.x=-Math.PI/2; floor.position.y=-.585; floor.receiveShadow=true; scene.add(floor);
const tileGeo = new THREE.BoxGeometry(1,1,1);
const tileMat = new THREE.MeshStandardMaterial({color:0xffffff,roughness:.82,metalness:.08,vertexColors:true});
const tiles = new THREE.InstancedMesh(tileGeo,tileMat,225); tiles.receiveShadow=true;
const dummy = new THREE.Object3D(), tmpColor = new THREE.Color();
let ti=0;
for(let x=-7;x<=7;x++) for(let z=-7;z<=7;z++) {
  dummy.position.set(x*.49,-.555,z*.49); dummy.scale.set(.47,.055,.47); dummy.rotation.set(0,0,0); dummy.updateMatrix();
  tiles.setMatrixAt(ti,dummy.matrix); const n=.78+pixelHash(912,ti)*.22; tiles.setColorAt(ti,tmpColor.setRGB(.075*n,.068*n,.082*n)); ti++;
}
scene.add(tiles);

function dynamicInstances(capacity, material, shadows=true) {
  const mesh = new THREE.InstancedMesh(tileGeo,material,capacity);
  mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); mesh.count=0; mesh.frustumCulled=false;
  mesh.castShadow=shadows; mesh.receiveShadow=shadows; scene.add(mesh); return mesh;
}
const waveMat = new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.76,metalness:.02,emissive:0x2a0500,emissiveIntensity:.55});
const wave = dynamicInstances(1100,waveMat);
const crust = dynamicInstances(64,new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.88,emissive:0x240300,emissiveIntensity:.45}));
const molten = dynamicInstances(32,new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.6,emissive:0xff2500,emissiveIntensity:1.25}),false);
function liquidMaterial(opacity,emissiveIntensity){return new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.38,metalness:.02,emissive:0xff3100,emissiveIntensity,transparent:true,opacity,depthWrite:false});}
const splashCool=dynamicInstances(140,liquidMaterial(.48,.85),false);
const splashMid=dynamicInstances(140,liquidMaterial(.70,1.05),false);
const splashHot=dynamicInstances(140,liquidMaterial(.92,1.25),false);
const splats=dynamicInstances(35,liquidMaterial(.55,.65),false);
const splashMeshes=[splashCool,splashMid,splashHot];splashCool.renderOrder=1;splashMid.renderOrder=2;splashHot.renderOrder=3;splats.renderOrder=0;
function setInstance(mesh,index,x,y,z,sx,sy,sz,color,rx=0,ry=0,rz=0,boost=1) {
  dummy.position.set(x,y,z); dummy.scale.set(sx,sy,sz); dummy.rotation.set(rx,ry,rz); dummy.updateMatrix();
  mesh.setMatrixAt(index,dummy.matrix);
  const c=rgb(color); mesh.setColorAt(index,tmpColor.setRGB(c[0]/255*boost,c[1]/255*boost,c[2]/255*boost));
}
function finishMesh(mesh,count) { mesh.count=count; mesh.instanceMatrix.needsUpdate=true; if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true; }

let currentT=.58, playing=true, last=performance.now(), hold=0, waveCount=0;
function phase(t) { return t<.18?['01','Émergence']:t<.48?['02','Montée de la muraille']:t<.70?['03','Déferlement']:['04','Enfoncement']; }
function updateScene(t) {
  currentT=clamp(t); t=currentT;
  const rise=smooth(t/.48),curl=smooth((t-.24)/.44),collapse=smooth((t-.68)/.32),fade=clamp(1-t);
  const birth=smooth(t/.18),sink=smooth((t-.76)/.24),envelope=birth*(1-sink);
  const depthOffset=-((1-birth)+sink)*1.90;
  const travel=(-.30+1.45*easeOut(t)),radius=1.12+.18*rise,waveZ=-travel,waveY=.20+depthOffset;
  let res=16,field=fillSculpt(res,t);
  if(field.skin>1100){while(field.skin>1100&&res>8){res--;field=fillSculpt(res,t);}}
  else if(res<24){res=clamp(Math.floor(res*Math.sqrt(1100/Math.max(1,field.skin))),16,24);field=fillSculpt(res,t);}
  while(field.skin>1100&&res>8){res--;field=fillSculpt(res,t);}
  const step=2/res,hsz=radius*step*.54; let n=0;
  for(let i=0;i<res;i++)for(let j=0;j<res;j++)for(let k=0;k<res;k++){
    if(!field.occ[field.at(i,j,k)])continue;
    if(!(i===0||j===0||k===0||i===res-1||j===res-1||k===res-1||!field.occ[field.at(i-1,j,k)]||!field.occ[field.at(i+1,j,k)]||!field.occ[field.at(i,j-1,k)]||!field.occ[field.at(i,j+1,k)]||!field.occ[field.at(i,j,k-1)]||!field.occ[field.at(i,j,k+1)]))continue;
    const nx=-1+(i+.5)*step,ny=-1+(j+.5)*step,nz=-1+(k+.5)*step;
    const u=clamp(.42+.62*(ny*.5+.5)+.20*nz);
    const color=moltenLavaRgb(nx,ny,nz,u,t);
    const hot=((color>>>8)&255)>70;
    setInstance(wave,n++,nx*radius,waveY+ny*radius,waveZ+nz*radius,hsz*2,hsz*2,hsz*2,color,0,0,0,hot?1.50:1.18);
  }
  const visible=envelope>.0001;waveCount=visible?n:0;finishMesh(wave,visible?n:0);waveMat.opacity=envelope;waveMat.transparent=envelope<.999;
  let nc=0,nm=0;const groundY=-.48+depthOffset;
  for(let row=0;row<6;row++){
    const reveal=clamp((t-row*.055)/.20);if(reveal<=0)continue;
    const along=-.42+row*.30+.20*easeOut(t);
    for(let col=-3;col<=3;col++){
      const h=pixelHash(SALT,row*41+col*17+100);if(h<.16&&row>1)continue;
      const side=col*.245,hs=(.105+.025*h)*reveal,color=shadeRgb(S,.62+.16*h);
      setInstance(crust,nc++,side,groundY,-along,hs*2,.06,hs*1.8,color);
      if(((row+col)&1)===0)setInstance(molten,nm++,side,groundY+.04,-along,hs*.96,.036,hs*1.24,h>.72?A:P,0,0,0,1.25);
    }
  }
  finishMesh(crust,visible?nc:0);finishMesh(molten,visible?nm:0);
  crust.material.opacity=envelope;molten.material.opacity=envelope;crust.material.transparent=molten.material.transparent=envelope<.999;
  const crestForward=.52+.54*curl,crestY=.48+.72*rise-.60*collapse+depthOffset;
  const splashCounts=[0,0,0],contactGround=-.48;let splatCount=0;
  for(let p=0;p<35;p++){
    const lane=p%7-3,burst=Math.floor(p/7),h=pixelHash(SALT,p*37+300),launch=.24+burst*.045+h*.025,age=t-launch;
    if(age<0)continue;
    const launchRise=smooth(launch/.48),launchCurl=smooth((launch-.24)/.44),launchTravel=-.30+1.45*easeOut(launch),launchForward=launchTravel+.52+.54*launchCurl;
    const side=lane*.24+(pixelHash(SALT,p*17+8)-.5)*.04,ox=side,oy=.48+.72*launchRise,oz=-launchForward;
    const force=.72+.62*h,vf=(1.00+1.25*pixelHash(SALT,p*41+11))*force,vy=(1.75+.85*pixelHash(SALT,p*43+19))*force;
    const vs=lane*.055+(pixelHash(SALT,p*47+23)-.5)*.28,vx=vs,vz=-vf,gravity=6.60,time=age*1.90;
    const hitTime=(vy+Math.sqrt(vy*vy+2*gravity*(oy-contactGround)))/gravity;
    if(time>=hitTime){
      const since=time-hitTime;if(since>.16)continue;
      const px=ox+vx*hitTime,pz=oz+vz*hitTime,spread=1+since*10,hs=(.055+.025*h)*spread;
      setInstance(splats,splatCount++,px,contactGround+.018,pz,hs*2,.03,hs*1.5,mixRgb(S,P,.45+.30*h),0,0,0,1.1);continue;
    }
    const breakup=clamp(age/.20),px=ox+vx*time,py=oy+vy*time-.5*gravity*time*time,pz=oz+vz*time,vyNow=vy-gravity*time;
    const speed=Math.sqrt(vx*vx+vyNow*vyNow+vz*vz),size=.040+.022*h+.030*(1-breakup),heat=(1-breakup)*(.55+.35*h);
    let color=mixRgb(P,A,.15+.65*heat);if(breakup>.65)color=mixRgb(color,S,(breakup-.65)*.80);
    color=shadeRgb(color,.94+.06*Math.sin(t*.7*3+px*2.1+py*3.7+pz*2.9));
    const group=Math.min(2,Math.floor(h*3)),satGroup=Math.max(0,group-1),yaw=Math.atan2(vx,vz),pitch=Math.acos(clamp(vyNow/Math.max(.001,speed),-1,1));
    setInstance(splashMeshes[group],splashCounts[group]++,px,py,pz,size*2,size*2*(1.05+.25*Math.abs(vyNow)/Math.max(.01,vy)),size*1.9,color,pitch,yaw,0,1.25);
    const separation=size*(.55+1.45*breakup),satSize=size*(.52+.18*h),satColor=mixRgb(color,S,.20+.25*breakup),invSpeed=1/Math.max(.001,speed);
    setInstance(splashMeshes[satGroup],splashCounts[satGroup]++,px-vx*invSpeed*separation,py-vyNow*invSpeed*separation,pz-vz*invSpeed*separation,satSize*2,satSize*2,satSize*2,satColor,0,0,0,1.1);
    if(h>.58&&breakup>.30)setInstance(splashCool,splashCounts[0]++,px+size*breakup*1.4,py+size*.35,pz,size*.76,size*.76,size*.76,mixRgb(P,A,.30),0,0,0,1.15);
  }
  splashMeshes.forEach((m,i)=>{finishMesh(m,visible?splashCounts[i]:0);m.material.opacity=envelope*(.72+.28*fade)*[.48,.70,.92][i];});
  finishMesh(splats,visible?splatCount:0);splats.material.opacity=envelope*(.72+.28*fade)*.55;
  const lightEnvelope=envelope*(.65+.35*fade);
  lavaLight.position.set(0,waveY-.10,waveZ-.1);lavaLight.intensity=24*lightEnvelope*(.90+.10*Math.sin(t*9));
  crestLight.position.set(0,crestY+.25,waveZ-crestForward);crestLight.intensity=8*rise*lightEnvelope*(.92+.08*Math.sin(t*7+1));
  underLight.position.set(0,waveY-.35,waveZ+.35);underLight.intensity=10*lightEnvelope*(.85+.15*Math.cos(t*8));
  const ph=phase(t);document.querySelector('#phaseIndex').textContent=ph[0];document.querySelector('#phaseName').textContent=ph[1];
  document.querySelector('#timeOutput').textContent=Math.round(t*100)+' %';document.querySelector('#timeline').value=Math.round(t*1000);
  document.querySelector('#timeline').style.background=`linear-gradient(90deg,var(--hot) ${t*100}%,#332b2b ${t*100}%)`;
  document.querySelector('#voxelCount').textContent=n.toLocaleString('fr-FR');
}

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene,camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(800,800),.52,.48,.74);composer.addPass(bloom);composer.addPass(new OutputPass());
function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h,false);composer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(stage);resize();
function setPlaying(value){playing=value;document.querySelector('#play').textContent=playing?'❚❚ Pause':'▶ Lecture';}
function setTime(t){setPlaying(false);hold=0;updateScene(t);controls.update();renderer.info.reset();composer.render();}
document.querySelector('#play').addEventListener('click',()=>setPlaying(!playing));
document.querySelector('#restart').addEventListener('click',()=>{currentT=0;hold=0;setPlaying(true);});
document.querySelector('#timeline').addEventListener('input',e=>setTime(e.target.value/1000));
document.querySelectorAll('[data-time]').forEach(b=>b.addEventListener('click',()=>setTime(Number(b.dataset.time))));
document.querySelector('#resetCamera').addEventListener('click',()=>{camera.position.copy(heroCamera);controls.target.copy(heroTarget);controls.update();});
const params=new URLSearchParams(location.search);if(params.has('clean'))document.querySelectorAll('.stage-badge,.orbit-hint').forEach(e=>e.style.display='none');if(params.has('t')){setPlaying(false);currentT=clamp(Number(params.get('t')));}else currentT=0;
window.renderAt=setTime;
window.setPlaying=setPlaying;
window.getDiagnostics=()=>({type:'web-prototype',t:currentT,waveVoxels:waveCount,phase:phase(currentT)[1],drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles});
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(playing){if(currentT>=1){hold+=dt;if(hold>.42){currentT=0;hold=0;}}else currentT=clamp(currentT+dt/4.2);}updateScene(currentT);controls.update();renderer.info.reset();composer.render();requestAnimationFrame(frame);}
updateScene(currentT);renderer.info.reset();composer.render();window.previewReady=true;requestAnimationFrame(frame);
