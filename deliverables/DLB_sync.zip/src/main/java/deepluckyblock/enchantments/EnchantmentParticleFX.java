package deepluckyblock.enchantments;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * T306-ENCHANT-FX : Moteur de chorégraphies de particules thématiques serveur
 * (géométries d'arcs de lame, doubles hélices, anneaux d'onde de choc, rayons
 * grappin/siphon, météores obliques, halos de couronne et sillages de chevilles).
 *
 * Conçu pour n'obstruer jamais la caméra première personne du porteur et rester
 * ultra-léger côté réseau (throttling strict sur les effets passifs).
 */
public final class EnchantmentParticleFX {

    private EnchantmentParticleFX() {}

    private static DustParticleOptions dustFromRgb(int rgb, float scale) {
        return new DustParticleOptions(new Vector3f(
                ((rgb >> 16) & 0xFF) / 255.0f,
                ((rgb >> 8) & 0xFF) / 255.0f,
                (rgb & 0xFF) / 255.0f), scale);
    }

    // T374-PALETTE-LOCK : toutes les poussières personnalisées réutilisent un rôle élémentaire existant.
    public static final DustParticleOptions CRIMSON_BLOOD = dustFromRgb(DeepElement.BLOOD.primary, 1.15f);
    public static final DustParticleOptions SCARLET_MIST = dustFromRgb(DeepElement.BLOOD.secondary, 0.90f);
    public static final DustParticleOptions GOLD_DIVINE = dustFromRgb(DeepElement.LIGHT.primary, 1.05f);
    public static final DustParticleOptions SHADOW_VIOLET = dustFromRgb(DeepElement.SHADOW.primary, 1.10f);
    public static final DustParticleOptions TOXIC_GREEN = dustFromRgb(DeepElement.POISON.primary, 1.00f);
    public static final DustParticleOptions TEMPORAL_AMBER = dustFromRgb(DeepElement.LIGHT.secondary, 0.85f);
    public static final DustParticleOptions FROST_CYAN = dustFromRgb(DeepElement.WATER.highlight, 0.95f);
    /** Nom historique conservé pour compatibilité ; la poussière suit maintenant la Foudre T373. */
    public static final DustParticleOptions OVERCLOCK_CYAN = dustFromRgb(DeepElement.THUNDER.primary, 1.05f);
    public static final DustParticleOptions STEEL_SILVER = dustFromRgb(DeepElement.METAL.primary, 0.95f);
    public static final DustParticleOptions EARTH_OCHRE = dustFromRgb(DeepElement.EARTH.primary, 1.10f);
    public static final DustParticleOptions CLOUD_WHITE = dustFromRgb(DeepElement.LIGHT.highlight, 1.05f);
    public static final DustParticleOptions HONEY_AMBER = dustFromRgb(DeepElement.LIGHT.secondary, 1.05f);

    /** Arc d'entaille orienté devant l'attaquant (balayages, lames maîtresses). */
    public static void slashArc(LivingEntity attacker, ParticleOptions main, ParticleOptions accent,
                                double radius, int points) {
        if (attacker == null || !(attacker.level() instanceof ServerLevel sl)) return;
        try {
            Vec3 look = attacker.getLookAngle();
            Vec3 flatFwd = new Vec3(look.x, 0.0, look.z);
            if (flatFwd.lengthSqr() < 1.0e-4) flatFwd = new Vec3(0.0, 0.0, 1.0);
            flatFwd = flatFwd.normalize();
            Vec3 right = new Vec3(-flatFwd.z, 0.0, flatFwd.x);
            double baseY = attacker.getY() + attacker.getBbHeight() * 0.62;
            int n = Math.max(5, Math.min(20, points));
            double r = Math.min(5.0, Math.max(1.2, radius));
            for (int i = 0; i < n; i++) {
                double t = (double) i / (n - 1) - 0.5; // [-0.5, 0.5]
                double ang = t * 2.15; // ~123 degrees arc
                double cos = Math.cos(ang);
                double sin = Math.sin(ang);
                double px = attacker.getX() + (flatFwd.x * cos + right.x * sin) * r;
                double pz = attacker.getZ() + (flatFwd.z * cos + right.z * sin) * r;
                double py = baseY + sin * 0.18;
                PixelFx.send(sl, main, px, py, pz, 1, 0.03, 0.03, 0.03, 0.005);
                if (accent != null && (i & 1) == 0) {
                    PixelFx.send(sl, accent, px, py, pz, 1, 0.02, 0.02, 0.02, 0.01);
                }
            }
        } catch (Throwable ignored) {}
    }

    /** Double hélice ascendante autour d'une entité (vampirisme, bénédictions, chrono). */
    public static void doubleHelix(Entity center, ParticleOptions strandA, ParticleOptions strandB,
                                   double radius, int steps) {
        if (center == null || !(center.level() instanceof ServerLevel sl)) return;
        try {
            double cx = center.getX();
            double cy = center.getY() + 0.15;
            double cz = center.getZ();
            double h = Math.max(1.0, Math.min(3.2, center.getBbHeight() + 0.3));
            double r = Math.max(0.35, Math.min(2.2, radius));
            int n = Math.max(6, Math.min(18, steps));
            double phase = (center.tickCount * 0.18);
            for (int i = 0; i < n; i++) {
                double frac = (double) i / n;
                double ang = phase + frac * Math.PI * 2.2;
                double y = cy + frac * h;
                PixelFx.send(sl, strandA, cx + Math.cos(ang) * r, y, cz + Math.sin(ang) * r,
                        1, 0.01, 0.01, 0.01, 0.0);
                if (strandB != null) {
                    PixelFx.send(sl, strandB, cx - Math.cos(ang) * r, y, cz - Math.sin(ang) * r,
                            1, 0.01, 0.01, 0.01, 0.0);
                }
            }
        } catch (Throwable ignored) {}
    }

    /** Anneau d'onde de choc horizontal au sol ou à mi-hauteur. */
    public static void shockwaveRing(ServerLevel sl, double x, double y, double z,
                                     ParticleOptions particle, double radius, int points, double outwardSpeed) {
        if (sl == null) return;
        try {
            int n = Math.max(8, Math.min(28, points));
            double r = Math.max(0.4, Math.min(6.0, radius));
            for (int i = 0; i < n; i++) {
                double ang = (Math.PI * 2.0 * i) / n;
                double dx = Math.cos(ang);
                double dz = Math.sin(ang);
                PixelFx.send(sl, particle, x + dx * r, y, z + dz * r,
                        1, dx * 0.04, 0.02, dz * 0.04, outwardSpeed);
            }
        } catch (Throwable ignored) {}
    }

    /** Onde de débris de bloc circulaire (séisme, impact tellurique, atterrissage lourd). */
    public static void blockDebrisRing(ServerLevel sl, double x, double y, double z,
                                       BlockState state, double radius, int points) {
        if (sl == null || state == null) return;
        shockwaveRing(sl, x, y + 0.08, z, new BlockParticleOption(ParticleTypes.BLOCK, state), radius, points, 0.08);
    }

    /** Rayon / corde tendue de particules entre deux positions (grappin, ricochet, foudre, sangsue). */
    public static void tetherBeam(ServerLevel sl, Vec3 from, Vec3 to, ParticleOptions main,
                                  ParticleOptions spark, double stepLen) {
        if (sl == null || from == null || to == null) return;
        try {
            Vec3 delta = to.subtract(from);
            double dist = Math.min(32.0, delta.length());
            if (dist < 0.15) return;
            Vec3 dir = delta.normalize();
            double step = Math.max(0.45, stepLen);
            int idx = 0;
            for (double d = 0.4; d <= dist; d += step) {
                Vec3 p = from.add(dir.scale(d));
                PixelFx.send(sl, main, p.x, p.y, p.z, 1, 0.02, 0.02, 0.02, 0.0);
                if (spark != null && (idx++ % 3 == 0)) {
                    PixelFx.send(sl, spark, p.x, p.y, p.z, 1, 0.04, 0.04, 0.04, 0.01);
                }
            }
        } catch (Throwable ignored) {}
    }

    /** Traînée météoritique oblique tombant du ciel jusqu'au point d'impact. */
    public static void meteorSkyfall(ServerLevel sl, Vec3 impact) {
        if (sl == null || impact == null) return;
        try {
            Vec3 skyStart = impact.add(2.8, 11.0, -2.2);
            Vec3 delta = impact.subtract(skyStart);
            int steps = 16;
            for (int i = 0; i <= steps; i++) {
                double f = (double) i / steps;
                Vec3 p = skyStart.add(delta.scale(f));
                PixelFx.send(sl, ParticleTypes.FLAME, p.x, p.y, p.z, 3, 0.18, 0.18, 0.18, 0.02);
                PixelFx.send(sl, ParticleTypes.CAMPFIRE_COSY_SMOKE, p.x, p.y, p.z, 1, 0.12, 0.12, 0.12, 0.005);
                if ((i & 1) == 0) {
                    PixelFx.send(sl, ParticleTypes.LAVA, p.x, p.y, p.z, 1, 0.10, 0.10, 0.10, 0.0);
                }
            }
        } catch (Throwable ignored) {}
    }

    /** Sillage discret aux chevilles (derrière le regard pour ne jamais gêner la vue). */
    public static void ankleTrail(LivingEntity entity, ParticleOptions particle, int count, double speed) {
        if (entity == null || !(entity.level() instanceof ServerLevel sl)) return;
        try {
            Vec3 look = entity.getLookAngle();
            double bx = entity.getX() - look.x * 0.28;
            double by = entity.getY() + 0.12;
            double bz = entity.getZ() - look.z * 0.28;
            PixelFx.send(sl, particle, bx, by, bz, Math.max(1, Math.min(8, count)), 0.18, 0.06, 0.18, speed);
        } catch (Throwable ignored) {}
    }

    /** Halo de couronne discret au-dessus de la tête (Roi, Général, Esprit Mystique, Garde Radieuse). */
    public static void crownHalo(LivingEntity entity, ParticleOptions particle, int points) {
        if (entity == null || !(entity.level() instanceof ServerLevel sl)) return;
        try {
            double y = entity.getY() + entity.getBbHeight() + 0.28;
            int n = Math.max(6, Math.min(16, points));
            // T360-HALO-CONTINU : anneau de mini-cubes 3D à durée de vie LONGUE (22 ticks). Deux
            // émissions successives se chevauchent donc toujours : la couronne ne s'éteint plus
            // entre deux déclenchements (le fameux « le halo spawn une fois et disparaît »).
            PixelFx.ring(sl, entity.getX(), y, entity.getZ(), 0.44, n,
                    PixelFx.colorOf(particle), 22);
        } catch (Throwable ignored) {}
    }

    /** Rubans d'ailes derrière les épaules (Élytres, Endurance Ailée). */
    public static void wingRibbons(LivingEntity entity, ParticleOptions particle) {
        if (entity == null || !(entity.level() instanceof ServerLevel sl)) return;
        try {
            Vec3 look = entity.getLookAngle();
            Vec3 right = new Vec3(-look.z, 0.0, look.x);
            if (right.lengthSqr() < 1.0e-4) right = new Vec3(1.0, 0.0, 0.0);
            right = right.normalize();
            Vec3 back = entity.position().add(-look.x * 0.45, entity.getBbHeight() * 0.65, -look.z * 0.45);
            Vec3 leftTip = back.add(right.scale(-0.65));
            Vec3 rightTip = back.add(right.scale(0.65));
            PixelFx.send(sl, particle, leftTip.x, leftTip.y, leftTip.z, 1, 0.04, 0.04, 0.04, 0.01);
            PixelFx.send(sl, particle, rightTip.x, rightTip.y, rightTip.z, 1, 0.04, 0.04, 0.04, 0.01);
        } catch (Throwable ignored) {}
    }

    /** Explosion ponctuelle centrée sur le buste d'une entité. */
    public static void burstOnEntity(Entity target, ParticleOptions particle, int count, double spread, double speed) {
        if (target == null || !(target.level() instanceof ServerLevel sl)) return;
        try {
            PixelFx.send(sl, particle,
                    target.getX(), target.getY() + target.getBbHeight() * 0.52, target.getZ(),
                    Math.max(1, Math.min(36, count)), spread, spread, spread, speed);
        } catch (Throwable ignored) {}
    }

    /**
     * T307-CLOUD : Coussin de nuages cotonneux directement sous les pieds du joueur
     * (Marcheur des Nuages triple saut, Marche Aérienne, Foulée des Nuages, rebonds aériens).
     */
    public static void cloudCushion(ServerLevel sl, double x, double y, double z, double radius, boolean radiant) {
        if (sl == null) return;
        try {
            double r = Math.max(0.35, Math.min(2.2, radius));
            // Cœur cotonneux dense juste sous les semelles
            PixelFx.send(sl, ParticleTypes.CLOUD, x, y, z, radiant ? 12 : 7, r * 0.36, 0.04, r * 0.36, 0.012);
            // Couronne horizontale de nuage qui s'évase doucement
            int pts = radiant ? 14 : 9;
            for (int i = 0; i < pts; i++) {
                double ang = (Math.PI * 2.0 * i) / pts;
                double px = x + Math.cos(ang) * r;
                double pz = z + Math.sin(ang) * r;
                PixelFx.send(sl, ParticleTypes.CLOUD, px, y + 0.02, pz, 1, 0.05, 0.02, 0.05, 0.008);
                if (radiant && (i & 1) == 0) {
                    PixelFx.send(sl, CLOUD_WHITE, px * 0.5 + x * 0.5, y + 0.03, pz * 0.5 + z * 0.5, 1, 0.03, 0.02, 0.03, 0.0);
                }
            }
            if (radiant) {
                PixelFx.send(sl, ParticleTypes.WHITE_ASH, x, y + 0.05, z, 6, r * 0.45, 0.05, r * 0.45, 0.01);
            }
        } catch (Throwable ignored) {}
    }
}
