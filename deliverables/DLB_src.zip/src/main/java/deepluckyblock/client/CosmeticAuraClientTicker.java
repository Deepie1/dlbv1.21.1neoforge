package deepluckyblock.client;

import deepluckyblock.DeepLuckyBlockMod;
import deepluckyblock.enchantments.EnchantmentComboRegistry;
import deepluckyblock.enchantments.EnchantmentComboRegistry.ComboMask;
import deepluckyblock.util.DeepEnchant;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * T321-CONTINUOUS-COSMETIC-FX : Moteur client temps réel d'auras, halos, couronnes et rubans d'ailes.
 *
 * Pourquoi côté Client (ClientTickEvent.Post) et non via des salves serveur espacées (% 20..200) ?
 *  1) Continuité infinie : les particules sont émises à chaque tick directement sur la position +
 *     vélocité courante de l'entité -> le halo (ex. Combo #110, Roi, Esprit Mystique, Égide Radieuse,
 *     ailes d'Archange...) suit le joueur en continu sans jamais clignoter ni rester figé derrière lui.
 *  2) Zéro paquet réseau & zéro charge serveur (0.00 ms TPS).
 *  3) Ultra-optimisé anti-lag : profil cosmétique mis en cache sur un simple int bitmask toutes les
 *     10 ticks (0,5 s), culling à 24 blocs, pause automatique et plafond strict de particules/tick.
 */
@EventBusSubscriber(modid = DeepLuckyBlockMod.MODID, value = Dist.CLIENT)
public final class CosmeticAuraClientTicker {

    private CosmeticAuraClientTicker() {}

    public static final int F_COMBO_110_AVATAR      = 1;
    public static final int F_COMBO_097_ETERNAL     = 1 << 1;
    public static final int F_COMBO_098_SWORD_GOD   = 1 << 2;
    public static final int F_COMBO_101_ARCHANGEL   = 1 << 3;
    public static final int F_COMBO_106_WARLORD     = 1 << 4;
    public static final int F_COMBO_062_PLAGUE      = 1 << 5;
    public static final int F_ENCH_KING             = 1 << 6;
    public static final int F_ENCH_MYSTIC_MIND      = 1 << 7;
    public static final int F_ENCH_RADIANT_AEGIS    = 1 << 8;
    public static final int F_ENCH_WINGED_ENDURANCE = 1 << 9;
    public static final int F_ENCH_DREAD_AURA       = 1 << 10;
    /** Halo générique, limité aux armes dont le choix Lucky Block persisté l'autorise. */
    public static final int F_HALO_CONTINUOUS       = 1 << 11;

    /**
     * T436 : deux cosmétiques de plus quittent le monde des particules vanilla pour celui des
     * pixels. Ils existaient déjà côté serveur ({@code EnchantmentParticleFX.cloudCushion} et
     * {@code shockwaveRing}) mais AUCUN bit ne les portait jusqu'au rendu : le joueur ne voyait
     * qu'un nuage de particules génériques, jamais la galette ni les anneaux de l'aperçu.
     */
    public static final int F_ENCH_CLOUD_CUSHION   = 1 << 12;
    public static final int F_ENCH_LANDING_WAVE    = 1 << 13;

    /**
     * T436 : les deux derniers ornements de JOUEUR qui n'existaient qu'en particules.
     * Les trois restants ({@code doubleHelix}, {@code tetherBeam}, {@code burstOnEntity})
     * ne sont pas des ornements portés : ce sont des effets de combat tirés à une position
     * arbitraire ou entre deux entités. Ils ne se déduisent pas de l'équipement et
     * demanderaient un paquet serveur dédié — ils restent donc en particules.
     */
    public static final int F_ENCH_CROWN_HALO      = 1 << 14;
    public static final int F_ENCH_WING_RIBBONS    = 1 << 15;

    /** Les ornements posés au sol : ce sont eux, et eux seuls, qui laissent une traînée. */
    public static final int F_SOL = F_COMBO_106_WARLORD | F_COMBO_062_PLAGUE | F_ENCH_DREAD_AURA;

    /** T349 : rayon de collecte des profils cosmétiques (rendu fait par CosmeticPixelAura). */
    private static final double CULL_DIST_SQR = 40.0 * 40.0;

    private static final class CachedProfile {
        int flags;
        long expiresAt;
    }

    private static final Map<Integer, CachedProfile> PROFILE_CACHE = new HashMap<>();
    private static ClientLevel cachedLevel = null;
    private static long lastGameTime = -1L;

    @SubscribeEvent
    public static void onClientTickPost(ClientTickEvent.Post event) {
        try {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer viewer = mc.player;
            ClientLevel level = mc.level;
            if (viewer == null || level == null) return;

            if (cachedLevel != level) {
                PROFILE_CACHE.clear();
                CosmeticTrail.vide();          // les pas d'un autre monde n'ont plus de sens
                cachedLevel = level;
                lastGameTime = -1L;
            }

            long now = level.getGameTime();
            // En pause solo, gameTime n'avance pas -> 0 particule émise pendant l'écran pause !
            if (now == lastGameTime) return;
            lastGameTime = now;

            DeepEnchant.rememberClientAccess(level.registryAccess());

            if ((now & 127L) == 0L && PROFILE_CACHE.size() > 64) {
                Iterator<Map.Entry<Integer, CachedProfile>> it = PROFILE_CACHE.entrySet().iterator();
                while (it.hasNext()) {
                    if (now > it.next().getValue().expiresAt + 100L) it.remove();
                }
            }

            // T349-COSMETIC-PIXEL-AURA : PLUS AUCUNE particule émise ici.
            // Le tick ne sert plus qu'à rafraîchir le bitmask (cache 10 ticks, gratuit) ; le dessin des
            // ailes / couronnes / auras est fait une seule fois par frame par CosmeticPixelAura.
            // T456 : le traceur T443 est retire pour la publication. L'appel reste :
            // getCosmeticFlags remplit le cache de drapeaux lu ensuite par le rendu.
            getCosmeticFlags(viewer, now);

            // T436 : la traînée au sol est une mémoire de pas en coordonnées monde. On la
            // nourrit ici, une fois par tick : c'est ce qui la fait se rétracter à l'arrêt
            // et se redéployer au départ, au lieu de défiler bêtement avec le temps.
            int fv = getCosmeticFlags(viewer, now);
            if ((fv & F_SOL) != 0) CosmeticTrail.suivre(viewer, now);
            if ((fv & (F_ENCH_CLOUD_CUSHION | F_ENCH_LANDING_WAVE)) != 0) {
                if ((fv & F_ENCH_CLOUD_CUSHION) != 0) CosmeticTrail.suivre(viewer, now);
                CosmeticTrail.noteChute(viewer, now);
            }

            List<? extends Player> nearbyPlayers = level.players();
            for (int i = 0, n = nearbyPlayers.size(); i < n; i++) {
                Player other = nearbyPlayers.get(i);
                if (other == viewer || !other.isAlive() || other.isSpectator()) continue;
                if (other.distanceToSqr(viewer) > CULL_DIST_SQR) continue;
                int fo = getCosmeticFlags(other, now);
                if ((fo & (F_SOL | F_ENCH_CLOUD_CUSHION)) != 0) CosmeticTrail.suivre(other, now);
                if ((fo & F_ENCH_LANDING_WAVE) != 0) CosmeticTrail.noteChute(other, now);
            }
            if ((now & 63L) == 0L) CosmeticTrail.nettoie(now);
        } catch (Throwable ignored) {}
    }

    public static int getCosmeticFlags(LivingEntity entity, long now) {
        CachedProfile cp = PROFILE_CACHE.get(entity.getId());
        if (cp != null && now < cp.expiresAt) {
            return cp.flags;
        }
        if (cp == null) {
            cp = new CachedProfile();
            PROFILE_CACHE.put(entity.getId(), cp);
        }
        cp.expiresAt = now + 10L;

        // T350-COSMETIC-RELIABLE : on lit d'abord le masque de combos (les 6 pièces d'un combo
        // suffisent, même si l'équipement n'est pas "classiquement" enchanté). L'ancien garde-fou
        // "aucun équipement enchanté -> 0" pouvait couper le halo du Combo #110 alors que le combo
        // était actif : c'est exactement le symptôme "le halo ne fonctionne plus".
        int f = 0;
        ComboMask mask = EnchantmentComboRegistry.getActiveMask(entity);
        if (!mask.isEmpty()) {
            if (mask.has(EnchantmentComboRegistry.IDX_AVATAR_SUPREME_DEEP_LUCKY)) f |= F_COMBO_110_AVATAR;
            if (mask.has(EnchantmentComboRegistry.IDX_ARMURE_ETERNELLE_TRANSCENDANTE)) f |= F_COMBO_097_ETERNAL;
            if (mask.has(EnchantmentComboRegistry.IDX_DIEU_LAME_SUPREME)) f |= F_COMBO_098_SWORD_GOD;
            if (mask.has(EnchantmentComboRegistry.IDX_ARCHANGE_JUGEMENT_SOLAIRE)) f |= F_COMBO_101_ARCHANGEL;
            if (mask.has(EnchantmentComboRegistry.IDX_SEIGNEUR_GUERRE_APOCALYPSE)) f |= F_COMBO_106_WARLORD;
            if (mask.has(EnchantmentComboRegistry.IDX_PESTE_AMBULANTE)) f |= F_COMBO_062_PLAGUE;
        }

        // T452 : AUCUN COSMETIQUE SANS COMBO ACTIF. L'ancienne garde demandait
        // « porte-t-il un equipement enchante ? » : une propriete d'inventaire, qui
        // laissait passer tous les drapeaux poses plus bas sur un simple enchantement.
        // Le masque est maintenant la seule porte d'entree.
        if (mask.isEmpty()) {
            cp.flags = 0;
            return 0;
        }

        // T452 : CES NEUF DRAPEAUX SE DECIDENT SUR LE COMBO, PLUS SUR L'ITEM.
        // Ils lisaient surLoot(entity, "deep_lucky_block:X") : « une piece d'armure
        // venue du loot porte-t-elle l'enchantement X ? ». C'etait encore une
        // propriete d'item. Ils lisent desormais comboActif(mask, "X") : « un combo
        // ACTIF exige-t-il X ? ». Un combo porte un nom et s'affiche en infobulle,
        // donc le joueur peut nommer ce qu'il voit -- c'etait tout le reproche fait
        // au halo. Le lien cosmetique <-> enchantement est conserve, mais c'est le
        // combo qui l'allume : sans combo actif, aucun cosmetique. Consequence
        // acceptee explicitement.
        if (comboActif(mask, "king")) f |= F_ENCH_KING;
        if (comboActif(mask, "mystic_mind")) f |= F_ENCH_MYSTIC_MIND;
        if (comboActif(mask, "heart_resonance")) f |= F_ENCH_RADIANT_AEGIS;
        // T453 : LA VOILURE EST RATTACHEE A TROIS COMBOS EXISTANTS.
        // wing_toughness_armor n'appartient a aucun des 310 combos ; apres T452, ce
        // drapeau ne pouvait donc plus jamais s'allumer. Il passe au meme mecanisme
        // que les six combos a cosmetique dedie : un index, pas un enchantement.
        // Les trois retenus sont les seuls a reunir AILES et ENDURANCE, et tous
        // reposent sur l'elytre -- ce qui colle au rendu, une voilure que
        // CosmeticPixelAura ne trace qu'en l'air (!onGround() || isFallFlying()).
        //   #72  belier_ailes_fer             EPIC   iron_wings / winging + dash
        //   #169 ailes_orageuses_maitrisees   RARE   maledictions d'ailes + veil
        //   #199 aeronaute_supersonique_royal MYTHIC wind_rider + iron_wings + air_walk
        if (mask.has(EnchantmentComboRegistry.IDX_BELIER_AILES_FER)
                || mask.has(EnchantmentComboRegistry.IDX_AILES_ORAGEUSES_MAITRISEES)
                || mask.has(EnchantmentComboRegistry.IDX_AERONAUTE_SUPERSONIQUE_ROYAL)) {
            f |= F_ENCH_WINGED_ENDURANCE;
        }
        if (comboActif(mask, "dread_aura")) f |= F_ENCH_DREAD_AURA;

        if (comboActif(mask, "cloud_walker", "air_walk", "cloud_stride")) {
            f |= F_ENCH_CLOUD_CUSHION;
        }
        if (comboActif(mask, "crash_landing", "meteor_stomp")) {
            f |= F_ENCH_LANDING_WAVE;
        }
        if (comboActif(mask, "general")) f |= F_ENCH_CROWN_HALO;
        // Le VOL PLANE reste exige : c'est une situation, pas une propriete d'item,
        // et des banderoles au sol montreraient une parure que le jeu ne produit
        // jamais. isFallFlying() implique deja l'elytre, donc le test d'item et le
        // isModLoot qui l'accompagnait disparaissent avec le reste.
        if (entity.isFallFlying() && comboActif(mask, "aerodynamic", "wind_rider")) {
            f |= F_ENCH_WING_RIBBONS;
        }

        // T451 : LE HALO EST LA SIGNATURE D'UN COMBO, PLUS CELLE D'UN ITEM.
        // Il venait de hasContinuousWeaponHalo(entity) : un booleen tire UNE FOIS a la
        // creation du butin, que rien n'affiche. Combine a la condition « f == 0 »,
        // il s'allumait donc PRECISEMENT quand aucun combo n'etait actif -- d'ou le
        // « wtf pourquoi un halo vient au dessus de ma tete ? » avec une arbalete
        // Flame + Quick Charge, et le diagnostic drapeaux=0x800 combos=0 : un
        // cosmetique qu'AUCUNE infobulle ne pouvait justifier.
        // Il exige desormais un combo reellement actif. Le sens s'inverse : au lieu
        // d'etre le lot de consolation de « aucun combo », le halo devient le blason
        // generique des combos qui n'ont pas de cosmetique dedie (seuls 6 des 310 en
        // ont un). combos=0 ne peut plus produire de halo.
        if (f == 0 && !mask.isEmpty()) f |= F_HALO_CONTINUOUS;

        cp.flags = f;
        return f;
    }

    /**
     * T452 : un combo ACTIF exige-t-il l'un de ces enchantements ?
     * Remplace surLoot(...), qui interrogeait l'armure portee. Les chemins sont donnes
     * SANS espace de noms : c'est la forme stockee par BY_ENCHANT_PATH.
     * Un combo actif implique deja que le joueur porte l'enchantement -- c'est sa
     * condition d'activation -- donc rien n'est perdu cote verification d'equipement.
     */
    private static boolean comboActif(ComboMask mask, String... chemins) {
        if (mask.isEmpty()) return false;
        for (String chemin : chemins) {
            for (EnchantmentComboRegistry.ComboDef def
                    : EnchantmentComboRegistry.combosForEnchantPath(chemin)) {
                if (mask.has(def.index())) return true;
            }
        }
        return false;
    }

    /**
     * T349 : plus aucune particule. Conservé vide volontairement pour ne rien casser côté appelants
     * éventuels : le cosmétique est désormais intégralement rendu en mini-cubes 3D par
     * {@link CosmeticPixelAura} (formes d'ailes réelles, couronnes en anneau, auras au sol).
     */
    private static int emitForEntity(ClientLevel level, LivingEntity entity, long now, int budget) {
        return budget;
    }
}
