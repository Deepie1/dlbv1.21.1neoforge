package deepluckyblock.enchantments;

import java.util.Locale;

/**
 * T350-ELEMENT-FAMILIES : familles élémentaires (système chinois Wu Xing étendu) qui pilotent
 * désormais la couleur, l'ordre d'affichage et le choix des animations d'enchantement.
 *
 * <p><b>Pourquoi ?</b> Les VFX d'arme étaient classés par « catégorie technique » (tranchant, critique,
 * sang, élément, distance, spécial) et joués dans un ordre hérité de la priorité : le résultat était un
 * mélange d'animations très différentes qui semblaient sortir « n'importe quand ». On trie maintenant
 * par <b>famille élémentaire</b>, ce qui donne une couleur et une ambiance cohérentes :
 * feu = rouge/orange, poison & nature = vert, eau & givre = bleu, foudre = violet/bleu avec surbrillance jaune pâle,
 * métal = gris neutres, terre = vert clair/terre, lumière = blanc doré, ombre = violet/noir, sang = rouge, vide = gris/noir.</p>
 *
 * <p>Les cinq éléments chinois classiques sont présents (Bois, Feu, Terre, Métal, Eau), complétés par
 * Foudre, Lumière et Ombre (demandés explicitement), plus Sang et Vide qui existaient déjà dans le mod.</p>
 */
public enum DeepElement {

    /**
     * 木 Bois / nature / forêt / récolte — <b>BRUN</b> (écorce, planches, sève).
     * T352b : le bois n'est plus vert ; le vert sombre appartient au Poison, désormais séparé.
     */
    WOOD("Bois", 0xA9743C, 0x5A3617, 0xE0B87E),
    /**
     * 毒 Poison / venin / miasme / peste — <b>VERT FONCÉ</b> (famille distincte depuis T352b :
     * avant, le poison était mélangé au Bois et prenait sa couleur verte).
     */
    POISON("Poison", 0x1E7A32, 0x0A3D16, 0x63E05C),
    /** 火 Feu / lave / météore / braise (rouge-orangé). */
    FIRE("Feu", 0xFF4A10, 0xB01B00, 0xFFE08A),
    /** 土 Terre / sol / séisme / sable — <b>VERT CLAIR + BRUN</b> (herbe sur terre, T352b). */
    EARTH("Terre", 0x9FC25E, 0x5C3B1A, 0xD6E39B),
    /** 金 Métal / acier / tranchant — trois gris neutres distincts, sans blanc ni noir pur. */
    METAL("Métal", 0x9EA3AA, 0x747A82, 0xC4C8CD),
    /** 水 Eau / glace / océan / givre — bleus clairs, rendus translucides par le matériau. */
    WATER("Eau", 0x62C7E8, 0x92DDF1, 0xD4F3FB),
    /** T373 : 雷 Foudre / éclair / surcadence (violet électrique, bleu profond, surbrillance jaune pâle). */
    THUNDER("Foudre", 0x5E3AFF, 0x1E26FF, 0xFCFFBA),
    /** 光 Lumière / saint / astral / or radieux. */
    LIGHT("Lumière", 0xFFF3B0, 0xFFB01F, 0xFFFFFF),
    /** T373 : 暗 Ombre / spectre / effroi / wither (violet ardoise, noir, accent violet vif). */
    SHADOW("Ombre", 0x4D318E, 0x000000, 0x7100A7),
    /** T373 : Sang / vampirisme (rouges purs) — famille historique du mod. */
    BLOOD("Sang", 0xDD0000, 0xB20000, 0xFF0000),
    /** T373 : Vide / ender / dragon / warp (gris charbon, noir et gris clair). */
    VOID("Vide", 0x444444, 0x000000, 0x5B5B5B),
    /**
     * 乱 Chaos / entropie / discordance prismatique.
     * Le corps conserve une base très sombre et stable. Seuls les contours reçoivent les teintes
     * dynamiques de {@link #chaosEdge(float, float)}, avec plusieurs phases visibles simultanément.
     */
    CHAOS("Chaos", 0x2B0B38, 0x120616, 0x5B2A68);

    public final String displayName;
    public final int primary;
    public final int secondary;
    public final int highlight;

    DeepElement(String displayName, int primary, int secondary, int highlight) {
        this.displayName = displayName;
        this.primary = primary;
        this.secondary = secondary;
        this.highlight = highlight;
    }

    /**
     * T350-CURSE-NO-FX : les malédictions ne produisent AUCUN glint ni particule custom.
     * Détection par mots-clés sur le chemin d'enregistrement (vanilla + enchantements du mod).
     */
    public static boolean isCursePath(String path) {
        if (path == null) return false;
        String s = path.toLowerCase(Locale.ROOT);
        return s.contains("curse") || s.contains("cursed") || s.contains("malediction")
                || s.contains("blemish") || s.contains("unlucky") || s.contains("calamity")
                || s.contains("penalty") || s.contains("handicap");
    }

    /**
     * Famille élémentaire déduite du chemin d'un enchantement (mêmes mots-clés que
     * {@code DeepGlintColor}, mais centralisés ici et exprimés en familles).
     */
    public static DeepElement fromEnchantPath(String path) {
        if (path == null) return METAL;
        String s = path.toLowerCase(Locale.ROOT);
        if (isCursePath(s)) return SHADOW;

        // Foudre
        if (s.contains("thunder") || s.contains("lightning") || s.contains("storm")
                || s.contains("channeling") || s.contains("electric") || s.contains("overclock")
                || s.contains("overcharge") || s.contains("sonic") || s.contains("echo")
                || s.contains("voltaic") || s.contains("galvan") || s.contains("discharge")) {
            return THUNDER;
        }
        // T352b : POISON (vert foncé) est une famille à part entière — testée AVANT le Bois.
        if (s.contains("poison") || s.contains("venom") || s.contains("toxic")
                || s.contains("fang") || s.contains("scorpion") || s.contains("plague")
                || s.contains("peste") || s.contains("miasma") || s.contains("blight")
                || s.contains("corrode") || s.contains("corrosion") || s.contains("acid")
                || s.contains("contagion") || s.contains("disease") || s.contains("virul")) {
            return POISON;
        }
        // Bois / nature / forêt / récolte -> BRUN (couleur de l'écorce et des planches)
        if (s.contains("nature") || s.contains("harvest") || s.contains("wood")
                || s.contains("lumber") || s.contains("tree") || s.contains("replant")
                || s.contains("farm") || s.contains("crop") || s.contains("timber")
                || s.contains("plank") || s.contains("bark") || s.contains("forest")
                || s.contains("thorn") || s.contains("briar") || s.contains("root")
                || s.contains("vine") || s.contains("bloom") || s.contains("sap")
                || s.contains("spore") || s.contains("moss")) {
            return WOOD;
        }
        // Feu
        if (s.contains("fire") || s.contains("flame") || s.contains("blaze")
                || s.contains("lava") || s.contains("magma") || s.contains("meteor")
                || s.contains("phoenix") || s.contains("scorch") || s.contains("ember")
                || s.contains("infernal") || s.contains("brimstone") || s.contains("molten")
                || s.contains("burning") || s.contains("soul_fire") || s.contains("volcan")
                || s.contains("cinder") || s.contains("pyro") || s.contains("ignite")) {
            return FIRE;
        }
        // Eau / glace
        if (s.contains("water") || s.contains("ocean") || s.contains("ice")
                || s.contains("frost") || s.contains("conduit") || s.contains("hydro")
                || s.contains("tide") || s.contains("undertow") || s.contains("snow")
                || s.contains("riptide") || s.contains("abyss") || s.contains("maelstrom")) {
            return WATER;
        }
        // Terre / roche / séisme
        if (s.contains("earth") || s.contains("seismic") || s.contains("tectonic")
                || s.contains("rock") || s.contains("stone") || s.contains("quake")
                || s.contains("sand") || s.contains("mountain") || s.contains("bulwark")
                || s.contains("soil") || s.contains("dirt") || s.contains("clay")
                || s.contains("terracotta") || s.contains("dune") || s.contains("golem")) {
            return EARTH;
        }
        // Sang / vampirisme
        if (s.contains("blood") || s.contains("leech") || s.contains("vamp")
                || s.contains("devour") || s.contains("execute") || s.contains("behead")
                || s.contains("guillotine") || s.contains("carnage") || s.contains("siphon")) {
            return BLOOD;
        }
        // Ombre / spectre / effroi
        if (s.contains("shadow") || s.contains("phantom") || s.contains("veil")
                || s.contains("stealth") || s.contains("ghost") || s.contains("wraith")
                || s.contains("dark") || s.contains("dread") || s.contains("wither")
                || s.contains("soul") || s.contains("night")) {
            return SHADOW;
        }
        // T352-CHAOS-ELEMENT : chaos / entropie / prismatique / discorde (avant le Vide, sinon
        // « chaos » retombait dans la famille Vide).
        if (s.contains("chaos") || s.contains("entropy") || s.contains("prism")
                || s.contains("discord") || s.contains("anarch") || s.contains("kaleido")
                || s.contains("pandemon") || s.contains("mirage")) {
            return CHAOS;
        }
        // Vide / ender / dragon
        if (s.contains("void") || s.contains("ender") || s.contains("dragon")
                || s.contains("warp") || s.contains("portal")
                || s.contains("null") || s.contains("singular")) {
            return VOID;
        }
        // Lumière / saint / astral
        if (s.contains("light") || s.contains("holy") || s.contains("seraph")
                || s.contains("astral") || s.contains("radiant") || s.contains("celestial")
                || s.contains("star") || s.contains("sun") || s.contains("halo")
                || s.contains("angel") || s.contains("king") || s.contains("divine")) {
            return LIGHT;
        }
        // Métal par défaut (tranchant, acier, or, critiques)
        return METAL;
    }

    /** Nombre de familles (masque de bits utilisable sur 16 bits). */
    public static final int COUNT = values().length;

    /** Masque de bits des familles (bit {@code ordinal()}). */
    public static final int MASK_ALL = (1 << COUNT) - 1;

    /**
     * Couleur d'un CONTOUR de Chaos. La phase spatiale {@code offset} permet à plusieurs bandes
     * colorées de coexister sur le même pourtour; le temps les déplace ensemble, sans aléa par frame.
     * La luminosité reste contrôlée et la base de l'effet n'entre pas dans ce calcul : elle doit
     * continuer à utiliser les trois rôles sombres ci-dessus. Réservé exclusivement à Chaos.
     */
    public static int chaosEdge(float timeSeconds, float offset) {
        float hue = (timeSeconds * 0.18f + offset) % 1.0f;
        if (hue < 0.0f) hue += 1.0f;
        float pulse = (float) Math.sin((timeSeconds * 0.45f + offset) * Math.PI * 2.0);
        float brightness = 0.80f + 0.12f * pulse;
        return net.minecraft.util.Mth.hsvToRgb(hue, 0.84f, brightness);
    }

    /** Adoucit un pixel vers la surbrillance déclarée de sa famille, sans injecter de blanc neutre. */
    public int tint(int rgb, float amount) {
        float a = Math.max(0.0f, Math.min(1.0f, amount));
        int r = (int) (((rgb >> 16) & 0xFF) * (1.0f - a) + ((highlight >> 16) & 0xFF) * a);
        int g = (int) (((rgb >> 8) & 0xFF) * (1.0f - a) + ((highlight >> 8) & 0xFF) * a);
        int b = (int) ((rgb & 0xFF) * (1.0f - a) + (highlight & 0xFF) * a);
        return (r << 16) | (g << 8) | b;
    }
}
