package deepluckyblock.enchantments;

import deepluckyblock.DeepLuckyBlockMod;
import deepluckyblock.enchantments.DeepElement;
import deepluckyblock.enchantments.WeaponVfxSubtle;
import deepluckyblock.network.DeepPayloads;
import deepluckyblock.procedures.TestProcedure;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * T343-VOXEL-SERVER-SYNC : Diffusion serveur S2C 100 % fonctionnelle des 30 effets d'armes :
 * <ul>
 *   <li>Synchronise les sillages de mini-pixels 3D en direct sur chaque flèche, carreau et trident
 *       enchanté dès leur apparition ({@link EntityJoinLevelEvent}).</li>
 *   <li>Gère les salves multi-flèches ({@code fan_volley}, {@code scatter}, {@code multishot}),
 *       les coups à dégâts nuls ({@code blood_transfusion}, {@code curse_of_mercy}, {@code toy}),
 *       les critiques mêlée et distance, les gantelets à mains nues et les bannières clic-droit.</li>
 * </ul>
 */
@EventBusSubscriber(modid = DeepLuckyBlockMod.MODID)
public final class WeaponVfxServerListener {

    // T346-VFX-TEST : kinds exposés publiquement pour la commande de test /dlbvfx
    public static final int KIND_SWING_SLASH       = 0;
    public static final int KIND_IMPACT            = 1;
    public static final int KIND_BEAM_SIPHON       = 2;
    public static final int KIND_PROJECTILE_ATTACH = 3;
    public static final int KIND_METEOR_TRACK = 4;

    private static final Map<Integer, Long> LAST_ATTACKER_HIT_TICK = new ConcurrentHashMap<>();
    private static final Map<Integer, Long> LAST_PROJECTILE_HIT_TICK = new ConcurrentHashMap<>();
    private static final Map<Integer, Long> LAST_CRIT_TICK = new ConcurrentHashMap<>();
    private static final Map<Integer, Long> LAST_RALLY_TICK = new ConcurrentHashMap<>();
    /** T351-BIG-BONUS : dernier tick où une GROSSE animation (critique) a été jouée, par attaquant. */
    private static final Map<Integer, Long> LAST_BIG_ANIM_TICK = new ConcurrentHashMap<>();
    /** T352-ELEMENT-COMBO : dernier tick d'un combo multi-éléments, par attaquant (anti-doublon). */
    private static final Map<Integer, Long> LAST_ELEMENT_COMBO_TICK = new ConcurrentHashMap<>();
    /** T349-VFX-FREQUENCY : cooldown réel et aléatoire par (attaquant, effet). */
    private static final Map<String, Long> EFFECT_COOLDOWN = new ConcurrentHashMap<>();
    /** Emprises Wood : immobilisation seule ou stun complet, expiration et état NoAi à restaurer. */
    private static final Map<Integer, WoodHold> WOOD_HOLDS = new ConcurrentHashMap<>();
    /** Soul Fire : montée, maintien au centre de la lune, descente et restauration de l'IA. */
    private static final Map<Integer, SoulHold> SOUL_HOLDS = new ConcurrentHashMap<>();
    /** Combustion Soul réelle : 80 ticks de flammes bleues et de dégâts périodiques. */
    private static final Map<Integer, SoulBurn> SOUL_BURNS = new ConcurrentHashMap<>();
    private static final int SIGNATURE_FIRE_TICKS = 80;
    private static final int METEOR_AOE_FIRE_TICKS = 60;
    private static final int METEOR_IMPACT_TICKS = 30;
    private static final double METEOR_FIRE_RADIUS = 4.0;

    private record WoodHold(long expires, double x, double y, double z, boolean previousNoAi, boolean fullStun) { }
    private record SoulHold(long expires, long riseStart, long riseEnd, long descendStart,
                            double x, double baseY, double targetY, double z, boolean previousNoAi) { }
    private record SoulBurn(long expires, long nextDamage) { }

    /** T351 : attaque NORMALE -> 5 % de chance de déclencher l'animation pixel. */
    private static final int NORMAL_TRIGGER_PERCENT = 5;
    /** T351 : coup CRITIQUE -> 66 % de chance ; T359-CRIT-RATE : +10 points -> 76 %. */
    private static final int CRIT_TRIGGER_PERCENT = 76;
    /** T351 : part des déclenchements qui jouent un accent discret. */
    private static final int SUBTLE_SHARE_PERCENT = 90;
    /** Ancien bonus du pipeline projectile/critique manuel, conservé hors de la nouvelle mêlée. */
    private static final float BIG_ANIM_DAMAGE_BONUS = 1.05f;
    /** Mêlée éligible : un seul jet 0..99 = normal 0..76, slash 77..96, grande forme 97..99. */
    private static final int MELEE_NORMAL_MAX_ROLL = 76;
    private static final int MELEE_SLASH_MAX_ROLL = 96;
    private static final float MELEE_SLASH_DAMAGE_MULTIPLIER = 1.05f;
    /** Toute grande forme reste réellement agrandie, même sur une très petite cible. */
    private static final float BIG_VISUAL_BASE_SCALE = 1.20f;
    private static final float BIG_VISUAL_MEASURED_FACTOR = 0.55f;
    /**
     * T352-ELEMENT-COMBO : sur une arme portant PLUSIEURS éléments, 6 % de chance de jouer en
     * simultané une grosse animation de CHAQUE famille présente (une couleur par élément).
     */
    private static final int ELEMENT_COMBO_PERCENT = 6;
    /** Garde-fou : au-delà de 6 éléments, on se limite aux 6 plus prioritaires (anti-spam réseau). */
    private static final int ELEMENT_COMBO_MAX = 6;

    private WeaponVfxServerListener() {}

    /**
     * T359-BIG-ANIM-SCALE : échelle des grosses animations d'après le VOLUME du mob touché.
     *
     * <p>Référence = joueur / zombie (0,6 × 0,6 × 1,8) -> 1.0. Le facteur suit la racine du
     * rapport de volume, borné entre <b>0.30</b> (poulet, poisson, silverfish : animation
     * minuscule) et <b>4.0</b> (ravager, wither, dragon : animation énorme).</p>
     */
    private static float sizeScaleOf(Entity entity) {
        if (entity == null) return 1.0f;
        double width = Math.max(0.05, entity.getBbWidth());
        double height = Math.max(0.05, entity.getBbHeight());
        double volume = width * width * height;
        double reference = 0.6 * 0.6 * 1.8;                 // joueur / zombie standard
        float scale = (float) Math.sqrt(volume / reference);
        return net.minecraft.util.Mth.clamp(scale, 0.30f, 4.0f);
    }

    /**
     * Classe l'échelle mesurée dans l'intervalle existant 0.30..4.0, puis la convertit en bonus
     * entier de 5 à 15 %. Aucun second tirage : une cible plus grande donne toujours un bonus
     * supérieur ou égal, et le même résultat pilote la taille de la grande animation.
     */
    private static int bigMeleeBonusPercent(float measuredScale) {
        float rank = (measuredScale - 0.30f) / (4.0f - 0.30f);
        return 5 + Math.round(net.minecraft.util.Mth.clamp(rank, 0.0f, 1.0f) * 10.0f);
    }

    /** Échelle visuelle monotone 1.365..3.40 : toujours une GRANDE animation, jamais une miniature. */
    private static float bigMeleeVisualScale(float measuredScale) {
        return BIG_VISUAL_BASE_SCALE + BIG_VISUAL_MEASURED_FACTOR * measuredScale;
    }

    /** Échelle exacte d'une grosse frappe de mêlée sur cette cible, pour {@code /dummytest}. */
    public static float debugBigMeleeScale(Entity target) {
        return bigMeleeVisualScale(sizeScaleOf(target));
    }

    /** Marque le coup critique du tick ; l'animation correspondante est choisie une seule fois dans onLivingHurtVisuals. */
    public static void markMeleeCrit(Player attacker) {
        if (attacker == null || !(attacker.level() instanceof ServerLevel sl)) return;
        LAST_CRIT_TICK.put(attacker.getId(), sl.getGameTime());
    }

    /** Démonstration explicite d'un effet critique (la mécanique normale passe par markMeleeCrit). */
    public static void notifyMeleeCrit(Player attacker, Entity target,
                                       WeaponVisualEffectId critStyle, int intensity) {
        if (attacker == null || target == null) return;
        if (!(attacker.level() instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        LAST_CRIT_TICK.put(attacker.getId(), now);

        WeaponVisualEffectId fx = (critStyle != null) ? critStyle : WeaponVisualEffectId.GOLDEN_CRIT_STAR;

        // T351/T359 : sur un coup critique, 76 % de chance de déclencher l'animation pixel.
        if (sl.random.nextInt(100) >= CRIT_TRIGGER_PERCENT) return;
        String critKey = "crit:" + attacker.getId() + ":" + fx.id;
        Long critReady = EFFECT_COOLDOWN.get(critKey);
        if (critReady != null && now < critReady) return;
        EFFECT_COOLDOWN.put(critKey, now + 16L + sl.random.nextInt(20));

        float cx = (float) target.getX();
        float cy = (float) (target.getY() + target.getBbHeight() * 0.55);
        float cz = (float) target.getZ();

        // T351 : la plupart des critiques jouent seulement un accent discret (bien plus subtil).
        // Ne lance pas le combo multicolore avant ce choix : sinon un accent discret pouvait quand
        // même être accompagné de plusieurs grosses animations élémentaires simultanées.
        if (playSubtleAccent(sl, attacker.getMainHandItem(), fx, cx, cy, cz,
                (float) attacker.getX(), (float) attacker.getEyeY(), (float) attacker.getZ())) {
            return;
        }

        // T352-ELEMENT-COMBO : combo possible uniquement quand le tirage a choisi une vraie grosse anim.
        tryElementCombo(sl, attacker.getId(), attacker.getMainHandItem(), cx, cy, cz,
                (float) attacker.getX(), (float) attacker.getEyeY(), (float) attacker.getZ(),
                sizeScaleOf(target), target);

        // Grosse animation jouée -> le dégât de ce coup sera amplifié de 5 % (voir onLivingHurtVisuals).
        LAST_BIG_ANIM_TICK.put(attacker.getId(), now);
        broadcastNear(sl, cx, cy, cz, fx.id, KIND_IMPACT, Math.max(2, intensity),
                cx, cy, cz, (float) attacker.getX(), (float) attacker.getEyeY(), (float) attacker.getZ(),
                paletteOf(attacker.getMainHandItem(), fx), sizeScaleOf(target));
        applyFireGameplay(attacker, target, fx, sizeScaleOf(target));
    }

    /** Appelé lors d'un rebond d'éclair en chaîne entre deux entités. */
    public static void notifyChainArc(ServerLevel sl, Entity from, Entity to, int level) {
        if (sl == null || from == null || to == null) return;
        float fx = (float) from.getX();
        float fy = (float) (from.getY() + from.getBbHeight() * 0.5);
        float fz = (float) from.getZ();
        float tx = (float) to.getX();
        float ty = (float) (to.getY() + to.getBbHeight() * 0.5);
        float tz = (float) to.getZ();
        broadcastNear(sl, tx, ty, tz,
                WeaponVisualEffectId.CHAIN_VOLT_ARC.id, KIND_BEAM_SIPHON, Math.max(1, level),
                fx, fy, fz, tx, ty, tz);
    }

    /**
     * Attache automatiquement un sillage de mini-pixels 3D en temps réel à toute flèche, carreau
     * ou trident tiré avec une arme enchantée !
     */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onProjectileSpawn(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof ServerLevel sl)) return;
        Entity entity = event.getEntity();
        if (!(entity instanceof Projectile proj)) return;
        if (!(proj instanceof AbstractArrow)) return;

        // Planifié à J+1 tick afin que ClientboundAddEntityPacket et le snapshot d'arme soient déjà prêts
        TestProcedure.schedule(sl, TestProcedure.currentTick(sl) + 1, () -> {
            if (!proj.isAlive()) return;
            if (!(proj.getOwner() instanceof LivingEntity shooter)) return;

            ItemStack weapon = ItemStack.EMPTY;
            if (proj instanceof ThrownTrident trident) {
                weapon = trident.getPickupItemStackOrigin();
            } else if (proj instanceof AbstractArrow arrow) {
                weapon = UniversalEnchantmentHandler.resolveArrowWeapon(arrow, shooter);
            }
            if (weapon.isEmpty()) {
                weapon = shooter.getMainHandItem();
            }
            List<WeaponVisualEffectId.ResolvedLayer> layers = WeaponVisualEffectId.resolveLayers(weapon, 1);
            if (layers.isEmpty()) return;

            WeaponVisualEffectId.ResolvedLayer top = layers.get(0);
            broadcastNear(sl, (float) proj.getX(), (float) proj.getY(), (float) proj.getZ(),
                    top.effect().id, KIND_PROJECTILE_ATTACH, top.level(),
                    (float) proj.getX(), (float) proj.getY(), (float) proj.getZ(),
                    (float) proj.getId(), 0.0f, 0.0f);
        });
    }

    /**
     * T349-VFX-FREQUENCY : les effets d'attaque partaient à CHAQUE coup (et se répétaient). On applique
     * maintenant un vrai cooldown aléatoire par effet (26..59 ticks) + un % de chance de déclenchement.
     * Les effets critiques gardent leur chance naturelle (ils sont déjà rares) mais restent throttlés.
     */
    /**
     * T351-SUBTLE : joue un accent discret (2..9 mini-pixels) au lieu de la grosse animation.
     * Retourne {@code true} si un accent a effectivement été envoyé.
     */
    private static boolean playSubtleAccent(ServerLevel sl, ItemStack weapon, WeaponVisualEffectId fx,
                                            float tx, float ty, float tz,
                                            float ax, float ay, float az) {
        if (sl.random.nextInt(100) >= SUBTLE_SHARE_PERCENT) return false;
        int accentIndex = pickAccentIndex(sl, weapon, fx);
        int palette = paletteOf(weapon, fx);
        // Direction de frappe : de l'attaquant vers la cible, prolongée au-delà de la cible.
        float dx = tx - ax, dy = ty - ay, dz = tz - az;
        float ex = tx + dx * 0.35f;
        float ey = ty + dy * 0.35f;
        float ez = tz + dz * 0.35f;
        broadcastNear(sl, tx, ty, tz, 0, WeaponVfxSubtle.NET_KIND_BASE + accentIndex, 1,
                tx, ty, tz, ex, ey, ez, palette);
        return true;
    }

    /**
     * T351-SUBTLE-ECHO : choisit l'accent discret à jouer.
     *
     * <p>Une fois sur deux on prend l'<b>écho de la grosse animation</b> de l'arme (même arc, même
     * colonne, même éclair... en minuscule) : le joueur reconnaît la signature de son enchantement
     * même quand la grande forme ne part pas. L'autre moitié pioche dans les accents élémentaires,
     * pour éviter toute répétition.</p>
     */
    private static int pickAccentIndex(ServerLevel sl, ItemStack weapon, WeaponVisualEffectId fx) {
        if (fx != null && sl.random.nextInt(100) < 50) {
            List<WeaponVfxSubtleEcho.Echo> pool = WeaponVfxSubtleEcho.forEffect(fx.id);
            if (!pool.isEmpty()) {
                return WeaponVfxSubtle.COUNT + pool.get(sl.random.nextInt(pool.size())).index();
            }
        }
        DeepElement el = pickElement(sl, weapon, fx);
        return WeaponVfxSubtle.pick(el, sl.random.nextLong()).index();
    }

    /**
     * T352-ELEMENT-COMBO : joue, en même temps, la signature de chaque famille élémentaire portée par
     * l'arme (6 % de chance, armes multi-éléments uniquement). Chaque animation part avec un masque
     * réduit à SA famille : les couleurs restent donc pures et bien distinctes (feu rouge, eau bleue,
     * chaos bariolé...), au lieu d'être moyennées.
     *
     * @return vrai si le combo élémentaire a été déclenché
     */
    private static boolean tryElementCombo(ServerLevel sl, int attackerId, ItemStack weapon,
                                           float tx, float ty, float tz,
                                           float ax, float ay, float az, LivingEntity target) {
        return tryElementCombo(sl, attackerId, weapon, tx, ty, tz, ax, ay, az, 1.0f, target);
    }

    /** T359-BIG-ANIM-SCALE : variante qui applique l'échelle de la cible à chacune des signatures. */
    private static boolean tryElementCombo(ServerLevel sl, int attackerId, ItemStack weapon,
                                           float tx, float ty, float tz,
                                           float ax, float ay, float az, float sizeScale,
                                           LivingEntity target) {
        // Un seul combo par coup : le critique et le handler d'impact peuvent viser le même tick.
        long now = sl.getGameTime();
        Long last = LAST_ELEMENT_COMBO_TICK.get(attackerId);
        if (last != null && now - last <= 1L) return false;
        if (sl.random.nextInt(100) >= ELEMENT_COMBO_PERCENT) return false;
        List<DeepElement> els = WeaponVisualEffectId.elementsOf(weapon);
        if (els.size() < 2) return false;
        LAST_ELEMENT_COMBO_TICK.put(attackerId, now);
        if (LAST_ELEMENT_COMBO_TICK.size() > 512) LAST_ELEMENT_COMBO_TICK.clear();

        int played = 0;
        for (DeepElement el : els) {
            if (played >= ELEMENT_COMBO_MAX) break;
            if (el == null) continue;
            WeaponVisualEffectId sig = WeaponVisualEffectId.signatureFor(el);
            if (sig == null) continue;
            broadcastNear(sl, tx, ty, tz, sig.id, KIND_IMPACT, 3,
                    tx, ty, tz, ax, ay, az, 1 << el.ordinal(), sizeScale);
            applyFireGameplay(sl.getEntityById(attackerId) instanceof LivingEntity comboAttacker
                    ? comboAttacker : null, target, sig, sizeScale);
            // Étincelles de la famille, une par élément : le mélange de couleurs se voit tout de suite.
            WeaponVfxSubtle.Subtle accent = WeaponVfxSubtle.pick(el, sl.random.nextLong());
            broadcastNear(sl, tx, ty, tz, 0, WeaponVfxSubtle.NET_KIND_BASE + accent.index(), 1,
                    tx, ty, tz, ax, ay, az, 1 << el.ordinal());
            played++;
        }
        return played > 1;
    }

    /** T351-ELEMENT-BLEND : masque des éléments de l'arme (0 si inconnu) pour mélanger les couleurs. */
    private static int paletteOf(ItemStack weapon, WeaponVisualEffectId fx) {
        int mask = WeaponVisualEffectId.elementMaskOf(weapon);
        if (mask == 0 && fx != null) mask = 1 << fx.element.ordinal();
        return mask;
    }

    /** Famille élémentaire à utiliser : une des familles portées par l'arme (variété), sinon celle de l'effet. */
    private static DeepElement pickElement(ServerLevel sl, ItemStack weapon, WeaponVisualEffectId fx) {
        List<DeepElement> els = WeaponVisualEffectId.elementsOf(weapon);
        if (els.isEmpty()) return (fx == null) ? DeepElement.METAL : fx.element;
        return els.get(sl.random.nextInt(els.size()));
    }

    private static boolean shouldPlay(int attackerId, WeaponVisualEffectId fx, ServerLevel sl, boolean crit) {
        long now = sl.getGameTime();
        String key = attackerId + ":" + fx.id;
        Long ready = EFFECT_COOLDOWN.get(key);
        if (ready != null && now < ready) return false;

        // T351/T359 : 5 % sur une attaque normale, 76 % sur un coup critique.
        int chance = crit ? CRIT_TRIGGER_PERCENT : NORMAL_TRIGGER_PERCENT;
        if (sl.random.nextInt(100) >= chance) {
            // Nouvelle tentative possible très vite : on ne veut pas « perdre » un long cooldown sur un jet raté
            EFFECT_COOLDOWN.put(key, now + 4L);
            return false;
        }
        int cooldown = crit
                ? 18 + sl.random.nextInt(22)
                : 45 + sl.random.nextInt(45);
        EFFECT_COOLDOWN.put(key, now + cooldown);
        if (EFFECT_COOLDOWN.size() > 2048) {
            EFFECT_COOLDOWN.clear();
        }
        return true;
    }

    /** Direction, contacts hostiles et combustion finale des trois signatures Fire. */
    private static void applyFireGameplay(LivingEntity attacker, LivingEntity target,
                                          WeaponVisualEffectId fx, float visualScale) {
        if (!(target.level() instanceof ServerLevel sl)) return;
        boolean molten = fx == WeaponVisualEffectId.MOLTEN_FIRE_WAVE;
        boolean soul = fx == WeaponVisualEffectId.SOUL_FIRE_CRESCENT;
        boolean meteor = fx == WeaponVisualEffectId.BRIMSTONE_METEOR;
        if (!molten && !soul && !meteor) return;

        long now = sl.getGameTime();
        int scheduleTick = TestProcedure.currentTick(sl);
        if (molten) scheduleWaveIgnition(sl, attacker, target, scheduleTick);
        if (meteor) {
            scheduleMeteorTracking(sl, target, scheduleTick);
            scheduleMeteorExplosionZone(sl, attacker, target, scheduleTick);
        }
        scheduleFireSoundtrack(sl, attacker, target, fx, scheduleTick);

        // La fin de chorégraphie réapplique exactement quatre secondes de feu à la cible.
        int duration = meteor ? 128 : 112;
        TestProcedure.schedule(sl, scheduleTick + duration, () -> {
            if (!target.isAlive() || target.level() != sl) return;
            if (soul) igniteSoulForFourSeconds(target);
            else igniteNormalForFourSeconds(target);
        });

        if (!soul) return;
        SoulHold previous = SOUL_HOLDS.get(target.getId());
        if (previous != null && previous.expires() > now) return;
        boolean previousNoAi = previous != null ? previous.previousNoAi()
                : target instanceof Mob mob && mob.isNoAi();
        double x = target.getX(), baseY = target.getY(), z = target.getZ();
        // FireSignatureVfx : centre = cy + 0.84 * S ; cy est le centre initial de la hitbox.
        double targetY = baseY + 0.84 * net.minecraft.util.Mth.clamp(visualScale, 0.30f, 4.0f);
        SOUL_HOLDS.put(target.getId(), new SoulHold(now + 104, now + 12, now + 22,
                now + 90, x, baseY, targetY, z, previousNoAi));
        if (target instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setTarget(null);
        }
        target.stopUsingItem();
        target.setDeltaMovement(Vec3.ZERO);
        target.fallDistance = 0.0f;
    }

    private static void igniteNormalForFourSeconds(LivingEntity target) {
        igniteNormalForTicks(target, SIGNATURE_FIRE_TICKS);
    }

    private static void igniteNormalForTicks(LivingEntity target, int ticks) {
        SOUL_BURNS.remove(target.getId());
        target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), ticks));
    }

    private static void igniteSoulForFourSeconds(LivingEntity target) {
        if (!(target.level() instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        SoulBurn previous = SOUL_BURNS.get(target.getId());
        long nextDamage = previous != null && previous.expires() > now ? previous.nextDamage() : now;
        SOUL_BURNS.put(target.getId(), new SoulBurn(now + SIGNATURE_FIRE_TICKS, nextDamage));
        // La flamme orange vanilla est remplacée par notre combustion Soul bleue.
        target.setRemainingFireTicks(0);
        emitSoulBurnParticles(target, 10);
    }

    private static void emitSoulBurnParticles(LivingEntity target, int count) {
        if (!(target.level() instanceof ServerLevel sl)) return;
        sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                target.getX(), target.getY() + target.getBbHeight() * 0.48, target.getZ(), count,
                Math.max(0.08, target.getBbWidth() * 0.24), target.getBbHeight() * 0.30,
                Math.max(0.08, target.getBbWidth() * 0.24), 0.012);
    }

    private static void tickSoulBurn(LivingEntity target) {
        SoulBurn burn = SOUL_BURNS.get(target.getId());
        if (burn == null || !(target.level() instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        if (!target.isAlive() || now >= burn.expires()) {
            SOUL_BURNS.remove(target.getId());
            return;
        }
        target.setRemainingFireTicks(0);
        if (now % 3L == 0L) emitSoulBurnParticles(target, 4);
        if (now >= burn.nextDamage()) {
            target.hurt(target.damageSources().onFire(), 1.0f);
            SOUL_BURNS.put(target.getId(), new SoulBurn(burn.expires(), now + 20L));
        }
    }

    private record WaveOrigin(double x, double y, double z, double dirX, double dirZ) { }

    /** Départ un bloc devant le joueur en mêlée, sans rapprocher la vague d'une cible distante. */
    private static WaveOrigin waveOrigin(LivingEntity attacker, LivingEntity primaryTarget) {
        double dx = attacker == null ? 1.0 : primaryTarget.getX() - attacker.getX();
        double dz = attacker == null ? 0.0 : primaryTarget.getZ() - attacker.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 0.001) {
            dx = 1.0;
            dz = 0.0;
            length = 1.0;
        }
        double dirX = dx / length;
        double dirZ = dz / length;
        double shift = Math.max(0.0, 3.0 - length);
        return new WaveOrigin(primaryTarget.getX() + dirX * shift, primaryTarget.getY(),
                primaryTarget.getZ() + dirZ * shift, dirX, dirZ);
    }

    /** Corridor de quatre blocs : front = -2 .. +2, largeur = trois blocs. */
    private static void scheduleWaveIgnition(ServerLevel sl, LivingEntity attacker,
                                             LivingEntity primaryTarget, int now) {
        WaveOrigin origin = waveOrigin(attacker, primaryTarget);
        double originX = origin.x(), originY = origin.y(), originZ = origin.z();
        double dirX = origin.dirX(), dirZ = origin.dirZ();
        int attackerId = attacker == null ? -1 : attacker.getId();
        int primaryId = primaryTarget.getId();
        Set<Integer> ignited = new HashSet<>();

        for (int delay = 0; delay <= 112; delay += 4) {
            double front = -2.0 + 4.0 * (delay / 112.0);
            TestProcedure.schedule(sl, now + delay, () -> {
                double centerX = originX + dirX * front;
                double centerZ = originZ + dirZ * front;
                AABB query = new AABB(centerX - 2.4, originY - 2.5, centerZ - 2.4,
                        centerX + 2.4, originY + 3.5, centerZ + 2.4);
                for (LivingEntity entity : sl.getEntitiesOfClass(LivingEntity.class, query)) {
                    if (!entity.isAlive() || ignited.contains(entity.getId())) continue;
                    boolean primary = entity.getId() == primaryId;
                    // Le joueur à l'origine ne peut jamais être touché par sa propre lave.
                    if (!primary && (entity.getId() == attackerId || !(entity instanceof Enemy))) continue;
                    double rx = entity.getX() - originX;
                    double rz = entity.getZ() - originZ;
                    double along = rx * dirX + rz * dirZ;
                    double lateral = rx * -dirZ + rz * dirX;
                    double radius = entity.getBbWidth() * 0.5;
                    if (Math.abs(along - front) > 0.90 + radius
                            || Math.abs(lateral) > 1.50 + radius) continue;
                    ignited.add(entity.getId());
                    igniteNormalForFourSeconds(entity);
                }
            });
        }
    }

    /** La tête chercheuse suit la cible sans la stun, puis s'arrête à l'impact. */
    private static void scheduleMeteorTracking(ServerLevel sl, LivingEntity target, int now) {
        int targetId = target.getId();
        for (int delay = 0; delay <= METEOR_IMPACT_TICKS; delay += 2) {
            TestProcedure.schedule(sl, now + delay, () -> {
                if (!target.isAlive() || target.level() != sl) return;
                float x = (float) target.getX();
                float y = (float) (target.getY() + target.getBbHeight() * 0.5);
                float z = (float) target.getZ();
                broadcastNear(sl, x, y, z, WeaponVisualEffectId.BRIMSTONE_METEOR.id,
                        KIND_METEOR_TRACK, 0, x, y, z, targetId, 0.0f, 0.0f);
            });
        }
    }

    /** Zone persistante de trois secondes ; chaque ennemi touché brûle trois secondes. */
    private static void scheduleMeteorExplosionZone(ServerLevel sl, LivingEntity attacker,
                                                    LivingEntity primaryTarget, int now) {
        int attackerId = attacker == null ? -1 : attacker.getId();
        int primaryId = primaryTarget.getId();
        TestProcedure.schedule(sl, now + METEOR_IMPACT_TICKS, () -> {
            if (primaryTarget.level() != sl) return;
            double x = primaryTarget.getX(), y = primaryTarget.getY(), z = primaryTarget.getZ();
            Set<Integer> zoneIgnited = new HashSet<>();
            for (int delay = 0; delay <= METEOR_AOE_FIRE_TICKS; delay += 10) {
                TestProcedure.schedule(sl, now + METEOR_IMPACT_TICKS + delay, () -> {
                    AABB area = new AABB(x - METEOR_FIRE_RADIUS, y - 2.0, z - METEOR_FIRE_RADIUS,
                            x + METEOR_FIRE_RADIUS, y + 3.0, z + METEOR_FIRE_RADIUS);
                    for (LivingEntity entity : sl.getEntitiesOfClass(LivingEntity.class, area)) {
                        if (!entity.isAlive() || zoneIgnited.contains(entity.getId())) continue;
                        boolean primary = entity.getId() == primaryId;
                        if (!primary && (entity.getId() == attackerId || !(entity instanceof Enemy))) continue;
                        double dx = entity.getX() - x, dz = entity.getZ() - z;
                        if (dx * dx + dz * dz > METEOR_FIRE_RADIUS * METEOR_FIRE_RADIUS) continue;
                        zoneIgnited.add(entity.getId());
                        igniteNormalForTicks(entity, METEOR_AOE_FIRE_TICKS);
                    }
                });
            }
        });
    }

    /** Bruitages vanilla placés sur les phases et les positions réelles des animations. */
    private static void scheduleFireSoundtrack(ServerLevel sl, LivingEntity attacker,
                                               LivingEntity target, WeaponVisualEffectId fx, int now) {
        if (fx == WeaponVisualEffectId.MOLTEN_FIRE_WAVE) {
            WaveOrigin origin = waveOrigin(attacker, target);
            int[] lavaTicks = {0, 20, 40, 60, 80};
            for (int delay : lavaTicks) {
                double front = -2.0 + 4.0 * (delay / 112.0);
                double x = origin.x() + origin.dirX() * front;
                double z = origin.z() + origin.dirZ() * front;
                TestProcedure.schedule(sl, now + delay, () -> sl.playSound(null, x, origin.y(), z,
                        SoundEvents.LAVA_AMBIENT, SoundSource.PLAYERS, 0.72f, 1.05f + delay * 0.0015f));
            }
            TestProcedure.schedule(sl, now, () -> sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                    SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.58f, 1.25f));
            TestProcedure.schedule(sl, now + 100, () -> sl.playSound(null,
                    target.getX(), target.getY(), target.getZ(),
                    SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.72f, 1.10f));
            return;
        }
        if (fx == WeaponVisualEffectId.SOUL_FIRE_CRESCENT) {
            TestProcedure.schedule(sl, now, () -> sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                    SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.48f, 1.75f));
            TestProcedure.schedule(sl, now + 22, () -> sl.playSound(null,
                    target.getX(), target.getY() + 0.8, target.getZ(),
                    SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.42f, 1.65f));
            for (int delay : new int[]{46, 74}) {
                TestProcedure.schedule(sl, now + delay, () -> sl.playSound(null,
                        target.getX(), target.getY(), target.getZ(),
                        SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.36f, 1.85f));
            }
            TestProcedure.schedule(sl, now + 104, () -> sl.playSound(null,
                    target.getX(), target.getY(), target.getZ(),
                    SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.50f, 1.70f));
            return;
        }
        if (fx != WeaponVisualEffectId.BRIMSTONE_METEOR) return;
        TestProcedure.schedule(sl, now, () -> {
            sl.playSound(null, target.getX(), target.getY() + 6.0, target.getZ(),
                    SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 0.90f, 0.65f);
            sl.playSound(null, target.getX(), target.getY() + 4.0, target.getZ(),
                    SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 0.40f, 1.65f);
        });
        TestProcedure.schedule(sl, now + 12, () -> sl.playSound(null,
                target.getX(), target.getY() + 2.0, target.getZ(),
                SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.46f, 0.80f));
        TestProcedure.schedule(sl, now + METEOR_IMPACT_TICKS, () -> {
            sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                    SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS, 1.10f, 0.82f);
            sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                    SoundEvents.LAVA_AMBIENT, SoundSource.PLAYERS, 0.78f, 0.85f);
        });
        TestProcedure.schedule(sl, now + 50, () -> sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.48f, 0.95f));
        TestProcedure.schedule(sl, now + 70, () -> sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.LAVA_AMBIENT, SoundSource.PLAYERS, 0.42f, 1.15f));
        TestProcedure.schedule(sl, now + 90, () -> sl.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.42f, 0.95f));
    }

    private static void releaseSoulHold(LivingEntity target, long expectedExpiry) {
        SoulHold hold = SOUL_HOLDS.get(target.getId());
        if (hold == null || hold.expires() != expectedExpiry) return;
        SOUL_HOLDS.remove(target.getId());
        if (target instanceof Mob mob) mob.setNoAi(hold.previousNoAi());
        target.teleportTo(hold.x(), hold.baseY(), hold.z());
        target.setDeltaMovement(Vec3.ZERO);
        target.fallDistance = 0.0f;
    }

    /** ZEPHYR/VERDANT = immobilisation sans bloquer les attaques ; THORN = stun complet 3 s. */
    private static void applyWoodGameplay(LivingEntity attacker, LivingEntity target,
                                          WeaponVisualEffectId fx) {
        if (!(attacker.level() instanceof ServerLevel sl)) return;
        int now = TestProcedure.currentTick(sl);
        if (fx == WeaponVisualEffectId.THORN_MAW_ROOT) {
            applyWoodHold(target, now + 60, true);
            return;
        }
        if (fx == WeaponVisualEffectId.ZEPHYR_WIND_LANCE) {
            applyWoodHold(target, now + 60, false);
            return;
        }
        if (fx != WeaponVisualEffectId.VERDANT_SAP_BLOOM) return;

        int holdStart = now + 64;
        int holdEnd = now + 82;
        TestProcedure.schedule(sl, holdStart, () -> {
            if (target.isAlive() && target.level() == sl) applyWoodHold(target, holdEnd, false);
        });
        TestProcedure.schedule(sl, now + 74, () -> {
            if (!target.isAlive() || target.level() != sl) return;
            // Explosion VISUELLE et SONORE uniquement : aucun dégât en plus du coup initial.
            sl.playSound(null, target.getX(), target.getY() + target.getBbHeight() * 0.50f, target.getZ(),
                    SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS, 0.70f, 1.35f);
        });
        TestProcedure.schedule(sl, holdEnd, () -> releaseWoodHold(target, holdEnd));
    }

    private static void applyWoodHold(LivingEntity target, long expires, boolean fullStun) {
        WoodHold previous = WOOD_HOLDS.get(target.getId());
        boolean previousNoAi = previous != null ? previous.previousNoAi()
                : target instanceof Mob mob && mob.isNoAi();
        double x = previous != null ? previous.x() : target.getX();
        double y = previous != null ? previous.y() : target.getY();
        double z = previous != null ? previous.z() : target.getZ();
        WOOD_HOLDS.put(target.getId(), new WoodHold(expires, x, y, z, previousNoAi, fullStun));
        if (fullStun) {
            if (target instanceof Mob mob) {
                mob.setNoAi(true);
                mob.setTarget(null);
            }
            target.stopUsingItem();
        }
        target.setDeltaMovement(Vec3.ZERO);
        target.teleportTo(x, y, z);
        target.fallDistance = 0.0f;
    }

    private static void releaseWoodHold(LivingEntity target, long expectedExpiry) {
        WoodHold hold = WOOD_HOLDS.get(target.getId());
        if (hold == null || hold.expires() != expectedExpiry) return;
        WOOD_HOLDS.remove(target.getId());
        if (hold.fullStun() && target instanceof Mob mob) mob.setNoAi(hold.previousNoAi());
    }

    private static boolean isSignatureFullyStunned(Entity entity) {
        if (!(entity instanceof LivingEntity living)) return false;
        long now = living.level().getGameTime();
        WoodHold wood = WOOD_HOLDS.get(living.getId());
        SoulHold soul = SOUL_HOLDS.get(living.getId());
        return (wood != null && wood.fullStun() && now < wood.expires())
                || (soul != null && now < soul.expires());
    }

    @SubscribeEvent
    public static void onSignatureHoldTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity target) || target.level().isClientSide()) return;
        tickSoulBurn(target);
        tickSoulHold(target);
        WoodHold hold = WOOD_HOLDS.get(target.getId());
        if (hold == null) return;
        long now = target.level().getGameTime();
        if (!target.isAlive() || now >= hold.expires()) {
            releaseWoodHold(target, hold.expires());
            return;
        }
        if (hold.fullStun()) {
            if (target instanceof Mob mob) {
                mob.setNoAi(true);
                mob.setTarget(null);
            }
            target.stopUsingItem();
        }
        target.setDeltaMovement(Vec3.ZERO);
        target.teleportTo(hold.x(), hold.y(), hold.z());
        target.fallDistance = 0.0f;
    }

    private static void tickSoulHold(LivingEntity target) {
        SoulHold hold = SOUL_HOLDS.get(target.getId());
        if (hold == null) return;
        long now = target.level().getGameTime();
        if (!target.isAlive() || now >= hold.expires()) {
            releaseSoulHold(target, hold.expires());
            return;
        }
        if (target instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setTarget(null);
        }
        target.stopUsingItem();
        double y;
        if (now < hold.riseStart()) {
            y = hold.baseY();
        } else if (now < hold.riseEnd()) {
            y = net.minecraft.util.Mth.lerp(smoothTick(now, hold.riseStart(), hold.riseEnd()),
                    hold.baseY(), hold.targetY());
        } else if (now < hold.descendStart()) {
            y = hold.targetY();
        } else {
            y = net.minecraft.util.Mth.lerp(smoothTick(now, hold.descendStart(), hold.expires()),
                    hold.targetY(), hold.baseY());
        }
        target.setDeltaMovement(Vec3.ZERO);
        target.teleportTo(hold.x(), y, hold.z());
        target.fallDistance = 0.0f;
    }

    private static float smoothTick(long now, long start, long end) {
        float x = net.minecraft.util.Mth.clamp((now - start) / (float) Math.max(1L, end - start), 0.0f, 1.0f);
        return x * x * (3.0f - 2.0f * x);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onWoodHeldAttack(AttackEntityEvent event) {
        if (isSignatureFullyStunned(event.getEntity())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onWoodHeldDamage(LivingIncomingDamageEvent event) {
        if (event.getSource().getEntity() instanceof LivingEntity attacker && isSignatureFullyStunned(attacker)) {
            event.setCanceled(true);
        }
    }

    /**
     * Mêlée directe éligible : exactement UN jet serveur par événement de dégâts accepté.
     * 77 % normal / 20 % slash +5 % / 3 % grande animation +5..15 % selon la taille mesurée.
     * Aucun appel aux anciens tirages de couches, accents, critiques ou combos dans cette branche.
     */
    private static void handleEligibleMelee(ServerLevel sl, LivingIncomingDamageEvent event,
                                            LivingEntity attacker, LivingEntity target, ItemStack weapon,
                                            List<WeaponVisualEffectId.ResolvedLayer> layers) {
        int roll = sl.random.nextInt(100);
        if (roll <= MELEE_NORMAL_MAX_ROLL) return;

        WeaponVisualEffectId.ResolvedLayer layer = layers.get(0);
        WeaponVisualEffectId fx = layer.effect();
        int palette = paletteOf(weapon, fx);
        float tx = (float) target.getX();
        float ty = (float) (target.getY() + target.getBbHeight() * 0.5f);
        float tz = (float) target.getZ();
        float ax = (float) attacker.getX();
        float ay = (float) (attacker.getY() + attacker.getBbHeight() * 0.62f);
        float az = (float) attacker.getZ();

        if (roll <= MELEE_SLASH_MAX_ROLL) {
            event.setAmount(event.getAmount() * MELEE_SLASH_DAMAGE_MULTIPLIER);
            broadcastNear(sl, ax, ay, az, fx.id, KIND_SWING_SLASH, layer.level(),
                    ax, ay, az, tx, ty, tz, palette);
            return;
        }

        float measuredScale = sizeScaleOf(target);
        int bonusPercent = bigMeleeBonusPercent(measuredScale);
        event.setAmount(event.getAmount() * (1.0f + bonusPercent / 100.0f));
        float bigScale = bigMeleeVisualScale(measuredScale);
        if (fx == WeaponVisualEffectId.CRIMSON_SIPHON) {
            broadcastNear(sl, tx, ty, tz, fx.id, KIND_BEAM_SIPHON, layer.level(),
                    tx, ty, tz, ax, ay, az, palette, bigScale);
        } else if (fx == WeaponVisualEffectId.ASTRAL_STAR_LANCE && attacker.distanceToSqr(target) > 9.0) {
            broadcastNear(sl, tx, ty, tz, fx.id, KIND_BEAM_SIPHON, layer.level(),
                    ax, (float) attacker.getEyeY() - 0.12f, az, tx, ty, tz, palette, bigScale);
        } else {
            broadcastNear(sl, tx, ty, tz, fx.id, KIND_IMPACT, layer.level(),
                    tx, ty, tz, ax, ay, az, palette, bigScale);
            applyWoodGameplay(attacker, target, fx);
            applyFireGameplay(attacker, target, fx, bigScale);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingHurtVisuals(LivingIncomingDamageEvent event) {
        // Note : on autorise event.getAmount() == 0.0f pour blood_transfusion (#11), curse_of_mercy et toy !
        if (event.isCanceled()) return;
        LivingEntity target = event.getEntity();
        if (!(target.level() instanceof ServerLevel sl)) return;

        DamageSource src = event.getSource();
        Entity attackerEntity = src.getEntity();
        if (!(attackerEntity instanceof LivingEntity attacker)) return;

        long now = sl.getGameTime();
        Entity direct = src.getDirectEntity();
        boolean isProjectileHit = direct instanceof Projectile;

        // En mêlée pure, évite le spam i-frame ; à distance, autorise les salves multi-flèches (jusqu'à 4 impacts/tick)
        if (!isProjectileHit) {
            Long prev = LAST_ATTACKER_HIT_TICK.put(attacker.getId(), now);
            if (prev != null && now - prev < 2L) return;
        } else {
            Long prevProj = LAST_PROJECTILE_HIT_TICK.put(direct.getId(), now);
            if (prevProj != null && now == prevProj) return;
        }

        if (LAST_ATTACKER_HIT_TICK.size() > 512) {
            LAST_ATTACKER_HIT_TICK.clear();
            LAST_PROJECTILE_HIT_TICK.clear();
            LAST_CRIT_TICK.clear();
            LAST_RALLY_TICK.clear();
            LAST_BIG_ANIM_TICK.clear();
            LAST_ELEMENT_COMBO_TICK.clear();
        }

        ItemStack weapon = resolveImpactWeapon(attacker, direct);
        List<WeaponVisualEffectId.ResolvedLayer> layers = resolveAttackerLayers(attacker, weapon, 2);
        if (layers.isEmpty()) return;

        // playerAttack/mobAttack direct uniquement : les projectiles et dégâts différés ne rerollent pas.
        if (!isProjectileHit && direct == attacker) {
            handleEligibleMelee(sl, event, attacker, target, weapon, layers);
            return;
        }

        float tx = (float) target.getX();
        float ty = (float) (target.getY() + target.getBbHeight() * 0.5);
        float tz = (float) target.getZ();
        float ax = (float) attacker.getX();
        float ay = (float) (attacker.getY() + attacker.getBbHeight() * 0.62);
        float az = (float) attacker.getZ();

        boolean meleeCritJustFired = (now - LAST_CRIT_TICK.getOrDefault(attacker.getId(), -100L)) <= 1L;
        boolean arrowCrit = (direct instanceof AbstractArrow arr) && arr.isCritArrow();
        // T351-ELEMENT-BLEND : palette élémentaire de l'arme (feu + eau -> les deux teintes ensemble).
        int palette = paletteOf(weapon, layers.get(0).effect());

        // Critique à l'arc / arbalète : étoile critique pixel 3D dédiée si pas déjà en couche 0
        if (arrowCrit && layers.get(0).effect().category != WeaponVisualEffectId.Category.CRIT
                && sl.random.nextInt(100) < CRIT_TRIGGER_PERCENT) {
            if (!playSubtleAccent(sl, weapon, WeaponVisualEffectId.GOLDEN_CRIT_STAR, tx, ty, tz, ax, ay, az)) {
                broadcastNear(sl, tx, ty, tz, WeaponVisualEffectId.GOLDEN_CRIT_STAR.id, KIND_IMPACT, 2,
                        tx, ty, tz, ax, ay, az, palette, sizeScaleOf(target));
            }
        }

        // T349-VFX-FREQUENCY : un seul effet par coup (rarement deux) au lieu de toute la pile
        int layerBudget = (sl.random.nextInt(100) < 22) ? 2 : 1;
        // Le critique a-t-il déjà lancé une grosse animation ? Alors le +5 % est appliqué tout de suite.
        boolean bigAnimBonusApplied = (now - LAST_BIG_ANIM_TICK.getOrDefault(attacker.getId(), -100L)) <= 2L;
        // T352-ELEMENT-COMBO : un seul combo élémentaire par coup, même si deux couches partent.
        boolean elementComboDone = false;
        boolean swingSlashPlayed = false;
        if (bigAnimBonusApplied) {
            event.setAmount(event.getAmount() * BIG_ANIM_DAMAGE_BONUS);
        }
        for (int i = 0; i < layers.size(); i++) {
            if (layerBudget <= 0) break;
            WeaponVisualEffectId.ResolvedLayer layer = layers.get(i);
            WeaponVisualEffectId fx = layer.effect();

            // Le slash standard accompagne le coup critique même si le tirage rare de VFX échoue.
            // Le petit/gros effet enchanté reste ensuite décidé une seule fois par shouldPlay.
            if (!isProjectileHit && meleeCritJustFired && !swingSlashPlayed) {
                broadcastNear(sl, ax, ay, az, fx.id, KIND_SWING_SLASH, layer.level(),
                        ax, ay, az, tx, ty, tz, palette);
                swingSlashPlayed = true;
            }
            boolean critHit = arrowCrit || meleeCritJustFired
                    || fx.category == WeaponVisualEffectId.Category.CRIT;
            if (!shouldPlay(attacker.getId(), fx, sl, critHit)) {
                continue;
            }
            // Slash de combat indépendant du tirage « petite ou grande animation » : les attaques
            // sélectionnées gardent leur entaille même lorsque le gros effet est remplacé par un
            // accent discret. Un seul slash par coup, jamais une superposition par couche.
            if (!isProjectileHit && !swingSlashPlayed) {
                broadcastNear(sl, ax, ay, az, fx.id, KIND_SWING_SLASH, layer.level(),
                        ax, ay, az, tx, ty, tz, palette);
                swingSlashPlayed = true;
            }

            layerBudget--;
            // La petite animation reste propre à l'enchantement et ne remplace plus le slash.
            if (playSubtleAccent(sl, weapon, fx, tx, ty, tz, ax, ay, az)) {
                continue;
            }

            // T352-ELEMENT-COMBO : arme multi-éléments -> parfois une animation de CHAQUE élément.
            if (!elementComboDone) {
                elementComboDone = tryElementCombo(sl, attacker.getId(), weapon, tx, ty, tz, ax, ay, az,
                        sizeScaleOf(target), target);
            }

            // T351-BIG-BONUS : les 10 % de grosses animations amplifient de 5 % les dégâts subis
            // (une seule fois par coup, même si deux couches partent).
            if (!bigAnimBonusApplied) {
                bigAnimBonusApplied = true;
                event.setAmount(event.getAmount() * BIG_ANIM_DAMAGE_BONUS);
            }

            if (fx == WeaponVisualEffectId.CRIMSON_SIPHON) {
                broadcastNear(sl, tx, ty, tz, fx.id, KIND_BEAM_SIPHON, layer.level(),
                        tx, ty, tz, ax, ay, az, palette, sizeScaleOf(target));
            } else if (fx == WeaponVisualEffectId.ASTRAL_STAR_LANCE && attacker.distanceToSqr(target) > 9.0) {
                broadcastNear(sl, tx, ty, tz, fx.id, KIND_BEAM_SIPHON, layer.level(),
                        ax, (float) attacker.getEyeY() - 0.12f, az, tx, ty, tz, palette);
            } else {
                int boost = (arrowCrit && fx.category == WeaponVisualEffectId.Category.CRIT) ? layer.level() + 1 : layer.level();
                broadcastNear(sl, tx, ty, tz, fx.id, KIND_IMPACT, boost,
                        tx, ty, tz, ax, ay, az, palette, sizeScaleOf(target));
                applyFireGameplay(attacker, target, fx, sizeScaleOf(target));
            }
        }
    }

    /** Impact sur bloc (flèche ou trident planté dans le décor) : salve de mini-pixels 3D ! */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onProjectileBlockVisuals(ProjectileImpactEvent event) {
        Projectile proj = event.getProjectile();
        if (!(proj.level() instanceof ServerLevel sl)) return;
        if (event.getRayTraceResult().getType() != HitResult.Type.BLOCK) return;
        if (!(proj.getOwner() instanceof LivingEntity shooter)) return;

        long now = sl.getGameTime();
        Long prev = LAST_PROJECTILE_HIT_TICK.put(proj.getId(), now);
        if (prev != null && now - prev < 2L) return;

        ItemStack weapon = resolveImpactWeapon(shooter, proj);
        List<WeaponVisualEffectId.ResolvedLayer> layers = WeaponVisualEffectId.resolveLayers(weapon, 1);
        if (layers.isEmpty()) return;

        if (!shouldPlay(shooter.getId(), layers.get(0).effect(), sl, false)) return;

        WeaponVisualEffectId.ResolvedLayer top = layers.get(0);
        int palette = paletteOf(weapon, top.effect());
        Vec3 hit = event.getRayTraceResult().getLocation();
        if (top.effect() == WeaponVisualEffectId.ASTRAL_STAR_LANCE) {
            broadcastNear(sl, (float) hit.x, (float) hit.y, (float) hit.z,
                    top.effect().id, KIND_BEAM_SIPHON, top.level(),
                    (float) shooter.getX(), (float) shooter.getEyeY() - 0.12f, (float) shooter.getZ(),
                    (float) hit.x, (float) hit.y, (float) hit.z, palette);
        } else {
            broadcastNear(sl, (float) hit.x, (float) hit.y, (float) hit.z,
                    top.effect().id, KIND_IMPACT, top.level(),
                    (float) hit.x, (float) hit.y, (float) hit.z,
                    (float) shooter.getX(), (float) shooter.getEyeY(), (float) shooter.getZ(), palette);
        }
    }

    /** Clic droit avec une arme portant {@code army_summon} / {@code summon_army} -> Sceau Voxel #29 ! */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickRallyVisuals(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        if (isSignatureFullyStunned(player)) {
            event.setCanceled(true);
            return;
        }
        if (!(player.level() instanceof ServerLevel sl)) return;
        ItemStack stack = event.getItemStack();
        if (stack.isEmpty() || player.getCooldowns().isOnCooldown(stack.getItem())) return;

        List<WeaponVisualEffectId.ResolvedLayer> layers = WeaponVisualEffectId.resolveLayers(stack, 2);
        for (WeaponVisualEffectId.ResolvedLayer l : layers) {
            if (l.effect() == WeaponVisualEffectId.WARLORD_RALLY_SIGIL) {
                long now = sl.getGameTime();
                Long prev = LAST_RALLY_TICK.put(player.getId(), now);
                if (prev != null && now - prev < 40L) return; // T349 : sceau moins spammable
                float px = (float) player.getX();
                float py = (float) (player.getY() + 0.45);
                float pz = (float) player.getZ();
                broadcastNear(sl, px, py, pz, WeaponVisualEffectId.WARLORD_RALLY_SIGIL.id, KIND_IMPACT, l.level(),
                        px, py, pz, px, py + 1.0f, pz);
                break;
            }
        }
    }

    private static List<WeaponVisualEffectId.ResolvedLayer> resolveAttackerLayers(LivingEntity attacker, ItemStack weapon, int maxLayers) {
        if (!weapon.isEmpty()) {
            return WeaponVisualEffectId.resolveLayers(weapon, maxLayers);
        }
        if (attacker instanceof Player p) {
            return WeaponVisualEffectId.resolveBareHandGauntletLayers(p, maxLayers);
        }
        return List.of();
    }

    private static ItemStack resolveImpactWeapon(LivingEntity attacker, Entity direct) {
        if (direct instanceof ThrownTrident trident) {
            ItemStack origin = trident.getPickupItemStackOrigin();
            if (!origin.isEmpty()) return origin;
        }
        if (direct instanceof AbstractArrow arrow) {
            ItemStack snap = UniversalEnchantmentHandler.resolveArrowWeapon(arrow, attacker);
            if (!snap.isEmpty()) return snap;
        }
        return attacker.getMainHandItem();
    }

    /**
     * T346-VFX-TEST : déclenchement MANUEL d'un effet visuel (utilisé par {@code /dlbvfx}).
     * Emprunte exactement le même paquet S2C que les déclencheurs de jeu réels, donc ce que la
     * commande affiche est rigoureusement identique à ce que le joueur voit en combat.
     */
    public static void playDebug(ServerPlayer player, WeaponVisualEffectId fx, int kind, int intensity,
                                 Vec3 from, Vec3 to) {
        playDebug(player, fx, kind, intensity, from, to, 1.0f);
    }

    /** Intensité et échelle explicites pour les tests visuels, sans second passage artificiel. */
    public static void playDebug(ServerPlayer player, WeaponVisualEffectId fx, int kind, int intensity,
                                 Vec3 from, Vec3 to, float sizeScale) {
        if (player == null || fx == null) return;
        if (!(player.level() instanceof ServerLevel sl)) return;
        int lvl = Math.max(1, Math.min(12, intensity));
        float scale = Math.max(0.45f, Math.min(2.60f, sizeScale));
        if (kind == KIND_PROJECTILE_ATTACH) {
            // to.x porte l'identifiant d'entité du projectile à suivre (comme le vrai chemin réseau)
            broadcastNear(sl, (float) from.x, (float) from.y, (float) from.z, fx.id, kind, lvl,
                    (float) from.x, (float) from.y, (float) from.z,
                    (float) to.x, 0.0f, 0.0f, 0, scale);
            return;
        }
        // Mêmes conventions que le combat réel : un impact a son ORIGINE sur la cible et sa
        // target sur l'attaquant ; un slash part de l'attaquant et regarde la cible. L'ancien
        // ordre from/to plaçait tous les impacts de démonstration sur le joueur.
        boolean impact = kind == KIND_IMPACT;
        Vec3 origin = impact ? to : from;
        Vec3 target = impact ? from : to;
        Vec3 reference = kind == KIND_SWING_SLASH ? from : to;
        broadcastNear(sl, (float) reference.x, (float) reference.y, (float) reference.z, fx.id, kind, lvl,
                (float) origin.x, (float) origin.y, (float) origin.z,
                (float) target.x, (float) target.y, (float) target.z, 0, scale);
    }

    /** T351 : joue un accent discret précis (test via {@code /dlbvfx subtle}). */
    public static void playSubtleDebug(ServerPlayer player, WeaponVfxSubtle.Subtle accent,
                                       Vec3 from, Vec3 to) {
        if (accent == null) return;
        playSubtleDebug(player, accent.index(), from, to);
    }

    /**
     * T351-SUBTLE-ECHO : joue un accent par son index global ({@code 0..49} élémentaires,
     * {@code 50..99} échos de grosses animations).
     */
    public static void playSubtleDebug(ServerPlayer player, int accentIndex, Vec3 from, Vec3 to) {
        if (player == null) return;
        if (!(player.level() instanceof ServerLevel sl)) return;
        broadcastNear(sl, (float) to.x, (float) to.y, (float) to.z,
                0, WeaponVfxSubtle.NET_KIND_BASE + accentIndex, 1,
                (float) from.x, (float) from.y, (float) from.z,
                (float) to.x, (float) to.y, (float) to.z);
    }

    private static void broadcastNear(ServerLevel sl, float refX, float refY, float refZ,
                                      int vfxId, int kind, int intensity,
                                      float x, float y, float z,
                                      float tx, float ty, float tz) {
        broadcastNear(sl, refX, refY, refZ, vfxId, kind, intensity, x, y, z, tx, ty, tz, 0);
    }

    private static void broadcastNear(ServerLevel sl, float refX, float refY, float refZ,
                                      int vfxId, int kind, int intensity,
                                      float x, float y, float z,
                                      float tx, float ty, float tz, int paletteMask) {
        broadcastNear(sl, refX, refY, refZ, vfxId, kind, intensity, x, y, z, tx, ty, tz, paletteMask, 1.0f);
    }

    /**
     * T359-BIG-ANIM-SCALE : comme ci-dessus, en transmettant l'<b>échelle de taille</b> de la
     * grosse animation. Le client fait alors grossir/rétrécir l'animation ENTIÈRE autour de son
     * point d'impact : un poulet reçoit une animation minuscule, un ravager ou un dragon une
     * animation énorme.
     */
    private static void broadcastNear(ServerLevel sl, float refX, float refY, float refZ,
                                      int vfxId, int kind, int intensity,
                                      float x, float y, float z,
                                      float tx, float ty, float tz, int paletteMask,
                                      float sizeScale) {
        DeepPayloads.WeaponVfxMessage payload = DeepPayloads.WeaponVfxMessage.create(
                vfxId, kind, intensity, x, y, z, tx, ty, tz, paletteMask, sizeScale);

        double maxDistSq = 52.0 * 52.0;
        for (ServerPlayer sp : sl.players()) {
            if (sp.distanceToSqr(refX, refY, refZ) <= maxDistSq) {
                PacketDistributor.sendToPlayer(sp, payload);
            }
        }
    }
}
