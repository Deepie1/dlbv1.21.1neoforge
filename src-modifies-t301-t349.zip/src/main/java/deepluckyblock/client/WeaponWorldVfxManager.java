package deepluckyblock.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import deepluckyblock.DeepLuckyBlockMod;
import deepluckyblock.enchantments.WeaponVisualEffectId;
import deepluckyblock.util.DeepEnchant;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * T343-VOXEL-3D-ENGINE : Moteur client 100 % "Blocky / Mini-Pixels 3D" pour les 30 effets d'armes :
 * <ul>
 *   <li>Chaque particule, entaille, éclair, goutte de sang, étoile critique, colonne céleste, vortex
 *       et rayon à distance est intégralement composé de <b>vrais mini-cubes voxels 3D à 6 faces</b>
 *       ombrées selon les normales Minecraft (UP 100 %, N/S 84 %, E/W 72 %, DOWN 60 %).</li>
 *   <li>Suit également en temps réel les flèches, carreaux et tridents enchantés pendant tout leur vol
 *       ({@link #KIND_PROJECTILE_ATTACH}) avec un sillage continu de mini-pixels 3D, ainsi que le tir
 *       d'arc/arbalète et les coups de gantelets à mains nues.</li>
 * </ul>
 */
@EventBusSubscriber(modid = DeepLuckyBlockMod.MODID, value = Dist.CLIENT)
public final class WeaponWorldVfxManager {

    private static final int MAX_ACTIVE_INSTANCES = 140;
    private static final int MAX_VOXEL_TRAIL_PIXELS = 320;

    public static final int KIND_SWING_SLASH       = 0;
    public static final int KIND_IMPACT            = 1;
    public static final int KIND_BEAM_SIPHON       = 2;
    public static final int KIND_PROJECTILE_ATTACH = 3;

    private static final List<VfxInstance> ACTIVE = new ArrayList<>(144);
    private static final List<FloatingPixel> PIXEL_PARTICLES = new ArrayList<>(340);
    private static final List<PendingEcho> PENDING_ECHOES = new ArrayList<>(16);
    private static final Map<Integer, TrackedProjectile> TRACKED_PROJECTILES = new HashMap<>(32);

    private static final Map<Integer, Boolean> PLAYER_WAS_SWINGING = new HashMap<>(16);
    private static final Map<Integer, Integer> PLAYER_SWING_PARITY = new HashMap<>(16);
    /** T349-VFX-FREQUENCY : cooldown aléatoire de la traînée de coup (par joueur). */
    private static final Map<Integer, Long> PLAYER_SWING_READY = new HashMap<>(16);
    private static final Map<Integer, Boolean> PLAYER_WAS_DRAWING = new HashMap<>(16);
    private static final Map<Integer, Boolean> PLAYER_WAS_CB_CHARGED = new HashMap<>(16);

    private static ClientLevel trackedLevel;
    private static long lastTickNanos = System.nanoTime();

    private static RenderType additiveType;
    private static RenderType translucentType;

    /** T349 : temps de frame (secondes) partagé, mis à jour une seule fois par frame. */
    private static float frameTimeSeconds;
    /** T349-PIXEL-VARIATION : échelle douce globale de tous les pixels. */
    private static float framePixelScale = 1.0f;

    /**
     * T349-IDLE-FILTER : plancher d'alpha. Quand il vaut &gt; 0, tout cube dont l'alpha est inférieur est
     * ignoré. Utilisé par le rendu d'arme tenue pour supprimer les « pixels lumineux constants » qui
     * restaient collés sur l'item, sans toucher aux éclats d'action (alpha élevé).
     */
    private static int alphaFloor = 0;

    public static void setAlphaFloor(int floor) {
        alphaFloor = Math.max(0, Math.min(255, floor));
    }

    public static int getAlphaFloor() {
        return alphaFloor;
    }

    /** T349 : remise à zéro du compteur de cubes (utilisée par CosmeticPixelAura, autre passe de rendu). */
    public static void resetCubeBudget() {
        cubesSinceFlush = 0;
    }

    /** Appelé une fois par frame pour partager le même temps / la même échelle de pixels. */
    public static void beginFrame(float timeSeconds) {
        frameTimeSeconds = timeSeconds;
        framePixelScale = 0.80f + 0.10f * Mth.sin(timeSeconds * 0.53f) + 0.10f * Mth.sin(timeSeconds * 1.27f + 1.7f);
    }

    private record TrackedProjectile(WeaponVisualEffectId effect, int intensity, long startTick, long expiresTick) {}

    private static final class FloatingPixel {
        final boolean additive;
        double x, y, z;
        double vx, vy, vz;
        float gravity;
        float halfSize;
        int rgb;
        int age;
        int maxAge;
        int detailSalt;

        FloatingPixel(boolean additive, double x, double y, double z,
                      double vx, double vy, double vz, float gravity,
                      float halfSize, int rgb, int maxAge, int detailSalt) {
            this.additive = additive;
            this.x = x; this.y = y; this.z = z;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.gravity = gravity;
            this.halfSize = halfSize;
            this.rgb = rgb;
            this.maxAge = Math.max(4, maxAge);
            this.detailSalt = detailSalt;
        }
    }

    private static final class PendingEcho {
        int ticksLeft;
        WeaponVisualEffectId effect;
        int intensity;
        double x, y, z;
        float yaw, pitch, tiltRad;
    }

    private static final class VfxInstance {
        final WeaponVisualEffectId effect;
        final int kind;
        final int intensity;
        final double x, y, z;
        final double tx, ty, tz;
        final float yawDeg, pitchDeg, tiltRad;
        final int maxAge;
        final long seed;
        int age;

        /** T349-VARIATION : variante 0..7 tirée au déclenchement (forme, sens de rotation, teinte). */
        int variant() {
            return (int) ((seed >>> 17) & 7);
        }

        VfxInstance(WeaponVisualEffectId effect, int kind, int intensity,
                    double x, double y, double z,
                    double tx, double ty, double tz,
                    float yawDeg, float pitchDeg, float tiltRad,
                    int maxAge, long seed) {
            this.effect = effect;
            this.kind = kind;
            this.intensity = Math.max(1, Math.min(12, intensity));
            this.x = x; this.y = y; this.z = z;
            this.tx = tx; this.ty = ty; this.tz = tz;
            this.yawDeg = yawDeg; this.pitchDeg = pitchDeg; this.tiltRad = tiltRad;
            this.maxAge = Math.max(4, maxAge);
            this.seed = seed;
        }
    }

    private WeaponWorldVfxManager() {}

    public static float smoothTimeSeconds() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel lvl = mc.level;
        if (lvl == null) {
            return (float) ((System.nanoTime() & 0x3FFFFFFFL) * 1.0e-9);
        }
        float subTick = mc.isPaused()
                ? 0.0f
                : Mth.clamp((System.nanoTime() - lastTickNanos) / 50_000_000.0f, 0.0f, 1.0f);
        return ((lvl.getGameTime() & 0xFFFFFL) + subTick) * 0.05f;
    }

    public static RenderType getAdditiveRenderType() {
        if (additiveType == null) {
            RenderType.CompositeState state = RenderType.CompositeState.builder()
                    .setShaderState(RenderStateShard.RENDERTYPE_LIGHTNING_SHADER)
                    .setTransparencyState(RenderStateShard.LIGHTNING_TRANSPARENCY)
                    .setCullState(RenderStateShard.NO_CULL)
                    .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
                    .setWriteMaskState(RenderStateShard.COLOR_WRITE)
                    .setOutputState(RenderStateShard.PARTICLES_TARGET)
                    .createCompositeState(false);
            additiveType = RenderType.create(
                    "dlb_voxel_vfx_add",
                    DefaultVertexFormat.POSITION_COLOR,
                    VertexFormat.Mode.QUADS,
                    32768,
                    false,
                    false,
                    state);
        }
        return additiveType;
    }

    public static RenderType getTranslucentRenderType() {
        if (translucentType == null) {
            RenderType.CompositeState state = RenderType.CompositeState.builder()
                    .setShaderState(RenderStateShard.RENDERTYPE_LIGHTNING_SHADER)
                    .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                    .setCullState(RenderStateShard.NO_CULL)
                    .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
                    .setWriteMaskState(RenderStateShard.COLOR_WRITE)
                    .setOutputState(RenderStateShard.PARTICLES_TARGET)
                    .createCompositeState(false);
            translucentType = RenderType.create(
                    "dlb_voxel_vfx_alpha",
                    DefaultVertexFormat.POSITION_COLOR,
                    VertexFormat.Mode.QUADS,
                    32768,
                    false,
                    true,
                    state);
        }
        return translucentType;
    }

    public static void enqueueNetworkVfx(int vfxId, int kind, int intensity,
                                         float x, float y, float z,
                                         float tx, float ty, float tz) {
        WeaponVisualEffectId fx = WeaponVisualEffectId.byId(vfxId);
        if (fx == null) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;

        // Attachement en direct d'un sillage de mini-pixels 3D à un projectile en vol !
        if (kind == KIND_PROJECTILE_ATTACH) {
            int projEntityId = Math.round(tx);
            if (projEntityId > 0) {
                long gt = level.getGameTime();
                TRACKED_PROJECTILES.put(projEntityId, new TrackedProjectile(fx, intensity, gt, gt + 140L));
            }
            spawnMiniPixelBurst(fx, x, y, z, 7, 0.032f, 0.14);
            return;
        }

        int duration = switch (fx) {
            case SERAPH_SKY_PILLAR, ABYSSAL_MAELSTROM, WARLORD_RALLY_SIGIL,
                 DRAGON_CHAOS_PRISM, BRIMSTONE_METEOR -> 22;
            case ASTRAL_STAR_LANCE, VOID_WARP_SPHERE, SEISMIC_TECTONIC,
                 CRIMSON_SIPHON, CHRONO_ETERNAL_HALO, ANNIHILATING_ARC -> 16;
            case CHAIN_VOLT_ARC -> 11;
            default -> 14;
        };

        float dx = tx - x;
        float dz = tz - z;
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        long seed = Double.doubleToLongBits(x * 31.0 + y * 17.0 + z * 13.0) ^ System.nanoTime();
        pushInstance(new VfxInstance(fx, kind, intensity, x, y, z, tx, ty, tz, yaw, 0.0f, 0.25f, duration, seed));

        // Éclaboussure de vrais mini-pixels 3D cubiques animés sous la physique !
        int burstCount = (fx.category == WeaponVisualEffectId.Category.BLOOD) ? 14 : 10;
        float cubeHalf = (fx.category == WeaponVisualEffectId.Category.BLOOD) ? 0.042f : 0.036f;
        spawnMiniPixelBurst(fx, x, y, z, burstCount, cubeHalf, 0.18);
    }

    public static void spawnMiniPixelBurst(WeaponVisualEffectId fx, double x, double y, double z,
                                           int count, float halfSize, double speed) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        var rand = mc.level.random;
        float grav = (fx.category == WeaponVisualEffectId.Category.BLOOD
                || fx == WeaponVisualEffectId.VENOM_BRIAR_FANG
                || fx == WeaponVisualEffectId.SEISMIC_TECTONIC) ? 0.016f
                : (fx == WeaponVisualEffectId.MOLTEN_FIRE_WAVE || fx == WeaponVisualEffectId.SOUL_FIRE_CRESCENT ? -0.005f : 0.004f);

        for (int i = 0; i < count; i++) {
            if (PIXEL_PARTICLES.size() >= MAX_VOXEL_TRAIL_PIXELS) {
                PIXEL_PARTICLES.remove(0);
            }
            double vx = (rand.nextDouble() - 0.5) * speed;
            double vy = (rand.nextDouble() - 0.2) * speed;
            double vz = (rand.nextDouble() - 0.5) * speed;
            int rgb = switch (i % 3) {
                case 0 -> fx.primaryRgb;
                case 1 -> fx.secondaryRgb;
                default -> rotateHue(fx.secondaryRgb, 0.16f);
            };
            // Tailles multi-échelles : quelques gros pixels, beaucoup de micro-éclats (jamais uniforme)
            float sz = halfSize * (0.42f + rand.nextFloat() * 1.05f);
            PIXEL_PARTICLES.add(new FloatingPixel(fx.additive, x, y, z, vx, vy, vz, grav, sz, rgb,
                    10 + rand.nextInt(10), rand.nextInt(Integer.MAX_VALUE)));
        }
    }

    private static void pushInstance(VfxInstance inst) {
        if (ACTIVE.size() >= MAX_ACTIVE_INSTANCES) {
            ACTIVE.remove(0);
        }
        ACTIVE.add(inst);
    }

    @SubscribeEvent
    public static void onClientTickPost(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer viewer = mc.player;
        if (level == null || viewer == null) {
            ACTIVE.clear();
            PIXEL_PARTICLES.clear();
            PENDING_ECHOES.clear();
            TRACKED_PROJECTILES.clear();
            PLAYER_WAS_SWINGING.clear();
            trackedLevel = null;
            return;
        }
        if (mc.isPaused()) return;

        lastTickNanos = System.nanoTime();
        if (trackedLevel != level) {
            trackedLevel = level;
            ACTIVE.clear();
            PIXEL_PARTICLES.clear();
            PENDING_ECHOES.clear();
            TRACKED_PROJECTILES.clear();
            PLAYER_WAS_SWINGING.clear();
        }
        DeepEnchant.rememberClientAccess(level.registryAccess());

        for (Iterator<VfxInstance> it = ACTIVE.iterator(); it.hasNext(); ) {
            VfxInstance inst = it.next();
            inst.age++;
            if (inst.age >= inst.maxAge) it.remove();
        }

        for (Iterator<FloatingPixel> it = PIXEL_PARTICLES.iterator(); it.hasNext(); ) {
            FloatingPixel fp = it.next();
            fp.age++;
            if (fp.age >= fp.maxAge) {
                it.remove();
                continue;
            }
            fp.x += fp.vx;
            fp.y += fp.vy;
            fp.z += fp.vz;
            fp.vy -= fp.gravity;
            fp.vx *= 0.90;
            fp.vz *= 0.90;
        }

        for (Iterator<PendingEcho> it = PENDING_ECHOES.iterator(); it.hasNext(); ) {
            PendingEcho pe = it.next();
            pe.ticksLeft--;
            if (pe.ticksLeft <= 0) {
                pushInstance(new VfxInstance(
                        pe.effect, KIND_SWING_SLASH, pe.intensity,
                        pe.x, pe.y, pe.z, pe.x, pe.y, pe.z,
                        pe.yaw, pe.pitch, -pe.tiltRad, 9, System.nanoTime()));
                it.remove();
            }
        }

        // Sillage continu de mini-cubes 3D derrière chaque flèche / carreau / trident enchanté en vol !
        long now = level.getGameTime();
        for (Iterator<Map.Entry<Integer, TrackedProjectile>> it = TRACKED_PROJECTILES.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<Integer, TrackedProjectile> e = it.next();
            TrackedProjectile tp = e.getValue();
            if (now > tp.expiresTick()) {
                it.remove();
                continue;
            }
            Entity ent = level.getEntity(e.getKey());
            if (ent == null) {
                if (now - tp.startTick() > 8L) it.remove();
                continue;
            }
            if (!ent.isAlive() || ent.onGround()) {
                it.remove();
                continue;
            }
            Vec3 vel = ent.getDeltaMovement();
            if (vel.lengthSqr() < 0.008) continue;

            for (int step = 0; step < 2; step++) {
                if (PIXEL_PARTICLES.size() >= MAX_VOXEL_TRAIL_PIXELS) PIXEL_PARTICLES.remove(0);
                double f = step * 0.5;
                double px = ent.getX() - vel.x * f + (level.random.nextDouble() - 0.5) * 0.08;
                double py = ent.getY() + 0.1 - vel.y * f + (level.random.nextDouble() - 0.5) * 0.08;
                double pz = ent.getZ() - vel.z * f + (level.random.nextDouble() - 0.5) * 0.08;
                // T349-PALETTE : traînée de flèche tricolore qui dérive lentement en teinte
                int rgb = (step == 0)
                        ? tp.effect().primaryRgb
                        : rotateHue(tp.effect().secondaryRgb, 0.10f + (float) ((now & 31L) / 31.0) * 0.14f);
                PIXEL_PARTICLES.add(new FloatingPixel(
                        tp.effect().additive, px, py, pz,
                        (level.random.nextDouble() - 0.5) * 0.02,
                        (level.random.nextDouble() - 0.5) * 0.02,
                        (level.random.nextDouble() - 0.5) * 0.02,
                        0.0f, 0.032f * (0.55f + level.random.nextFloat() * 0.9f), rgb, 9,
                        level.random.nextInt(Integer.MAX_VALUE)));
            }
        }

        // Détecte les frappes mêlée, gantelets mains nues, et tirs d'arc / arbalète
        for (Player p : level.players()) {
            if (!p.isAlive() || p.isSpectator()) continue;
            if (p != viewer && p.distanceToSqr(viewer) > 32.0 * 32.0) continue;

            boolean swinging = p.swinging && p.swingTime <= 2;
            boolean prevSwing = PLAYER_WAS_SWINGING.getOrDefault(p.getId(), false);
            PLAYER_WAS_SWINGING.put(p.getId(), p.swinging);
            if (swinging && !prevSwing) {
                onPlayerWeaponSwing(p);
            }

            // Détection relâchement d'arc ou tir d'arbalète -> salve de mini-pixels 3D devant l'arme !
            ItemStack main = p.getMainHandItem();
            ItemStack off = p.getOffhandItem();
            boolean drawingNow = p.isUsingItem() && p.getUseItem().getItem() instanceof ProjectileWeaponItem && p.getTicksUsingItem() >= 4;
            boolean wasDrawing = PLAYER_WAS_DRAWING.getOrDefault(p.getId(), false);
            PLAYER_WAS_DRAWING.put(p.getId(), drawingNow);
            if (wasDrawing && !drawingNow) {
                ItemStack ranged = main.getItem() instanceof ProjectileWeaponItem ? main : off;
                onPlayerRangedShot(p, ranged);
            }

            boolean cbCharged = (main.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(main))
                    || (off.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(off));
            boolean wasCbCharged = PLAYER_WAS_CB_CHARGED.getOrDefault(p.getId(), false);
            PLAYER_WAS_CB_CHARGED.put(p.getId(), cbCharged);
            if (wasCbCharged && !cbCharged) {
                ItemStack cb = main.getItem() instanceof CrossbowItem ? main : off;
                onPlayerRangedShot(p, cb);
            }
        }
    }

    private static void onPlayerRangedShot(Player p, ItemStack ranged) {
        List<WeaponVisualEffectId.ResolvedLayer> layers = WeaponVisualEffectId.resolveLayers(ranged, 2);
        if (layers.isEmpty()) return;
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double mx = eye.x + look.x * 0.85;
        double my = eye.y - 0.12 + look.y * 0.85;
        double mz = eye.z + look.z * 0.85;
        WeaponVisualEffectId fx = layers.get(0).effect();
        spawnMiniPixelBurst(fx, mx, my, mz, 10, 0.030f, 0.12);
    }

    private static void onPlayerWeaponSwing(Player p) {
        // T349-VFX-FREQUENCY : la tranche partait à CHAQUE clic, en plus de l'effet d'impact envoyé par
        // le serveur au touche -> même effet vu deux fois de suite, en rafale. On applique ici une chance
        // de 62 % et un vrai cooldown aléatoire (7..18 ticks) : les coups deviennent irréguliers et
        // chaque déclenchement a une variante de teinte différente.
        long nowTick = p.level().getGameTime();
        Long swingReady = PLAYER_SWING_READY.get(p.getId());
        if (swingReady != null && nowTick < swingReady) return;
        if (p.level().random.nextInt(100) >= 62) {
            PLAYER_SWING_READY.put(p.getId(), nowTick + 3L + p.level().random.nextInt(4));
            return;
        }
        PLAYER_SWING_READY.put(p.getId(), nowTick + 7L + p.level().random.nextInt(12));
        if (PLAYER_SWING_READY.size() > 256) {
            PLAYER_SWING_READY.clear();
        }

        InteractionHand hand = p.swingingArm == null ? InteractionHand.MAIN_HAND : p.swingingArm;
        ItemStack stack = p.getItemInHand(hand);

        List<WeaponVisualEffectId.ResolvedLayer> layers;
        if (stack.isEmpty()) {
            layers = WeaponVisualEffectId.resolveBareHandGauntletLayers(p, 2);
        } else if (stack.getItem() instanceof ProjectileWeaponItem) {
            return;
        } else {
            layers = WeaponVisualEffectId.resolveLayers(stack, 2);
        }
        if (layers.isEmpty()) return;

        int parity = PLAYER_SWING_PARITY.merge(p.getId(), 1, Integer::sum);
        float baseTilt = ((parity & 1) == 0) ? 0.36f : -0.34f;
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double ox = eye.x + look.x * 0.55;
        double oy = eye.y - 0.16 + look.y * 0.35;
        double oz = eye.z + look.z * 0.55;

        WeaponVisualEffectId.ResolvedLayer primary = layers.get(0);
        WeaponVisualEffectId fx = primary.effect();
        int duration = (fx == WeaponVisualEffectId.ANNIHILATING_ARC || fx == WeaponVisualEffectId.CARNAGE_BERSERK) ? 11 : 8;
        float tilt = (fx == WeaponVisualEffectId.GUILLOTINE_CLEAVE) ? 1.48f : baseTilt;

        pushInstance(new VfxInstance(
                fx, KIND_SWING_SLASH, primary.level(),
                ox, oy, oz, ox + look.x * 3.4, oy + look.y * 3.4, oz + look.z * 3.4,
                p.getYRot(), p.getXRot(), tilt, duration, System.nanoTime()));

        // Quelques mini-pixels 3D détachés le long du coup
        spawnMiniPixelBurst(fx, ox + look.x * 1.1, oy + look.y * 1.1, oz + look.z * 1.1, 5, 0.026f, 0.09);

        boolean hasEcho = fx == WeaponVisualEffectId.TWIN_ECHO_SLASH
                || (layers.size() > 1 && layers.get(1).effect() == WeaponVisualEffectId.TWIN_ECHO_SLASH);
        if (hasEcho && PENDING_ECHOES.size() < 16) {
            PendingEcho pe = new PendingEcho();
            pe.ticksLeft = 4;
            pe.effect = WeaponVisualEffectId.TWIN_ECHO_SLASH;
            pe.intensity = primary.level();
            pe.x = ox; pe.y = oy; pe.z = oz;
            pe.yaw = p.getYRot(); pe.pitch = p.getXRot(); pe.tiltRad = baseTilt;
            PENDING_ECHOES.add(pe);
        }
    }

    /** Budget de cubes par batch : évite de saturer le ByteBufferBuilder partagé de renderBuffers(). */
    private static final int MAX_CUBES_PER_BATCH = 900;
    /** Plafond dur par frame : au-delà, on arrête simplement d'émettre (jamais de pic incontrôlé). */
    private static final int HARD_CUBE_CAP_PER_FRAME = 7000;
    /** Distance au-delà de laquelle un effet n'est plus dessiné (FPS + taille des batches). */
    private static final double MAX_VFX_RENDER_DISTANCE_SQR = 96.0 * 96.0;

    private static int cubesSinceFlush;

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (ACTIVE.isEmpty() && PIXEL_PARTICLES.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        Camera cam = event.getCamera();
        Vec3 camPos = cam.getPosition();

        PoseStack poseStack = event.getPoseStack();
        Matrix4f mat = poseStack.last().pose();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        Vector3f tmp = new Vector3f();

        cubesSinceFlush = 0;
        beginFrame((mc.level.getGameTime() & 0xFFFFFL) * 0.05f
                + (mc.isPaused() ? 0.0f : Mth.clamp((System.nanoTime() - lastTickNanos) / 1.0e9f, 0.0f, 1.0f)));

        // T348-BUFFER-SAFETY : tout le rendu est encapsulé. Un BufferBuilder partagé qui aurait été
        // vidé/recyclé par un autre listener ne doit JAMAIS faire crasher le jeu ("Not building!").
        try {
            renderVfxFrame(mc, buffers, mat, tmp, camPos);
        } catch (RuntimeException ex) {
            releaseBatches(buffers);
            PIXEL_PARTICLES.clear();
            if (ACTIVE.size() > 8) {
                ACTIVE.subList(0, ACTIVE.size() - 8).clear();
            }
        }
    }

    private static void renderVfxFrame(Minecraft mc, MultiBufferSource.BufferSource buffers,
                                       Matrix4f mat, Vector3f tmp, Vec3 camPos) {
        float subTick = mc.isPaused()
                ? 0.0f
                : Mth.clamp((System.nanoTime() - lastTickNanos) / 50_000_000.0f, 0.0f, 1.0f);

        VertexConsumer addVc = null;
        VertexConsumer alphaVc = null;
        cubesSinceFlush = 0;

        // 1) Rendu des mini-pixels 3D flottants (traînées de flèches, gouttes de sang, flammèches, étincelles)
        for (int i = 0, n = PIXEL_PARTICLES.size(); i < n; i++) {
            FloatingPixel fp = PIXEL_PARTICLES.get(i);
            float t = Mth.clamp((fp.age + subTick) / (float) fp.maxAge, 0.0f, 1.0f);
            if (t >= 1.0f) continue;

            double dx = fp.x + fp.vx * subTick - camPos.x;
            double dy = fp.y + fp.vy * subTick - camPos.y;
            double dz = fp.z + fp.vz * subTick - camPos.z;
            if (dx * dx + dy * dy + dz * dz > MAX_VFX_RENDER_DISTANCE_SQR) continue;

            if (cubesSinceFlush >= MAX_CUBES_PER_BATCH) {
                flushBatches(buffers, addVc != null, alphaVc != null);
                addVc = null;
                alphaVc = null;
            }

            float rx = (float) dx;
            float ry = (float) dy;
            float rz = (float) dz;
            float sz = fp.halfSize * (1.0f - t * 0.45f);
            int alpha = Math.round(235.0f * (1.0f - t));

            VertexConsumer pvc = fp.additive ? addVc : alphaVc;
            if (pvc == null) {
                if (fp.additive) {
                    addVc = buffers.getBuffer(getAdditiveRenderType());
                    pvc = addVc;
                } else {
                    alphaVc = buffers.getBuffer(getTranslucentRenderType());
                    pvc = alphaVc;
                }
            }
            // Pixel principal de taille et de hauteur variables (aspect "vrai bloc de pixel")
            float hy = sz * (0.72f + 0.40f * pixelHash(fp.detailSalt, 3));
            emitVoxelCube(pvc, mat, tmp, rx, ry, rz, sz, hy, sz, fp.rgb, alpha);
            // 1 ou 2 micro-éclats accolés : le débris se lit comme une grappe de pixels, pas un cube lisse
            int detailMode = fp.detailSalt & 3;
            if (detailMode != 0) {
                float m = sz * 0.42f;
                emitVoxelCube(pvc, mat, tmp,
                        rx + (detailMode == 1 ? m * 1.1f : -m * 1.1f), ry + m * 0.5f, rz + m * 0.7f,
                        m * 0.62f, m * 0.52f, m * 0.62f,
                        detailMode == 2 ? 0xFFFFFF : fp.rgb, Math.round(alpha * 0.72f));
            }
            if (detailMode == 3) {
                float m = sz * 0.30f;
                emitVoxelCube(pvc, mat, tmp, rx - m, ry - m * 1.2f, rz - m,
                        m * 0.55f, m * 0.45f, m * 0.55f, fp.rgb, Math.round(alpha * 0.6f));
            }
        }

        // 2) Rendu des 30 animations d'armes en grappes de mini-cubes 3D blocky
        for (int i = 0, n = ACTIVE.size(); i < n; i++) {
            VfxInstance inst = ACTIVE.get(i);
            float t = Mth.clamp((inst.age + subTick) / (float) inst.maxAge, 0.0f, 1.0f);
            if (t >= 1.0f) continue;

            double ddx = inst.x - camPos.x;
            double ddy = inst.y - camPos.y;
            double ddz = inst.z - camPos.z;
            if (ddx * ddx + ddy * ddy + ddz * ddz > MAX_VFX_RENDER_DISTANCE_SQR) continue;

            // Flush progressif : chaque batch reste petit, le buffer partagé ne peut plus déborder
            if (cubesSinceFlush >= MAX_CUBES_PER_BATCH) {
                flushBatches(buffers, addVc != null, alphaVc != null);
                addVc = null;
                alphaVc = null;
            }

            VertexConsumer vc;
            if (inst.effect.additive) {
                if (addVc == null) addVc = buffers.getBuffer(getAdditiveRenderType());
                vc = addVc;
            } else {
                if (alphaVc == null) alphaVc = buffers.getBuffer(getTranslucentRenderType());
                vc = alphaVc;
            }

            if (inst.kind == KIND_SWING_SLASH) {
                renderVoxelSwingSlash(vc, mat, tmp, camPos, inst, t);
            } else if (inst.kind == KIND_BEAM_SIPHON) {
                renderVoxelBeamOrSiphon(vc, mat, tmp, camPos, inst, t);
            } else {
                renderVoxelImpact(vc, mat, tmp, camPos, inst, t);
            }
        }

        flushBatches(buffers, addVc != null, alphaVc != null);
    }

    /** Envoie les geometry accumulées au GPU et libère les builders (ordre : alpha puis additif). */
    private static void flushBatches(MultiBufferSource.BufferSource buffers, boolean hasAlpha, boolean hasAdditive) {
        if (hasAlpha) {
            buffers.endBatch(getTranslucentRenderType());
        }
        if (hasAdditive) {
            buffers.endBatch(getAdditiveRenderType());
        }
        cubesSinceFlush = 0;
    }

    /** Nettoyage défensif après une exception de rendu : libère les deux RenderTypes sans propager. */
    private static void releaseBatches(MultiBufferSource.BufferSource buffers) {
        try {
            buffers.endBatch(getTranslucentRenderType());
        } catch (RuntimeException ignored) {
        }
        try {
            buffers.endBatch(getAdditiveRenderType());
        } catch (RuntimeException ignored) {
        }
        cubesSinceFlush = 0;
    }

    // ==================== 1. ENTAILLES EN MINI-CUBES VOXELS 3D ====================

    private static void renderVoxelSwingSlash(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                              Vec3 cam, VfxInstance inst, float t) {
        float rx = (float) (inst.x - cam.x);
        float ry = (float) (inst.y - cam.y);
        float rz = (float) (inst.z - cam.z);

        if (inst.effect == WeaponVisualEffectId.SPECTRAL_REACH) {
            float tx = (float) (inst.tx - cam.x);
            float ty = (float) (inst.ty - cam.y);
            float tz = (float) (inst.tz - cam.z);
            float reach = Math.min(1.0f, t * 2.3f);
            emitSteppedVoxelLine(vc, mat, tmp, rx, ry, rz,
                    Mth.lerp(reach, rx, tx), Mth.lerp(reach, ry, ty), Mth.lerp(reach, rz, tz),
                    0.045f, 0xFFFFFF, inst.effect.primaryRgb, Math.round(230 * (1.0f - t)));
            return;
        }

        float sweepDeg = switch (inst.effect) {
            case CARNAGE_BERSERK -> 320.0f;
            case ANNIHILATING_ARC -> 175.0f;
            case MOLTEN_FIRE_WAVE, SOUL_FIRE_CRESCENT -> 150.0f;
            default -> 125.0f;
        };
        float radius = switch (inst.effect) {
            case ANNIHILATING_ARC -> 2.10f + 0.95f * t;
            case MOLTEN_FIRE_WAVE, SOUL_FIRE_CRESCENT, CARNAGE_BERSERK -> 1.60f + 0.45f * t;
            default -> 1.35f + 0.22f * t;
        };
        float voxelHalf = switch (inst.effect) {
            case RAZOR_GLEAM -> 0.032f;
            case ANNIHILATING_ARC -> 0.058f;
            case MOLTEN_FIRE_WAVE, SOUL_FIRE_CRESCENT, CARNAGE_BERSERK, SEISMIC_TECTONIC -> 0.048f;
            default -> 0.038f;
        };

        // T349-VARIATION : chaque déclenchement diffère un peu — amplitude, ouverture et grain.
        // (variante tirée au déclenchement, donc deux coups consécutifs ne se ressemblent jamais)
        int v = inst.variant();
        float varSpan = 0.90f + (v & 3) * 0.06f;          // 0.90 .. 1.08
        float varSweep = 0.92f + ((v >> 1) & 3) * 0.05f;  // 0.92 .. 1.07
        radius *= varSpan;
        sweepDeg *= varSweep;
        voxelHalf *= 0.88f + (v & 1) * 0.10f;

        int alpha = Math.round(238.0f * (1.0f - t * t));
        // T349-PALETTE : dégradé propre à l'enchantement + variante de teinte à chaque déclenchement
        int[] pal = palette(inst.effect, inst.variant());
        int arcCore = pal[0];
        int arcTrail = ((inst.variant() & 1) == 0) ? pal[1] : pal[2];
        emitVoxelSlashArc(vc, mat, tmp, rx, ry, rz, inst.yawDeg, inst.pitchDeg,
                inst.tiltRad, radius, voxelHalf, sweepDeg, t, arcCore, arcTrail, alpha);

        if (inst.effect == WeaponVisualEffectId.SUPREME_PRISM_EDGE) {
            emitVoxelSlashArc(vc, mat, tmp, rx, ry, rz, inst.yawDeg, inst.pitchDeg, -inst.tiltRad * 0.85f,
                    radius * 0.92f, voxelHalf * 0.85f, sweepDeg * 0.88f, t,
                    inst.effect.secondaryRgb, 0xFFFFFF, Math.round(alpha * 0.85f));
        }
    }

    private static void emitVoxelSlashArc(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                          float cx, float cy, float cz,
                                          float yawDeg, float pitchDeg, float tiltRad,
                                          float radius, float baseHalfSize, float sweepDeg, float progress,
                                          int coreRgb, int trailRgb, int peakAlpha) {
        if (peakAlpha <= 6) return;
        float yawRad = -yawDeg * Mth.DEG_TO_RAD;
        float pitchRad = pitchDeg * Mth.DEG_TO_RAD;

        float fx = Mth.sin(yawRad) * Mth.cos(pitchRad);
        float fy = -Mth.sin(pitchRad);
        float fz = Mth.cos(yawRad) * Mth.cos(pitchRad);

        float rx0 = Mth.cos(yawRad);
        float rz0 = -Mth.sin(yawRad);
        float ux0 = -Mth.sin(yawRad) * Mth.sin(pitchRad);
        float uy0 = Mth.cos(pitchRad);
        float uz0 = -Mth.cos(yawRad) * Mth.sin(pitchRad);

        float cosT = Mth.cos(tiltRad);
        float sinT = Mth.sin(tiltRad);
        float sx = rx0 * cosT + ux0 * sinT;
        float sy = uy0 * sinT;
        float sz = rz0 * cosT + uz0 * sinT;

        // Pas volontairement gros (≈1 pixel de grille) : l'entaille doit se lire comme un escalier de
        // pixels 3D bien visible, jamais comme un arc lissé.
        int pixelSteps = Math.max(9, Math.round(sweepDeg / 10.0f));
        float halfArc = (sweepDeg * 0.5f) * Mth.DEG_TO_RAD;
        float headU = Mth.clamp(progress * 1.35f, 0.0f, 1.0f);
        int salt = Math.round(cx * 577.0f + cz * 431.0f + radius * 97.0f);

        for (int i = 0; i <= pixelSteps; i++) {
            float u = (float) i / pixelSteps;
            if (u > headU + 0.15f) break;

            float distBehind = headU - u;
            if (distBehind > 0.68f) continue;

            float ang = (u - 0.5f) * 2.0f * halfArc;
            float ca = Mth.cos(ang);
            float sa = Mth.sin(ang);
            float dirX = fx * ca + sx * sa;
            float dirY = fy * ca + sy * sa;
            float dirZ = fz * ca + sz * sa;

            float taper = Mth.sin(u * (float) Math.PI);
            float px = quantize(cx + dirX * radius, 0.0625f);
            float py = quantize(cy + dirY * radius, 0.0625f);
            float pz = quantize(cz + dirZ * radius, 0.0625f);

            boolean isHead = Math.abs(distBehind) < 0.12f;
            float hs = baseHalfSize * (0.55f + 0.75f * taper) * (isHead ? 1.25f : 1.0f)
                    * (0.82f + 0.34f * pixelHash(salt, i * 13));
            int rgb = isHead ? 0xFFFFFF : (distBehind < 0.28f ? coreRgb : trailRgb);
            int a = Math.round(peakAlpha * Math.max(0.2f, 1.0f - Math.max(0.0f, distBehind) * 1.35f));

            emitVoxelCube(vc, mat, tmp, px, py, pz, hs,
                    hs * (0.78f + 0.3f * pixelHash(salt + 3, i)), hs, rgb, a);
            // Épaisseur blocky doublée d'un mini-cube intérieur décalé d'un pixel 1/16
            if (taper > 0.45f) {
                float pxIn = quantize(cx + dirX * (radius - baseHalfSize * 2.2f), 0.0625f);
                float pyIn = quantize(cy + dirY * (radius - baseHalfSize * 2.2f), 0.0625f);
                float pzIn = quantize(cz + dirZ * (radius - baseHalfSize * 2.2f), 0.0625f);
                emitVoxelCube(vc, mat, tmp, pxIn, pyIn, pzIn, hs * 0.72f, hs * 0.72f, hs * 0.72f, trailRgb, Math.round(a * 0.8f));
                // Éclat de bord minuscule sur la tranche extérieure : cassure pixel-art
                if ((i & 1) == 0) {
                    emitVoxelCube(vc, mat, tmp,
                            quantize(cx + dirX * (radius + baseHalfSize * 1.4f), 0.03125f),
                            quantize(cy + dirY * (radius + baseHalfSize * 1.4f), 0.03125f),
                            quantize(cz + dirZ * (radius + baseHalfSize * 1.4f), 0.03125f),
                            hs * 0.32f, hs * 0.26f, hs * 0.32f, 0xFFFFFF, Math.round(a * 0.55f));
                }
            }
        }
    }

    // ==================== 2. RAYONS, ÉCLAIRS CRÉNELÉS & SIPHONS VOXELS ====================

    private static void renderVoxelBeamOrSiphon(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                                Vec3 cam, VfxInstance inst, float t) {
        float x0 = (float) (inst.x - cam.x);
        float y0 = (float) (inst.y - cam.y);
        float z0 = (float) (inst.z - cam.z);
        float x1 = (float) (inst.tx - cam.x);
        float y1 = (float) (inst.ty - cam.y);
        float z1 = (float) (inst.tz - cam.z);
        int alpha = Math.round(240.0f * (1.0f - t));

        switch (inst.effect) {
            case CRIMSON_SIPHON -> {
                // #10 : 3 courants courbes de mini-cubes de sang aspirés vers le porteur !
                for (int s = 0; s < 3; s++) {
                    float phase = s * 2.094f + inst.age * 0.32f;
                    emitVoxelCurvedSiphon(vc, mat, tmp, x0, y0, z0, x1, y1, z1, phase, t,
                            inst.effect.primaryRgb, inst.effect.secondaryRgb, alpha);
                }
            }
            case CHAIN_VOLT_ARC -> {
                // #16 : Éclair en escalier de mini-cubes 3D !
                emitVoxelLightning(vc, mat, tmp, x0, y0, z0, x1, y1, z1, 9, 0.25f,
                        inst.seed + inst.age / 2, 0xFFFFFF, inst.effect.primaryRgb, alpha, 0.036f);
            }
            default -> {
                // #25 Lance Astrale / Sniper : Rayon crénelé en mini-cubes stellaires + croix pixel 3D à l'impact
                emitSteppedVoxelLine(vc, mat, tmp, x0, y0, z0, x1, y1, z1,
                        0.040f * (1.0f - t * 0.45f), 0xFFFFFF, inst.effect.primaryRgb, alpha);
                emitPixelCross3D(vc, mat, tmp, x1, y1, z1, 0.0625f, 3, 0xFFFFFF, inst.effect.secondaryRgb, alpha);
            }
        }
    }

    // ==================== 3. IMPACTS, CRITIQUES & EFFETS GRANDIOSES EN MINI-PIXELS 3D ====================

    private static void renderVoxelImpact(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                          Vec3 cam, VfxInstance inst, float t) {
        float cx = quantize((float) (inst.x - cam.x), 0.0625f);
        float cy = quantize((float) (inst.y - cam.y), 0.0625f);
        float cz = quantize((float) (inst.z - cam.z), 0.0625f);
        int fadeA = Math.round(240.0f * (1.0f - t));
        // T349-PALETTE : trois teintes par enchantement (cœur / halo / accent) au lieu de deux
        int[] pal = palette(inst.effect, inst.variant());
        int pRgb = pal[0];
        int sRgb = pal[1];
        int aRgb = pal[2];

        switch (inst.effect) {
            case GOLDEN_CRIT_STAR -> {
                // #06 Étoile Critique Pixel-Art 3D (+ en cubes + vrai cercle pixelisé de Bresenham)
                int arms = (inst.intensity >= 3) ? 4 : 3;
                emitPixelCross3D(vc, mat, tmp, cx, cy, cz, 0.0625f, arms, 0xFFFFFF, pRgb, fadeA);
                emitPixelCircle3D(vc, mat, tmp, cx, cy, cz, 0.30f + 1.35f * t, pRgb, sRgb, fadeA);
            }
            case FOCUSED_BULLSEYE -> {
                // #07 Mire circulaire pixel-art (Bresenham) faisant face au tireur + 4 crans de visée pixels
                float rad = (t < 0.4f) ? (1.10f - 1.55f * t) : (0.48f + (t - 0.4f) * 1.45f);
                emitPixelCircleBillboard3D(vc, mat, tmp, cx, cy, cz, rad, sRgb, pRgb, fadeA);
                emitPixelCross3D(vc, mat, tmp, cx, cy, cz, 0.0625f, 2, 0xFFFFFF, sRgb, fadeA);
            }
            case OVERCLOCK_CYBER_X -> {
                // #08 Immense X en escalier de mini-cubes néon cyan & magenta + cercle runique cyber pixelisé !
                float span = 0.85f + 0.55f * t;
                emitSteppedVoxelLine(vc, mat, tmp, cx - span, cy - span, cz, cx + span, cy + span, cz, 0.048f, 0xFFFFFF, pRgb, fadeA);
                emitSteppedVoxelLine(vc, mat, tmp, cx - span, cy + span, cz, cx + span, cy - span, cz, 0.048f, 0xFFFFFF, sRgb, fadeA);
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.35f, cz, 0.55f + 1.35f * t, -t * 3.0f, pRgb, sRgb, aRgb, fadeA, false);
            }
            case GUILLOTINE_CLEAVE -> {
                // #05 Colonne de cubes d'exécution tranchant de haut en bas + cercle pixel au sol
                float topY = cy + 2.0f * (1.0f - t * 0.35f);
                emitSteppedVoxelLine(vc, mat, tmp, cx, topY, cz, cx, cy - 0.8f, cz, 0.058f, sRgb, pRgb, fadeA);
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.65f, cz, 0.30f + 1.30f * t, pRgb, sRgb, fadeA);
            }
            case DRIPPING_BLOOD_EDGE, CARNAGE_BERSERK -> {
                // #09 / #12 Gouttes reconstruites en PIXELS 3D de tailles différentes (pointe fine, corps
                // large, queue, éclaboussures satellites) — plus aucune goutte lisse ni gros cube unique !
                int count = (inst.effect == WeaponVisualEffectId.CARNAGE_BERSERK) ? 10 : 7;
                for (int i = 0; i < count; i++) {
                    float ang = (float) (i * (Math.PI * 2.0 / count) + (inst.seed & 7));
                    float rad = (0.20f + 1.35f * t) * (0.72f + 0.28f * pixelHash(inst.effect.ordinal(), i * 19));
                    float dy = 0.55f * t - 1.40f * t * t;
                    float px = quantize(cx + Mth.cos(ang) * rad, 0.0625f);
                    float py = quantize(cy + dy, 0.0625f);
                    float pz = quantize(cz + Mth.sin(ang) * rad, 0.0625f);
                    float dropStep = (i % 3 == 0) ? 0.034f : ((i % 3 == 1) ? 0.024f : 0.040f);
                    emitPixelDroplet3D(vc, mat, tmp, px, py, pz, dropStep,
                            (i & 1) == 0 ? pRgb : sRgb, 0xFF8A8A, fadeA, inst.effect.ordinal() * 7 + i);
                    // Gouttelettes plus petites qui se détachent au-dessus de la goutte
                    if ((i & 1) == 0) {
                        emitVoxelCube(vc, mat, tmp, px, py + dropStep * 4.2f, pz,
                                dropStep * 0.30f, dropStep * 0.30f, dropStep * 0.30f, pRgb,
                                Math.round(fadeA * 0.8f));
                        emitVoxelCube(vc, mat, tmp, px + dropStep * 0.9f, py + dropStep * 6.0f, pz,
                                dropStep * 0.20f, dropStep * 0.20f, dropStep * 0.20f, sRgb,
                                Math.round(fadeA * 0.6f));
                    }
                }
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.35f, cz, 0.35f + 1.50f * t, pRgb, sRgb, fadeA);
            }
            case VITAL_TRANSFUSION -> {
                // #11 Double hélice voxel rubis-or + petit cercle runique médical en pixels au sol
                emitVoxelHelix(vc, mat, tmp, cx, cy - 0.6f, cz, 0.65f, 1.8f, t * 4.0f, pRgb, sRgb, fadeA);
                emitVoxelHelix(vc, mat, tmp, cx, cy - 0.6f, cz, 0.65f, 1.8f, t * 4.0f + (float) Math.PI, sRgb, pRgb, fadeA);
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.45f, cz, 0.75f, sRgb, pRgb, fadeA);
            }
            case SOUL_FIRE_CRESCENT -> {
                // #14 Cercle runique d'âme en pixels turquoise + flammes voxel montantes
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.40f, cz, 0.55f + 1.35f * t, t * 2.2f, pRgb, sRgb, aRgb, fadeA, true);
                emitVoxelHelix(vc, mat, tmp, cx, cy - 0.4f, cz, 0.60f, 1.6f, t * 3.8f, pRgb, sRgb, fadeA);
            }
            case BRIMSTONE_METEOR -> {
                // #15 Bloc-météore cubique plongeant du ciel + grand cercle runique infernal en pixels !
                if (t < 0.48f) {
                    float mt = t / 0.48f;
                    float mx = quantize(cx + 3.2f * (1.0f - mt), 0.0625f);
                    float my = quantize(cy + 11.0f * (1.0f - mt), 0.0625f);
                    float mz = quantize(cz + 2.0f * (1.0f - mt), 0.0625f);
                    // Météore reconstruit en amas de pixels 3D (croûte irrégulière + cœur incandescent)
                    emitPixelRockCluster3D(vc, mat, tmp, mx, my, mz, 0.0625f, 10, pRgb, sRgb, 0xFFFFFF, 235,
                            inst.effect.ordinal() * 13 + inst.age);
                    emitSteppedVoxelLine(vc, mat, tmp, mx + 1.0f, my + 3.2f, mz + 0.6f, mx, my, mz,
                            0.070f, sRgb, pRgb, 220);
                }
                float st = Math.max(0.0f, (t - 0.2f) / 0.8f);
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.38f, cz, 0.55f + 2.65f * st, t * 1.5f, sRgb, pRgb, 0xFFFFFF, fadeA, true);
            }
            case CHAIN_VOLT_ARC -> {
                // #16 Éclair céleste en escalier de cubes 3D + 3 arcs au sol + onde circulaire pixelisée
                emitVoxelLightning(vc, mat, tmp, cx + 0.3f, cy + 8.0f, cz - 0.3f, cx, cy, cz, 11, 0.35f,
                        inst.seed + inst.age / 2, 0xFFFFFF, pRgb, fadeA, 0.045f);
                for (int b = 0; b < 3; b++) {
                    float a = b * 2.094f + (inst.seed & 3);
                    emitVoxelLightning(vc, mat, tmp, cx, cy, cz,
                            cx + Mth.cos(a) * 1.8f, cy - 0.3f, cz + Mth.sin(a) * 1.8f,
                            5, 0.18f, inst.seed + b * 29L + inst.age, sRgb, pRgb, fadeA, 0.035f);
                }
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.35f, cz, 0.35f + 1.45f * t, 0xFFFFFF, pRgb, fadeA);
            }
            case HYDRO_TIDAL_SURGE -> {
                emitVoxelHelix(vc, mat, tmp, cx, cy - 0.5f, cz, 0.55f + 0.8f * t, 1.6f, t * 4.8f, pRgb, sRgb, fadeA);
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.35f, cz, 0.30f + 2.00f * t, sRgb, pRgb, fadeA);
            }
            case ABYSSAL_MAELSTROM -> {
                // #18 Vortex océanique de mini-cubes 3D tournoyants à 4 bras + cercle pixel abyssal
                for (int arm = 0; arm < 4; arm++) {
                    float baseAng = arm * ((float) Math.PI * 0.5f) + t * 6.0f;
                    for (int s = 1; s <= 9; s++) {
                        float u = s / 9.0f;
                        float r = Mth.lerp(u, 0.25f, 2.6f * (1.0f - 0.2f * t));
                        float a = baseAng + u * 2.6f;
                        float vx = quantize(cx + Mth.cos(a) * r, 0.0625f);
                        float vy = quantize(cy - 0.35f + (1.0f - u) * 0.55f, 0.0625f);
                        float vz = quantize(cz + Mth.sin(a) * r, 0.0625f);
                        emitVoxelCube(vc, mat, tmp, vx, vy, vz, 0.052f * (1.15f - 0.4f * u), 0.052f, 0.052f,
                                (s & 1) == 0 ? sRgb : pRgb, fadeA);
                    }
                }
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.38f, cz, 0.45f + 2.05f * t, pRgb, sRgb, fadeA);
            }
            case PERMAFROST_RIME -> {
                // #19 Piliers de cristaux cubiques de glace + cercle runique givré en pixels !
                for (int k = 0; k < 6; k++) {
                    float a = k * ((float) Math.PI / 3.0f);
                    float r = 0.40f + 1.45f * t;
                    float px = quantize(cx + Mth.cos(a) * r, 0.0625f);
                    float pz = quantize(cz + Mth.sin(a) * r, 0.0625f);
                    float h = 0.38f * (1.0f - t * 0.5f);
                    // Cristal en pixels 3D empilés qui s'affinent vers la pointe (jamais un bloc unique)
                    int segs = 4;
                    for (int seg = 0; seg < segs; seg++) {
                        float su = seg / (float) segs;
                        float segS = 0.0625f * (1.0f - 0.62f * su);
                        float sy = cy - 0.3f + h * (su + 0.5f / segs);
                        emitVoxelCube(vc, mat, tmp, px, sy, pz,
                                segS, h / segs * 0.52f, segS,
                                (k & 1) == 0 ? sRgb : pRgb, fadeA);
                        emitVoxelCube(vc, mat, tmp, px + segS * 0.85f, sy + h / segs * 0.16f, pz - segS * 0.7f,
                                segS * 0.48f, h / segs * 0.3f, segS * 0.48f, 0xFFFFFF,
                                Math.round(fadeA * 0.55f));
                    }
                    emitVoxelCube(vc, mat, tmp, px, cy - 0.3f + h + 0.02f, pz,
                            0.0125f, 0.020f, 0.0125f, 0xFFFFFF, Math.round(fadeA * 0.9f));
                }
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.38f, cz, 0.45f + 1.45f * t, 0.0f, sRgb, pRgb, 0xFFFFFF, fadeA, false);
            }
            case VENOM_BRIAR_FANG -> {
                emitVoxelHelix(vc, mat, tmp, cx, cy - 0.5f, cz, 0.70f, 1.5f, t * 3.0f, pRgb, sRgb, fadeA);
                emitVoxelHelix(vc, mat, tmp, cx, cy - 0.5f, cz, 0.70f, 1.5f, -t * 3.0f + 1.4f, sRgb, pRgb, fadeA);
            }
            case SEISMIC_TECTONIC -> {
                // #21 Failles de cubes rocheux soulevés sur le sol + onde sismique circulaire en pixels
                float reach = 0.5f + 2.9f * Mth.sqrt(t);
                for (int f = 0; f < 6; f++) {
                    float a = f * ((float) Math.PI / 3.0f) + 0.2f;
                    emitSteppedVoxelLine(vc, mat, tmp, cx, cy - 0.42f, cz,
                            cx + Mth.cos(a) * reach, cy - 0.42f, cz + Mth.sin(a) * reach,
                            0.058f, sRgb, pRgb, fadeA);
                }
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.40f, cz, reach * 0.78f, pRgb, sRgb, fadeA);
            }
            case ZEPHYR_WIND_LANCE -> {
                emitPixelCircle3D(vc, mat, tmp, cx, cy, cz, 0.35f + 1.90f * t, pRgb, sRgb, fadeA);
                emitPixelCircle3D(vc, mat, tmp, cx, cy + 0.45f * t, cz, 0.25f + 1.25f * t, 0xFFFFFF, pRgb, fadeA);
            }
            case SERAPH_SKY_PILLAR -> {
                // #23 Colonne céleste blocky + VRAI CERCLE RUNIQUE SACRÉ EN PIXELS 3D au sol et en élévation !
                float hw = 0.26f * Mth.sin(Math.min(1.0f, t * 1.3f) * (float) Math.PI);
                if (hw > 0.02f) {
                    // Colonne céleste reconstruite en pixels 3D empilés de tailles différentes : cœur blanc
                    // crénelé, halo de micro-pixels colorés et étincelles — aucun gros bloc rectangulaire.
                    int layers = 30;
                    for (int li = 0; li < layers; li++) {
                        float lu = li / (float) (layers - 1);
                        float ly = cy + 0.15f + lu * 10.8f;
                        float bulge = 0.35f + 0.85f * Mth.sin(lu * (float) Math.PI);
                        float spread = hw * bulge;
                        float jx = (pixelHash(inst.effect.ordinal() + li, li * 31) - 0.5f) * spread * 1.35f;
                        float jz = (pixelHash(li * 7 + 3, li * 17) - 0.5f) * spread * 1.35f;
                        float px = quantize(cx + jx, 0.0625f);
                        float pz = quantize(cz + jz, 0.0625f);
                        float coreS = 0.028f + 0.030f * bulge;
                        emitVoxelCube(vc, mat, tmp, px, ly, pz, coreS,
                                coreS * (1.05f + 0.35f * pixelHash(li, li * 5)), coreS, 0xFFFFFF, fadeA);
                        int haloA = Math.round(fadeA * 0.42f);
                        emitVoxelCube(vc, mat, tmp, quantize(px + spread, 0.0625f), ly + 0.02f, pz,
                                coreS * 0.72f, coreS * 0.9f, coreS * 0.72f, sRgb, haloA);
                        emitVoxelCube(vc, mat, tmp, px, ly + 0.01f, quantize(pz - spread, 0.0625f),
                                coreS * 0.60f, coreS * 0.78f, coreS * 0.60f, pRgb, Math.round(haloA * 0.9f));
                        if ((li & 3) == 0) {
                            emitVoxelCube(vc, mat, tmp, quantize(px, 0.03125f), ly + coreS * 2.2f, pz,
                                    coreS * 0.26f, coreS * 0.26f, coreS * 0.26f, 0xFFFFFF,
                                    Math.round(fadeA * 0.6f));
                        }
                    }
                }
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.38f, cz, 0.65f + 1.75f * Math.min(1.0f, t * 1.6f),
                        t * 1.8f, pRgb, sRgb, aRgb, fadeA, true);
                emitPixelCircle3D(vc, mat, tmp, cx, cy - 0.20f + 2.4f * t, cz, 0.55f + 1.15f * t, 0xFFFFFF, sRgb, fadeA);
            }
            case WITHER_SHADOW_RIFT -> {
                // #24 Triple griffure d'ombre en escalier de mini-pixels violets-noirs
                for (int claw = -1; claw <= 1; claw++) {
                    float off = claw * 0.28f;
                    emitSteppedVoxelLine(vc, mat, tmp,
                            cx - 0.65f + off, cy + 0.75f, cz - 0.30f,
                            cx + 0.65f + off, cy - 0.65f, cz + 0.30f,
                            0.044f, sRgb, pRgb, fadeA);
                }
            }
            case ASTRAL_STAR_LANCE -> {
                // #25 Impact stellaire : étoile 3D + cercle runique astral en pixels !
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.35f, cz, 0.50f + 1.35f * t, -t * 2.4f, pRgb, sRgb, aRgb, fadeA, true);
                emitPixelCross3D(vc, mat, tmp, cx, cy + 0.1f, cz, 0.0625f, 4, 0xFFFFFF, pRgb, fadeA);
            }
            case VOID_WARP_SPHERE -> {
                // #26 Cercle runique du Vide en pixels 3D (implosion/explosion) + croix abyssale
                float r = 0.40f + 1.45f * Mth.sin(t * (float) Math.PI);
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.20f, cz, r, -t * 3.5f, pRgb, sRgb, aRgb, fadeA, true);
                emitPixelCircleBillboard3D(vc, mat, tmp, cx, cy + 0.1f, cz, r * 0.65f, sRgb, pRgb, fadeA);
                emitPixelCross3D(vc, mat, tmp, cx, cy + 0.1f, cz, 0.0625f, 3, sRgb, pRgb, fadeA);
            }
            case DRAGON_CHAOS_PRISM -> {
                // #27 Cercle runique draconique arc-en-ciel en pixels 3D !
                int c1 = Mth.hsvToRgb((t * 1.5f) % 1.0f, 0.8f, 1.0f);
                int c2 = Mth.hsvToRgb((t * 1.5f + 0.35f) % 1.0f, 0.85f, 1.0f);
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.38f, cz, 0.55f + 2.15f * t, t * 2.6f, c1, c2, 0xFFFFFF, fadeA, true);
                emitPixelCross3D(vc, mat, tmp, cx, cy + 0.2f, cz, 0.0625f, 4, 0xFFFFFF, c1, fadeA);
            }
            case CHRONO_ETERNAL_HALO -> {
                // #28 Cadran d'horloge runique en pixels 3D (double cercle de Bresenham + 8 runes + aiguilles pixels) !
                float r = 1.05f;
                float hy = cy + 0.65f;
                emitPixelRunicCircle3D(vc, mat, tmp, cx, hy, cz, r, t * 0.8f, pRgb, sRgb, aRgb, fadeA, false);
                float aFast = t * 8.5f;
                float aSlow = t * 2.2f;
                emitSteppedVoxelLine(vc, mat, tmp, cx, hy, cz,
                        cx + Mth.cos(aFast) * r * 0.58f, hy, cz + Mth.sin(aFast) * r * 0.58f,
                        0.032f, 0xFFFFFF, pRgb, fadeA);
                emitSteppedVoxelLine(vc, mat, tmp, cx, hy, cz,
                        cx + Mth.cos(aSlow) * r * 0.40f, hy, cz + Mth.sin(aSlow) * r * 0.40f,
                        0.038f, sRgb, pRgb, fadeA);
            }
            case WARLORD_RALLY_SIGIL -> {
                // #29 Grand Cercle Runique du Chef de Guerre en pixels 3D (double anneau Bresenham + 8 runes 3x3 + étoile) !
                float r = 2.05f * Math.min(1.0f, t * 2.4f);
                emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.40f, cz, r, t * 1.6f, pRgb, sRgb, aRgb, fadeA, true);
            }
            default -> {
                float maxR = (inst.effect == WeaponVisualEffectId.ANNIHILATING_ARC) ? 3.1f : 1.65f;
                if (inst.effect == WeaponVisualEffectId.ANNIHILATING_ARC) {
                    emitPixelRunicCircle3D(vc, mat, tmp, cx, cy - 0.35f, cz, 0.45f + maxR * t, t * 3.0f, aRgb, pRgb, sRgb, fadeA, true);
                } else {
                    emitPixelCircle3D(vc, mat, tmp, cx, cy, cz, 0.25f + maxR * t, pRgb, sRgb, fadeA);
                }
                emitPixelCross3D(vc, mat, tmp, cx, cy, cz, 0.0625f, 3, 0xFFFFFF, pRgb, fadeA);
            }
        }
    }

    // ==================== PRIMITIVES VOXELS 3D (MINI-CUBES 6 FACES MINECRAFT) ====================

    /**
     * Dessine un vrai mini-cube 3D à 6 faces alignées sur la grille avec l'ombrage directionnel
     * exact de Minecraft (UP 100 %, N/S 84 %, E/W 72 %, DOWN 60 %).
     */
    public static void emitVoxelCube(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                     float cx, float cy, float cz,
                                     float hx, float hy, float hz,
                                     int rgb, int alpha) {
        if (alpha <= 5 || hx <= 0.0005f || hy <= 0.0005f || hz <= 0.0005f) return;
        if (alphaFloor > 0 && alpha < alphaFloor) return;
        if (cubesSinceFlush >= HARD_CUBE_CAP_PER_FRAME) return;
        cubesSinceFlush++;

        // T349-PIXEL-VARIATION : chaque pixel est rapetissé/agrandi aléatoirement MAIS de façon lisse
        // dans le temps (bruit sinusoïdal déterministe par position) : la taille respire doucement au
        // lieu de rester un gros bloc figé.
        float scale = framePixelScale * smoothPulse(cx, cy, cz);
        hx *= scale;
        hy *= scale;
        hz *= scale;

        float x0 = cx - hx, x1 = cx + hx;
        float y0 = cy - hy, y1 = cy + hy;
        float z0 = cz - hz, z1 = cz + hz;

        int rTop = rgb;
        int rNS = shadeRgb(rgb, 0.85f);
        int rEW = shadeRgb(rgb, 0.73f);
        int rBot = shadeRgb(rgb, 0.62f);

        // UP
        putQuad(vc, mat, tmp, x0, y1, z0, rTop, alpha, x0, y1, z1, rTop, alpha, x1, y1, z1, rTop, alpha, x1, y1, z0, rTop, alpha);
        // DOWN
        putQuad(vc, mat, tmp, x0, y0, z1, rBot, alpha, x0, y0, z0, rBot, alpha, x1, y0, z0, rBot, alpha, x1, y0, z1, rBot, alpha);
        // NORTH
        putQuad(vc, mat, tmp, x1, y1, z0, rNS, alpha, x1, y0, z0, rNS, alpha, x0, y0, z0, rNS, alpha, x0, y1, z0, rNS, alpha);
        // SOUTH
        putQuad(vc, mat, tmp, x0, y1, z1, rNS, alpha, x0, y0, z1, rNS, alpha, x1, y0, z1, rNS, alpha, x1, y1, z1, rNS, alpha);
        // WEST
        putQuad(vc, mat, tmp, x0, y1, z0, rEW, alpha, x0, y0, z0, rEW, alpha, x0, y0, z1, rEW, alpha, x0, y1, z1, rEW, alpha);
        // EAST
        putQuad(vc, mat, tmp, x1, y1, z1, rEW, alpha, x1, y0, z1, rEW, alpha, x1, y0, z0, rEW, alpha, x1, y1, z0, rEW, alpha);
    }

    /**
     * T349-PIXEL-VARIATION : pulsation lente et déterministe (0.72 .. 1.12) propre à chaque position.
     * Comme elle dérive du temps de frame, la variation est parfaitement lisse (aucun scintillement).
     */
    private static float smoothPulse(float x, float y, float z) {
        float h = x * 12.9898f + y * 78.233f + z * 37.719f;
        float n = h - (float) Math.floor(h * 0.15915494f) * 6.2831855f;
        float t = frameTimeSeconds;
        return 0.92f + 0.11f * Mth.sin(t * 1.15f + n) + 0.09f * Mth.sin(t * 0.41f + n * 2.3f);
    }

    /**
     * T349-PALETTE : palette vivante (cœur, halo, accent saturé) dérivée de l'enchantement et tournée
     * par variante. Les entailles et traînées de flèches ne sont donc plus monochromes : chaque
     * enchantement a son dégradé propre et chaque déclenchement décale légèrement la teinte.
     */
    public static int[] palette(WeaponVisualEffectId fx, int variant) {
        int core = fx.primaryRgb;
        int glow = fx.secondaryRgb;
        float shift = ((variant & 7) - 3.5f) * 0.012f;
        int accent = rotateHue(glow, 0.12f + shift);
        return new int[]{core, glow, accent};
    }

    /** Rotation de teinte HSV légère d'une couleur RGB 0xRRGGBB. */
    public static int rotateHue(int rgb, float deltaHue) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        float max = Math.max(r, Math.max(g, b)) / 255.0f;
        float min = Math.min(r, Math.min(g, b)) / 255.0f;
        float v = max;
        float sat = max <= 0.0f ? 0.0f : (max - min) / max;
        float h;
        float d = max - min;
        if (d <= 0.00001f) {
            h = 0.0f;
        } else if (max == r / 255.0f) {
            h = ((g - b) / 255.0f) / d;
            if (h < 0.0f) h += 6.0f;
            h /= 6.0f;
        } else if (max == g / 255.0f) {
            h = (((b - r) / 255.0f) / d + 2.0f) / 6.0f;
        } else {
            h = (((r - g) / 255.0f) / d + 4.0f) / 6.0f;
        }
        h = (h + deltaHue) % 1.0f;
        if (h < 0.0f) h += 1.0f;
        int i = (int) (h * 6.0f);
        float f = h * 6.0f - i;
        float pp = v * (1.0f - sat);
        float q = v * (1.0f - sat * f);
        float t = v * (1.0f - sat * (1.0f - f));
        float rr, gg, bb;
        switch (i % 6) {
            case 0 -> { rr = v; gg = t; bb = pp; }
            case 1 -> { rr = q; gg = v; bb = pp; }
            case 2 -> { rr = pp; gg = v; bb = t; }
            case 3 -> { rr = pp; gg = q; bb = v; }
            case 4 -> { rr = t; gg = pp; bb = v; }
            default -> { rr = v; gg = pp; bb = q; }
        }
        return ((int) (rr * 255) << 16) | ((int) (gg * 255) << 8) | (int) (bb * 255);
    }

    /** T345-PIXEL-DETAIL : micro-aléa déterministe (0..1) — toutes les tailles de pixels restent stables d'une frame à l'autre. */
    private static float pixelHash(int salt, int a) {
        int h = salt * 0x9E3779B1 ^ (a * 0x85EBCA77);
        h ^= (h >>> 15);
        h *= 0x2545F491;
        h ^= (h >>> 13);
        return (h & 0xFFFF) / 65535.0f;
    }

    private static final int PIXEL_RING_SOLID  = 0;
    private static final int PIXEL_RING_DASHED = 1;
    private static final int PIXEL_RING_BEADS  = 2;

    /**
     * Croix pixel-art 3D détaillée : cœur à double taille, bras crénelés de cubes dégressifs,
     * éclats diagonaux minuscules et micro-pixels de pointe (aucun gros bloc uniforme).
     */
    public static void emitPixelCross3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                        float cx, float cy, float cz,
                                        float stepSize, int armPixels,
                                        int coreRgb, int tipRgb, int alpha) {
        if (alpha <= 6 || stepSize <= 0.004f) return;
        float hs = stepSize * 0.46f;
        int salt = Math.round(cx * 811.0f + cy * 457.0f + cz * 293.0f);

        emitVoxelCube(vc, mat, tmp, cx, cy, cz, hs * 1.24f, hs * 1.30f, hs * 1.24f, 0xFFFFFF, alpha);
        emitVoxelCube(vc, mat, tmp, cx, cy - hs * 0.9f, cz, hs * 0.72f, hs * 0.42f, hs * 0.72f, coreRgb,
                Math.round(alpha * 0.85f));
        for (int d = 0; d < 4; d++) {
            float sx = ((d & 1) == 0) ? 1.0f : -1.0f;
            float sy = ((d & 2) == 0) ? 1.0f : -1.0f;
            emitVoxelCube(vc, mat, tmp, cx + sx * stepSize * 0.92f, cy + sy * stepSize * 0.92f, cz,
                    hs * 0.38f, hs * 0.38f, hs * 0.38f, coreRgb, Math.round(alpha * 0.8f));
        }

        for (int i = 1; i <= armPixels; i++) {
            float off = i * stepSize;
            float t = (armPixels > 1) ? (float) (i - 1) / (armPixels - 1) : 0.0f;
            float s = hs * (1.02f - 0.40f * t) * (0.86f + 0.28f * pixelHash(salt + i * 17, i));
            int rgb = (i == 1) ? coreRgb : tipRgb;
            int a = Math.round(alpha * (1.0f - 0.13f * (i - 1)));
            crossArmPixel(vc, mat, tmp, cx + off, cy, cz, s, rgb, a, salt + i, 0);
            crossArmPixel(vc, mat, tmp, cx - off, cy, cz, s, rgb, a, salt + i, 1);
            crossArmPixel(vc, mat, tmp, cx, cy + off, cz, s, rgb, a, salt + i, 2);
            crossArmPixel(vc, mat, tmp, cx, cy - off, cz, s, rgb, a, salt + i, 3);
            if (i <= 2) {
                crossArmPixel(vc, mat, tmp, cx, cy, cz + off, s, rgb, a, salt + i, 4);
                crossArmPixel(vc, mat, tmp, cx, cy, cz - off, s, rgb, a, salt + i, 5);
            }
        }
    }

    /** Pixel de bras de croix : tailles X/Y/Z différentes + micro-éclat de bord. */
    private static void crossArmPixel(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                      float px, float py, float pz, float s,
                                      int rgb, int alpha, int salt, int face) {
        float jy = s * (0.76f + 0.44f * pixelHash(salt, face * 29 + 7));
        float jz = s * (0.84f + 0.28f * pixelHash(salt + 3, face * 13 + 1));
        emitVoxelCube(vc, mat, tmp, px, py, pz, s, jy, jz, rgb, alpha);
        if ((face & 1) == 0) {
            emitVoxelCube(vc, mat, tmp, px, py + jy * 0.94f, pz, s * 0.34f, s * 0.26f, s * 0.34f,
                    0xFFFFFF, Math.round(alpha * 0.68f));
        }
    }

    /**
     * Ligne pixel-art 3D : chaque pas est un mini-cube de taille variable, avec coudes de remplissage
     * (aucun trou en escalier) et éclats périodiques plus petits — l'effet "trait droit 3D" reste
     * volontairement crénelé, jamais une forme lisse.
     */
    public static void emitSteppedVoxelLine(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                            float x0, float y0, float z0,
                                            float x1, float y1, float z1,
                                            float halfSize, int coreRgb, int outerRgb, int alpha) {
        if (alpha <= 6 || halfSize <= 0.002f) return;
        float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        float dist = Mth.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist <= 0.0005f) return;

        float grid = Math.max(0.03125f, halfSize * 1.95f);
        int count = Math.min(64, Math.max(2, Math.round(dist / grid)));
        int salt = Math.round(x0 * 911.0f + z0 * 647.0f + y0 * 383.0f + dist * 97.0f);

        float prevX = 0.0f, prevY = 0.0f, prevZ = 0.0f;
        boolean hasPrev = false;
        for (int i = 0; i <= count; i++) {
            float u = (float) i / count;
            float px = quantize(Mth.lerp(u, x0, x1), grid);
            float py = quantize(Mth.lerp(u, y0, y1), grid);
            float pz = quantize(Mth.lerp(u, z0, z1), grid);
            int rgb = ((i & 1) == 0) ? coreRgb : outerRgb;

            if (hasPrev) {
                int changed = 0;
                if (Math.abs(px - prevX) > grid * 0.45f) changed++;
                if (Math.abs(py - prevY) > grid * 0.45f) changed++;
                if (Math.abs(pz - prevZ) > grid * 0.45f) changed++;
                if (changed >= 2) {
                    // Coude : petit cube intercalé pour garder la ligne continue en escalier
                    emitVoxelCube(vc, mat, tmp,
                            (prevX + px) * 0.5f, (prevY + py) * 0.5f, (prevZ + pz) * 0.5f,
                            halfSize * 0.60f, halfSize * 0.60f, halfSize * 0.60f,
                            ((i & 1) == 0) ? outerRgb : coreRgb, Math.round(alpha * 0.92f));
                }
            }

            float jit = 0.84f + 0.30f * pixelHash(salt, i * 13);
            emitVoxelCube(vc, mat, tmp, px, py, pz,
                    halfSize * jit,
                    halfSize * (0.74f + 0.32f * pixelHash(salt + 5, i * 7)),
                    halfSize * jit, rgb, alpha);
            if ((i & 3) == 1) {
                emitVoxelCube(vc, mat, tmp, px, py + halfSize * 1.12f, pz,
                        halfSize * 0.33f, halfSize * 0.27f, halfSize * 0.33f, 0xFFFFFF,
                        Math.round(alpha * 0.7f));
            }
            prevX = px; prevY = py; prevZ = pz;
            hasPrev = true;
        }
    }

    /**
     * 12 vraies runes pixel-art 5x5 (bitmaps 25 bits, ligne par ligne) : Fehu, Algiz, Othala, Tiwaz,
     * Dagaz, Sowilo, Ingwaz, Gebo, Ehwaz, Ansuz, Raido, Thurisaz.
     */
    private static final int[] RUNE_BITMAPS_5X5 = {
            0b10000_11110_11111_10100_10000, // Fehu
            0b10001_01010_00100_00100_00100, // Algiz
            0b01110_10001_10001_01010_00100, // Othala
            0b01110_00100_00100_00100_00100, // Tiwaz
            0b11100_11110_01111_00111_00011, // Dagaz
            0b01110_11000_01100_00110_01110, // Sowilo
            0b00100_01010_10001_01010_00100, // Ingwaz
            0b10001_01010_00100_01010_10001, // Gebo
            0b00100_01110_11111_01110_00100, // Ehwaz
            0b10000_11100_10110_10000_11000, // Ansuz
            0b11100_10010_11100_10100_10010, // Raido
            0b01100_10010_01100_01000_01000  // Thurisaz
    };

    private static boolean runeBit(int mask, int row, int col) {
        int bit = 24 - (row * 5 + col);
        return ((mask >>> bit) & 1) != 0;
    }

    /**
     * T345-PIXEL-RING : vrai cercle pixel-art (rasterisation colonne par colonne, comme un sprite de
     * cercle Minecraft) — chaque pixel est un mini-cube 3D de taille variable, avec pixels internes
     * plus petits et biseaux de marche pour que la courbe reste visiblement crénelée.
     */
    public static void emitPixelCircle3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                         float cx, float cy, float cz,
                                         float radius, int rgbA, int rgbB, int alpha) {
        emitPixelRing3D(vc, mat, tmp, cx, cy, cz, radius, rgbA, rgbB, alpha, PIXEL_RING_SOLID);
    }

    private static void emitPixelRing3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                        float cx, float cy, float cz, float radius,
                                        int rgbA, int rgbB, int alpha, int style) {
        if (alpha <= 6 || radius <= 0.06f) return;
        float grid = (radius <= 0.70f) ? 0.0625f : ((radius <= 1.55f) ? 0.078125f : 0.109375f);
        int rPix = Math.min(30, Math.max(2, Math.round(radius / grid)));
        // Le niveau de détail (micro-pixel intérieur + biseau) n'est activé que sur les petits cercles :
        // sur les grands rayons, le contour pixel-art suffit et le nombre de cubes reste raisonnable.
        boolean fine = rPix <= 16;
        float hs = grid * 0.47f;
        float gx = quantize(cx, grid);
        float gz = quantize(cz, grid);
        int salt = Math.round(cx * 977.0f + cz * 613.0f + cy * 331.0f) ^ (rPix * 31);

        if (style == PIXEL_RING_BEADS) {
            // Anneau de perles : pixels isolés tous les 3 pas, tailles alternées
            for (int u = -rPix; u <= rPix; u += 3) {
                int v = (int) Math.round(Math.sqrt((double) Math.max(0, rPix * rPix - u * u)));
                ringPixel(vc, mat, tmp, gx, cy, gz, u, v, grid, hs, alpha, rgbA, rgbB, false, fine, salt);
                if (v != 0) {
                    ringPixel(vc, mat, tmp, gx, cy, gz, u, -v, grid, hs, alpha, rgbB, rgbA, false, fine, salt + 1);
                }
            }
            return;
        }

        int lastV = -1;
        for (int u = -rPix; u <= rPix; u++) {
            int v = (int) Math.round(Math.sqrt((double) Math.max(0, rPix * rPix - u * u)));
            boolean edgeStep = (u == -rPix || u == rPix || v == 0 || v == rPix);
            if (style == PIXEL_RING_DASHED) {
                if (((u >> 1) & 1) != 0) {
                    lastV = v;
                    continue;
                }
                ringPixel(vc, mat, tmp, gx, cy, gz, u, v, grid, hs, alpha, rgbA, rgbB, edgeStep, fine, salt);
                if (v != 0) {
                    ringPixel(vc, mat, tmp, gx, cy, gz, u, -v, grid, hs, alpha, rgbB, rgbA, edgeStep, fine, salt + 1);
                }
                lastV = v;
                continue;
            }

            // Remplissage vertical : le contour reste jointif là où la courbe "saute" d'un cran.
            // Grand rayon : seuls les deux bords de la marche sont posés (4x moins de cubes).
            int from = (lastV >= 0) ? Math.min(lastV, v) : v;
            int to = (lastV >= 0) ? Math.max(lastV, v) : v;
            for (int k = from; k <= to; k++) {
                if (!fine && k != from && k != to) continue;
                boolean edge = edgeStep || k == from || k == to;
                ringPixel(vc, mat, tmp, gx, cy, gz, u, k, grid, hs, alpha, rgbA, rgbB, edge, fine, salt);
                if (k != 0) {
                    ringPixel(vc, mat, tmp, gx, cy, gz, u, -k, grid, hs, alpha, rgbB, rgbA, edge, fine, salt + 1);
                }
            }
            lastV = v;
        }
    }

    /** Un pixel de cercle : cube principal de taille variable, micro-pixel intérieur et biseau de marche. */
    private static void ringPixel(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                  float gx, float gy, float gz, int u, int v,
                                  float grid, float hs, int alpha,
                                  int rgb, int rgbAlt, boolean edge, boolean detail, int salt) {
        float px = gx + u * grid;
        float pz = gz + v * grid;
        float jx = 0.80f + 0.30f * pixelHash(salt, u * 37 + v * 11);
        float hy = hs * (0.66f + 0.34f * pixelHash(salt ^ 0x5F, u * 13 + v * 41));

        emitVoxelCube(vc, mat, tmp, px, gy, pz, hs * jx, hy, hs * (0.82f + 0.26f * pixelHash(salt + 9, u * 7 + v * 29)),
                rgb, alpha);
        if (!detail) return;

        // Pixel intérieur plus petit : donne l'épaisseur "2 blocs de tailles différentes"
        if (((u * 3 + v * 5) & 1) == 0) {
            float inX = px + (u >= 0 ? -grid * 0.29f : grid * 0.29f);
            float inZ = pz + (v >= 0 ? -grid * 0.29f : grid * 0.29f);
            emitVoxelCube(vc, mat, tmp, inX, gy + hy * 0.62f, inZ,
                    grid * 0.20f, grid * 0.15f, grid * 0.20f, rgbAlt, Math.round(alpha * 0.88f));
        }
        // Biseau de marche : marque le crénelage pixel-art (jamais de courbe lissée)
        if (edge) {
            emitVoxelCube(vc, mat, tmp,
                    px + (u >= 0 ? -grid * 0.42f : grid * 0.42f), gy - hy * 0.52f,
                    pz + (v >= 0 ? grid * 0.20f : -grid * 0.20f),
                    grid * 0.16f, grid * 0.10f, grid * 0.16f, rgbAlt, Math.round(alpha * 0.78f));
        }
    }

    /**
     * T345-PIXEL-RETICLE : réticule pixel-art face caméra — anneau rasterisé en pixels 3D de tailles
     * variées, second anneau intérieur pointillé, et crans de mire dégressifs.
     */
    private static void emitPixelCircleBillboard3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                                   float cx, float cy, float cz,
                                                   float radius, int rgbA, int rgbB, int alpha) {
        if (alpha <= 6 || radius <= 0.06f) return;
        float horizDist = Mth.sqrt(cx * cx + cz * cz);
        float rx = (horizDist > 0.01f) ? (-cz / horizDist) : 1.0f;
        float rz = (horizDist > 0.01f) ? (cx / horizDist) : 0.0f;

        float grid = (radius <= 1.20f) ? 0.0625f : 0.09375f;
        int rPix = Math.min(24, Math.max(3, Math.round(radius / grid)));
        boolean fine = rPix <= 14;
        float hs = grid * 0.47f;
        int salt = Math.round(cx * 733.0f + cy * 419.0f + cz * 617.0f + radius * 89.0f);

        int lastV = -1;
        for (int u = -rPix; u <= rPix; u++) {
            int v = (int) Math.round(Math.sqrt((double) Math.max(0, rPix * rPix - u * u)));
            int from = (lastV >= 0) ? Math.min(lastV, v) : v;
            int to = (lastV >= 0) ? Math.max(lastV, v) : v;
            for (int k = from; k <= to; k++) {
                if (!fine && k != from && k != to) continue;
                boolean edge = (u == -rPix || u == rPix || k == 0 || k == rPix || k == from || k == to);
                int rgb = (((u + k) >> 1) & 1) == 0 ? rgbA : rgbB;
                billboardPixel(vc, mat, tmp, cx, cy, cz, rx, rz, u, k, grid, hs, rgb, rgbB, alpha, edge, fine, salt);
                if (k != 0) {
                    billboardPixel(vc, mat, tmp, cx, cy, cz, rx, rz, u, -k, grid, hs, rgb, rgbB, alpha, edge, fine, salt + 1);
                }
            }
            lastV = v;
        }

        // Second anneau intérieur pointillé (profondeur pixel-art du réticule)
        int innerPix = Math.max(2, Math.round(rPix * 0.56f));
        for (int u = -innerPix; u <= innerPix; u += 2) {
            int v = (int) Math.round(Math.sqrt((double) Math.max(0, innerPix * innerPix - u * u)));
            billboardPixel(vc, mat, tmp, cx, cy, cz, rx, rz, u, v, grid, hs * 0.8f, rgbB, rgbA,
                    Math.round(alpha * 0.72f), false, fine, salt + 5);
            if (v != 0) {
                billboardPixel(vc, mat, tmp, cx, cy, cz, rx, rz, u, -v, grid, hs * 0.8f, rgbB, rgbA,
                        Math.round(alpha * 0.72f), false, fine, salt + 6);
            }
        }

        // Crans de mire dégressifs sur les 4 axes + marques diagonales minuscules
        for (int tk = 1; tk <= 3; tk++) {
            int p = rPix - tk;
            if (p <= 1) break;
            int a2 = Math.round(alpha * (tk == 1 ? 1.0f : 0.62f));
            float s = hs * (tk == 1 ? 1.05f : 0.56f);
            billboardRaw(vc, mat, tmp, cx, cy, cz, rx, rz, p, 0, grid, s, 0xFFFFFF, a2);
            billboardRaw(vc, mat, tmp, cx, cy, cz, rx, rz, -p, 0, grid, s, 0xFFFFFF, a2);
            billboardRaw(vc, mat, tmp, cx, cy, cz, rx, rz, 0, p, grid, s, 0xFFFFFF, a2);
            billboardRaw(vc, mat, tmp, cx, cy, cz, rx, rz, 0, -p, grid, s, 0xFFFFFF, a2);
        }
        int diag = Math.max(2, Math.round(rPix * 0.70f));
        for (int d = 0; d < 4; d++) {
            int ux = ((d & 1) == 0) ? diag : -diag;
            int uy = ((d & 2) == 0) ? diag : -diag;
            billboardRaw(vc, mat, tmp, cx, cy, cz, rx, rz, ux, uy, grid, hs * 0.5f, rgbA, Math.round(alpha * 0.8f));
        }
    }

    private static void billboardPixel(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                       float cx, float cy, float cz, float rx, float rz,
                                       int uPix, int vPix, float grid, float hs, int rgb, int rgbAlt,
                                       int alpha, boolean edge, boolean detail, int salt) {
        float px = cx + rx * (uPix * grid);
        float py = cy + vPix * grid;
        float pz = cz + rz * (uPix * grid);
        float jx = 0.80f + 0.30f * pixelHash(salt, uPix * 31 + vPix * 17);
        float hy = hs * (0.68f + 0.32f * pixelHash(salt + 2, uPix * 11 + vPix * 43));
        emitVoxelCube(vc, mat, tmp, px, py, pz, hs * jx, hy, hs * jx, rgb, alpha);
        if (!detail) return;
        if (((uPix + vPix) & 1) == 0) {
            emitVoxelCube(vc, mat, tmp, px - rx * grid * 0.26f, py - grid * 0.22f, pz - rz * grid * 0.26f,
                    grid * 0.19f, grid * 0.15f, grid * 0.19f, rgbAlt, Math.round(alpha * 0.85f));
        }
        if (edge) {
            emitVoxelCube(vc, mat, tmp, px + rx * grid * 0.30f, py + grid * 0.24f, pz + rz * grid * 0.30f,
                    grid * 0.14f, grid * 0.11f, grid * 0.14f, 0xFFFFFF, Math.round(alpha * 0.75f));
        }
    }

    private static void billboardRaw(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                     float cx, float cy, float cz, float rx, float rz,
                                     int uPix, int vPix, float grid, float hs,
                                     int rgb, int alpha) {
        emitVoxelCube(vc, mat, tmp,
                cx + rx * (uPix * grid), cy + vPix * grid, cz + rz * (uPix * grid),
                hs, hs * 0.9f, hs, rgb, alpha);
    }

    /**
     * T345-PIXEL-RUNIC-CIRCLE : cercle runique fait d'ANNEAUX DE PIXELS :
     * anneau extérieur plein, anneau intérieur plein, anneau de perles ornemental, runes 5x5
     * en mini-cubes orientés vers l'extérieur, étoile inscrite crénelée et accents cardinaux.
     */
    public static void emitPixelRunicCircle3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                              float cx, float cy, float cz,
                                              float outerRadius, float rotPhase,
                                              int outerRgb, int innerRgb, int runeRgb,
                                              int alpha, boolean withInscribedStar) {
        if (alpha <= 6 || outerRadius <= 0.15f) return;

        // 1) Anneau extérieur : cercle de pixels 3D jointifs, tailles variées
        emitPixelRing3D(vc, mat, tmp, cx, cy, cz, outerRadius, outerRgb, innerRgb, alpha, PIXEL_RING_SOLID);

        // 2) Anneau intérieur plein, légèrement plus petit
        float innerR = outerRadius * 0.60f;
        if (innerR >= 0.16f) {
            emitPixelRing3D(vc, mat, tmp, cx, cy, cz, innerR, innerRgb, runeRgb,
                    Math.round(alpha * 0.94f), PIXEL_RING_SOLID);
        }

        // 3) Anneau de perles pixel-art entre les deux anneaux
        float beadR = outerRadius * 0.78f;
        if (beadR >= 0.30f) {
            emitPixelRing3D(vc, mat, tmp, cx, cy, cz, beadR, runeRgb, outerRgb,
                    Math.round(alpha * 0.72f), PIXEL_RING_BEADS);
        }

        // 4) Runes 5x5 en mini-pixels 3D, orientées vers l'extérieur du cercle
        if (outerRadius >= 0.42f) {
            float step = Mth.clamp(outerRadius * 0.040f, 0.024f, 0.050f);
            int runeCount = (outerRadius >= 1.75f) ? 12 : ((outerRadius >= 0.95f) ? 8 : 4);
            int phaseIdx = Math.round(rotPhase * 3.0f);
            for (int r = 0; r < runeCount; r++) {
                float ang = rotPhase + r * ((float) (Math.PI * 2.0) / runeCount);
                float rx = quantize(cx + Mth.cos(ang) * beadR, 0.03125f);
                float rz = quantize(cz + Mth.sin(ang) * beadR, 0.03125f);
                emitPixelRune3D(vc, mat, tmp, rx, cy + 0.022f, rz, r + phaseIdx, step,
                        -ang + (float) (Math.PI * 0.5), runeRgb, (r & 1) == 0 ? 0xFFFFFF : innerRgb, alpha);
            }
        }

        // 5) Étoile runique inscrite en lignes de pixels crénelées
        if (withInscribedStar && innerR >= 0.22f) {
            float sr = innerR * 0.92f;
            float lineHalf = Mth.clamp(outerRadius * 0.024f, 0.014f, 0.032f);
            for (int k = 0; k < 4; k++) {
                float a = rotPhase * 0.5f + k * ((float) Math.PI * 0.25f);
                float dx = Mth.cos(a) * sr;
                float dz = Mth.sin(a) * sr;
                emitSteppedVoxelLine(vc, mat, tmp, cx - dx, cy, cz - dz, cx + dx, cy, cz + dz,
                        lineHalf, (k & 1) == 0 ? runeRgb : innerRgb, outerRgb, Math.round(alpha * 0.86f));
            }
            emitVoxelCube(vc, mat, tmp, cx, cy + lineHalf * 0.4f, cz,
                    lineHalf * 1.5f, lineHalf * 1.2f, lineHalf * 1.5f, 0xFFFFFF, Math.round(alpha * 0.9f));
        }

        // 6) Accents cardinaux : micro-pixels blancs pour le piqué pixel-art
        if (outerRadius >= 0.60f) {
            for (int k = 0; k < 4; k++) {
                float a = rotPhase * 0.35f + k * ((float) Math.PI * 0.5f);
                float px = quantize(cx + Mth.cos(a) * outerRadius, 0.03125f);
                float pz = quantize(cz + Mth.sin(a) * outerRadius, 0.03125f);
                float s = Mth.clamp(outerRadius * 0.028f, 0.010f, 0.030f);
                emitVoxelCube(vc, mat, tmp, px, cy + s * 1.1f, pz, s, s * 0.85f, s, 0xFFFFFF,
                        Math.round(alpha * 0.85f));
            }
        }
    }

    /** Rune pixel-art 5x5 : pixels "colonne" plus gros et pixels de liaison plus petits + orientation radiale. */
    private static void emitPixelRune3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                        float rx, float ry, float rz,
                                        int glyphIdx, float pixelStep, float angleRad,
                                        int stemRgb, int accentRgb, int alpha) {
        int mask = RUNE_BITMAPS_5X5[Math.floorMod(glyphIdx, RUNE_BITMAPS_5X5.length)];
        float ca = Mth.cos(angleRad);
        float sa = Mth.sin(angleRad);
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                if (!runeBit(mask, row, col)) continue;
                int neighbours = 0;
                if (col > 0 && runeBit(mask, row, col - 1)) neighbours++;
                if (col < 4 && runeBit(mask, row, col + 1)) neighbours++;
                if (row > 0 && runeBit(mask, row - 1, col)) neighbours++;
                if (row < 4 && runeBit(mask, row + 1, col)) neighbours++;

                boolean stem = neighbours >= 2;
                float dx = (col - 2) * pixelStep;
                float dz = (row - 2) * pixelStep;
                float px = rx + dx * ca - dz * sa;
                float pz = rz + dx * sa + dz * ca;
                float hx = pixelStep * (stem ? 0.47f : 0.34f);
                float hy = pixelStep * (stem ? 0.42f : 0.28f);
                emitVoxelCube(vc, mat, tmp, px, ry + (stem ? 0.0f : pixelStep * 0.07f), pz,
                        hx, hy, hx, stem ? stemRgb : accentRgb, alpha);
            }
        }
    }

    /**
     * Goutte pixel-art 3D : aucune forme lisse, uniquement un empilement de cubes de tailles
     * différentes (pointe fine, corps large, queue, éclaboussures satellites, micro-reflet).
     */
    public static void emitPixelDroplet3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                          float cx, float cy, float cz, float pixelStep,
                                          int bodyRgb, int lightRgb, int alpha, int salt) {
        if (alpha <= 6 || pixelStep <= 0.004f) return;
        float[][] pixels = {
                {0.00f, 3.10f, 0.16f},
                {0.00f, 2.25f, 0.28f},
                {0.00f, 1.35f, 0.40f},
                {-0.42f, 0.55f, 0.34f}, {0.42f, 0.55f, 0.34f},
                {0.00f, 0.50f, 0.52f},
                {-0.52f, -0.35f, 0.34f}, {0.52f, -0.35f, 0.34f},
                {0.00f, -0.42f, 0.50f},
                {0.00f, -1.20f, 0.34f},
                {0.00f, -1.75f, 0.18f}
        };
        for (int i = 0; i < pixels.length; i++) {
            float jx = (pixelHash(salt, i * 11) - 0.5f) * pixelStep * 0.22f;
            float jz = (pixelHash(salt + 13, i * 7) - 0.5f) * pixelStep * 0.22f;
            float s = pixelStep * pixels[i][2];
            emitVoxelCube(vc, mat, tmp,
                    cx + pixelStep * pixels[i][0] + jx,
                    cy + pixelStep * pixels[i][1],
                    cz + jz,
                    s, s * 0.86f, s,
                    i <= 2 ? lightRgb : bodyRgb,
                    Math.round(alpha * (i <= 2 ? 0.92f : 1.0f)));
        }
        emitVoxelCube(vc, mat, tmp, cx - pixelStep * 0.55f, cy + pixelStep * 0.9f, cz - pixelStep * 0.1f,
                pixelStep * 0.13f, pixelStep * 0.13f, pixelStep * 0.13f, 0xFFE0E0, Math.round(alpha * 0.85f));
        emitVoxelCube(vc, mat, tmp, cx + pixelStep * 1.15f, cy + pixelStep * 2.0f, cz + pixelStep * 0.35f,
                pixelStep * 0.11f, pixelStep * 0.11f, pixelStep * 0.11f, bodyRgb, Math.round(alpha * 0.8f));
        emitVoxelCube(vc, mat, tmp, cx - pixelStep * 1.05f, cy - pixelStep * 0.9f, cz + pixelStep * 0.5f,
                pixelStep * 0.14f, pixelStep * 0.12f, pixelStep * 0.14f, lightRgb, Math.round(alpha * 0.7f));
    }

    /** Amas de pixels 3D (météore, éclat de roche, cœur) : croûte irrégulière de cubes de tailles différentes. */
    public static void emitPixelRockCluster3D(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                              float cx, float cy, float cz, float pixelStep, int count,
                                              int crustRgb, int glowRgb, int hotRgb, int alpha, int salt) {
        if (alpha <= 6 || pixelStep <= 0.004f) return;
        emitVoxelCube(vc, mat, tmp, cx, cy, cz, pixelStep * 1.10f, pixelStep * 1.00f, pixelStep * 1.10f, hotRgb, alpha);
        long h = salt * 0x9E3779B97F4A7C15L;
        for (int i = 0; i < count; i++) {
            h = h * 6364136223846793005L + 1442695040888963407L;
            float a = (((h >>> 11) & 0x3FF) / 1023.0f) * (float) (Math.PI * 2.0);
            h = h * 6364136223846793005L + 1442695040888963407L;
            float elev = ((((h >>> 13) & 0x1FF) / 511.0f) - 0.5f) * 1.6f;
            h = h * 6364136223846793005L + 1442695040888963407L;
            float dist = 0.75f + (((h >>> 17) & 0xFF) / 255.0f) * 1.35f;
            float px = quantize(cx + Mth.cos(a) * pixelStep * dist, pixelStep * 0.5f);
            float py = quantize(cy + elev * pixelStep * dist, pixelStep * 0.5f);
            float pz = quantize(cz + Mth.sin(a) * pixelStep * dist, pixelStep * 0.5f);
            float s = pixelStep * (0.30f + 0.30f * ((i & 1) == 0 ? 1.0f : 0.5f));
            emitVoxelCube(vc, mat, tmp, px, py, pz, s, s * 0.88f, s,
                    (i % 3 == 0) ? glowRgb : crustRgb, Math.round(alpha * Math.max(0.45f, 0.95f - 0.03f * i)));
        }
    }

    /** Éclair 3D en escalier de mini-cubes voxels. */
    public static void emitVoxelLightning(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                          float x0, float y0, float z0,
                                          float x1, float y1, float z1,
                                          int nodes, float jitterAmp, long seed,
                                          int coreRgb, int glowRgb, int alpha, float cubeHalf) {
        if (alpha <= 6) return;
        float px = x0, py = y0, pz = z0;
        long h = seed * 0x9E3779B97F4A7C15L;
        for (int i = 1; i <= nodes; i++) {
            float f = (float) i / nodes;
            float nx = Mth.lerp(f, x0, x1);
            float ny = Mth.lerp(f, y0, y1);
            float nz = Mth.lerp(f, z0, z1);
            if (i < nodes) {
                float env = Mth.sin(f * (float) Math.PI) * jitterAmp;
                h = h * 6364136223846793005L + 1442695040888963407L;
                nx += (((h >>> 16) & 0xFF) / 127.5f - 1.0f) * env;
                h = h * 6364136223846793005L + 1442695040888963407L;
                ny += (((h >>> 16) & 0xFF) / 127.5f - 1.0f) * env * 0.6f;
                h = h * 6364136223846793005L + 1442695040888963407L;
                nz += (((h >>> 16) & 0xFF) / 127.5f - 1.0f) * env;
            }
            emitSteppedVoxelLine(vc, mat, tmp, px, py, pz, nx, ny, nz, cubeHalf, coreRgb, glowRgb, alpha);
            px = nx; py = ny; pz = nz;
        }
    }

    private static void emitVoxelCurvedSiphon(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                              float x0, float y0, float z0,
                                              float x1, float y1, float z1,
                                              float phase, float progress,
                                              int darkRgb, int brightRgb, int alpha) {
        if (alpha <= 6) return;
        float mx = (x0 + x1) * 0.5f + Mth.cos(phase) * 0.75f;
        float my = Math.max(y0, y1) + 0.85f + Mth.sin(phase) * 0.35f;
        float mz = (z0 + z1) * 0.5f + Mth.sin(phase) * 0.75f;

        int cubes = 16;
        int salt = Math.round(phase * 137.0f + progress * 53.0f);
        float prevX = x0, prevY = y0, prevZ = z0;
        for (int i = 0; i <= cubes; i++) {
            float u = (float) i / cubes;
            float inv = 1.0f - u;
            float bx = quantize(inv * inv * x0 + 2.0f * inv * u * mx + u * u * x1, 0.0625f);
            float by = quantize(inv * inv * y0 + 2.0f * inv * u * my + u * u * y1, 0.0625f);
            float bz = quantize(inv * inv * z0 + 2.0f * inv * u * mz + u * u * z1, 0.0625f);
            float pulse = 1.0f - Math.min(1.0f, Math.abs(u - progress) * 2.8f);
            float hs = (0.034f + 0.026f * pulse) * (0.82f + 0.36f * pixelHash(salt, i * 13));
            // Coude de remplissage : le siphon reste un chapelet de pixels jointifs, jamais lissé
            if (i > 0 && (Math.abs(bx - prevX) > 0.03f && Math.abs(by - prevY) > 0.03f)) {
                emitVoxelCube(vc, mat, tmp, (bx + prevX) * 0.5f, (by + prevY) * 0.5f, (bz + prevZ) * 0.5f,
                        hs * 0.58f, hs * 0.58f, hs * 0.58f, darkRgb, Math.round(alpha * 0.9f));
            }
            emitVoxelCube(vc, mat, tmp, bx, by, bz, hs,
                    hs * (0.78f + 0.3f * pixelHash(salt + 4, i)), hs,
                    pulse > 0.35f ? brightRgb : darkRgb, alpha);
            if ((i & 2) == 0) {
                emitVoxelCube(vc, mat, tmp, bx + hs * 1.1f, by + hs * 0.35f, bz,
                        hs * 0.32f, hs * 0.32f, hs * 0.32f, brightRgb, Math.round(alpha * 0.62f));
            }
            prevX = bx; prevY = by; prevZ = bz;
        }
    }

    private static void emitVoxelHelix(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                       float cx, float baseY, float cz,
                                       float radius, float height, float phase,
                                       int rgbA, int rgbB, int alpha) {
        if (alpha <= 6) return;
        int cubes = 18;
        int salt = Math.round(phase * 211.0f + radius * 379.0f);
        float pxP = cx, pyP = baseY, pzP = cz;
        for (int i = 0; i <= cubes; i++) {
            float u = (float) i / cubes;
            float a = phase + u * (float) Math.PI * 2.4f;
            float nx = quantize(cx + Mth.cos(a) * radius * (1.0f - 0.2f * u), 0.0625f);
            float ny = quantize(baseY + u * height, 0.0625f);
            float nz = quantize(cz + Mth.sin(a) * radius * (1.0f - 0.2f * u), 0.0625f);
            float hs = 0.040f * (1.0f - u * 0.32f) * (0.80f + 0.38f * pixelHash(salt, i * 11));
            // Remplissage des marches : l'hélice reste un escalier de pixels continus
            if (i > 0) {
                emitVoxelCube(vc, mat, tmp, (nx + pxP) * 0.5f, (ny + pyP) * 0.5f, (nz + pzP) * 0.5f,
                        hs * 0.56f, hs * 0.56f, hs * 0.56f, rgbB, Math.round(alpha * 0.85f));
            }
            emitVoxelCube(vc, mat, tmp, nx, ny, nz, hs,
                    hs * (0.80f + 0.26f * pixelHash(salt + 3, i)), hs,
                    (i & 1) == 0 ? rgbA : rgbB, alpha);
            // Micro-pixel décalé : casse l'effet "gros bloc uniforme"
            if ((i & 1) == 0) {
                emitVoxelCube(vc, mat, tmp, quantize(nx + hs * 1.25f, 0.03125f), ny, quantize(nz - hs * 1.1f, 0.03125f),
                        hs * 0.34f, hs * 0.30f, hs * 0.34f, rgbA, Math.round(alpha * 0.66f));
            }
            pxP = nx; pyP = ny; pzP = nz;
        }
    }

    public static float quantize(float v, float step) {
        return Math.round(v / step) * step;
    }

    private static int shadeRgb(int rgb, float mul) {
        int r = Math.min(255, Math.round(((rgb >>> 16) & 0xFF) * mul));
        int g = Math.min(255, Math.round(((rgb >>> 8) & 0xFF) * mul));
        int b = Math.min(255, Math.round((rgb & 0xFF) * mul));
        return (r << 16) | (g << 8) | b;
    }

    public static void putQuad(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                               float x0, float y0, float z0, int rgb0, int a0,
                               float x1, float y1, float z1, int rgb1, int a1,
                               float x2, float y2, float z2, int rgb2, int a2,
                               float x3, float y3, float z3, int rgb3, int a3) {
        putPosColor(vc, mat, tmp, x0, y0, z0, rgb0, a0);
        putPosColor(vc, mat, tmp, x1, y1, z1, rgb1, a1);
        putPosColor(vc, mat, tmp, x2, y2, z2, rgb2, a2);
        putPosColor(vc, mat, tmp, x3, y3, z3, rgb3, a3);
    }

    public static void putPosColor(VertexConsumer vc, Matrix4f mat, Vector3f tmp,
                                   float x, float y, float z, int rgb, int a) {
        mat.transformPosition(x, y, z, tmp);
        int ca = Mth.clamp(a, 0, 255);
        vc.addVertex(tmp.x(), tmp.y(), tmp.z())
                .setColor((rgb >>> 16) & 0xFF, (rgb >>> 8) & 0xFF, rgb & 0xFF, ca);
    }
}
